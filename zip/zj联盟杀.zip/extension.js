var ZJNGEx;
(function (ZJNGEx) {
    ZJNGEx.type = NG.ImportType.Extension;
    function extensionFun(lib, game, ui, get, ai, _status) {
        var heros = {
            name: "ZJShaHero",
            connect: true,
            character: {},
            characterTitle: {},
            skill: {},
            translate: {}
        };
        var skills = {
            name: "ZJShaSkill",
            skill: {},
            translate: {}
        };
        var cards = {
            name: "ZJShaCard",
            connect: true,
            card: {},
            skill: {},
            list: [],
            translate: {}
        };
        var extensionData = {
            name: "ZJ_Sha",
            editable: true,
            config: {
                start_wuxing: {
                    name: "启用五行属性",
                    init: true,
                    intro: "将”魏蜀吴群神“变为”水火木土金“",
                    frequent: true,
                    onclick: function (item) {
                        console.log("点击后输出的结果为：", item);
                    }
                },
                start_wuxingSkill: {
                    name: "启用ZJ联盟杀的五行属性主公技",
                    init: true,
                    intro: "在身份局中，不同属性的身份会拥有不同的主公技",
                    frequent: true,
                    onclick: function (item) {
                        console.log("点击后输出的结果为：", item);
                    }
                }
            },
            precontent: function (data) {
            },
            content: function (config, pack) {
            },
            onremove: function () {
            },
            package: {
                author: "神雷zero",
                intro: "ZJ联盟杀",
                version: "1.0.0",
                character: heros,
                skill: skills,
                card: cards,
            },
            translate: {
                ZJ_Sha: "ZJ联盟杀",
            },
            help: {
                ZJ联盟杀: NG.Utils.createHelp([
                    "先测试下1",
                    "先测试下2",
                    ["先测试下2.1", "先测试下2.2"],
                    "先测试下3",
                    "先测试下4",
                    ["先测试下4.1", "先测试下4.2"]
                ])
            }
        };
        return extensionData;
    }
    ZJNGEx.extensionFun = extensionFun;
})(ZJNGEx || (ZJNGEx = {}));
game.import(ZJNGEx.type, ZJNGEx.extensionFun);
//# sourceMappingURL=extension.js.map