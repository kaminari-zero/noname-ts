game.import("extension",function(lib,game,ui,get,ai,_status){return {name:"导入助手",content:function (config,pack){
    
	var importExtension = game.importExtension;
	
	game.importExtension = function(data, finishLoad, exportext, pkg) {
		if (!window.JSZip || get.objtype(data)=='object') return importExtension.call(this, data, finishLoad, exportext, pkg);
		
		try {
			var zip = new JSZip();
			zip.load(data);
			
			var file = zip.file('extension.js');
			if (file == null) {
				alert('缺少 extension.js 文件，请检查该扩展文件的文件结构是否正确！');
				return false;
			}
			
			var str = file.asText();
			_status.importingExtension = true;
			eval(str);
			_status.importingExtension = false;
			

			if (!game.importedPack || lib.config.all.plays.contains('extname')) {
				throw ('err');
			}
			
			var extname = game.importedPack.name;
			
			if (lib.config.extensions.contains(extname)) {
				game.removeExtension(extname, true);
			}
			
			lib.config.extensions.add(extname);
			game.saveConfig('extensions', lib.config.extensions);
			game.saveConfig('extension_' + extname + '_enable', true);
			for (var i in game.importedPack.config) {
				if (game.importedPack.config[i] && game.importedPack.config[i].hasOwnProperty('init')) {
					game.saveConfig('extension_' + extname + '_' + i, game.importedPack.config[i].init);
				}
			}
			
			if (game.download) {
				var filelist = [];
				for (var i in zip.files) {
					if (i[0] != '.' && i[0] != '_') {
						filelist.push(i);
					}
				}
				
				var dirs = [];
				var callback = function(){};
				for (var i = 0; i < filelist.length; i++) {
					if (filelist[i].indexOf('.') < 0) {
						dirs.push(filelist[i]);
						filelist.splice(i--, 1);
						if (filelist.length == 0) break;
					}
				}
				
				if (lib.node && lib.node.fs) {
					for (var i = 0; i < dirs.length; i++) {
						game.ensureDirectory('extension/' + extname + '/' + dirs[i], callback);
					}

					game.ensureDirectory('extension/' + extname, function(){
						var writeFile = function() {
							if (filelist.length) {
								var filename = filelist.shift();
								console.log(filename);
								lib.node.fs.writeFile(__dirname + '/extension/' + extname + '/' + filename, zip.files[filename].asNodeBuffer(), null, writeFile);
							} else {
								finishLoad();
							}
						}
						
						writeFile();
					});
				} else {
					window.resolveLocalFileSystemURL(lib.assetURL, function(entry){
						for (var i = 0; i < dirs.length; i++) {
							entry.getDirectory('extension/' + extname + '/' + dirs[i], { create: true }, callback);
						}

						entry.getDirectory('extension/' + extname, { create: true }, function(dirEntry){
							var writeFile = function() {
								if (filelist.length) {
									var filename = filelist.shift();
									dirEntry.getFile(filename, { create: true }, function(fileEntry){
										fileEntry.createWriter(function(fileWriter){
											fileWriter.onwriteend = writeFile;
											fileWriter.write(zip.files[filename].asArrayBuffer());
										});
									});
								} else {
									finishLoad();
								}
							};
							writeFile();
						});
					});
				}
			} else {
				localStorage.setItem(lib.configprefix + 'extension_' + extname, str);
				var imglist = [];
				for (var i in zip.files) {
					if (i[0] != '.' && i[0] != '_') {
						if (i.indexOf('.jpg') != -1 || i.indexOf('.png') != -1) {
							imglist.push(i);
						}
					}
				}
				if (imglist.length && lib.db) {
					lib.config.extensionInfo[extname] = {
						image: imglist
					}
					game.saveConfig('extensionInfo', lib.config.extensionInfo);
					for (var i = 0; i < imglist.length; i++) {
						var imgname = imglist[i];
						var str = zip.file(imgname).asArrayBuffer();
						if (str) {
							var blob = new Blob([str]);
							var fileReader = new FileReader();
							fileReader.onload = (function(imgname){
								return function(fileLoadedEvent) {
									var data = fileLoadedEvent.target.result;
									game.putDB('image', 'extension-' + extname + ':' + imgname, data);
								};
							}(imgname));
							
							fileReader.readAsDataURL(blob, "UTF-8");
						}
					}
				}
				finishLoad();
			}
			
			delete game.importedPack;
		} catch(e) {
			console.log(e);
			alert('导入失败');
			return false;
		}
	};
	
	
	
},precontent:function(){
    
	
	
},help:{},config:{},package:{
    character:{
        character:{
        },
        translate:{
        },
    },
    card:{
        card:{
        },
        translate:{
        },
        list:[],
    },
    skill:{
        skill:{
        },
        translate:{
        },
    },
    intro:'<p style="color:rgb(200,200,000); font-size:12px; line-height:14px; text-shadow: 0 0 2px black;">' +
	'1.0.1：' + '<br>' +
	'- 修复手机端不能正常导入的BUG；<br>' +
    '</p>',
    author:"短歌 QQ464598631",
    diskURL:"",
    forumURL:"",
    version:"1.0.1",
},files:{"character":[],"card":[],"skill":[]},editable:false}})