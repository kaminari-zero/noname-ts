window.func=function(lib,game,ui,get,ai,_status){
	var change=false;
	var change1=false;
	setInterval(function(){
		if(get.mode()=='brawl'||get.mode()=='identity'||get.mode()=='guozhan'||get.mode()=='partner'){
			if(game.players!=undefined&&game.dead!=undefined){
				if(game.players.length+game.dead.length-game.countPlayer(function(current){return current.扩展ol_type=='fellow'})>8||game.shibing_move_interval!=undefined){
					if(change==false){
						game.documentZoom=game.deviceZoom*0.8;
						var width=document.documentElement.offsetWidth;
						var height=document.documentElement.offsetHeight;
						var zoom=game.documentZoom;
						document.body.style.width=(width/zoom)+'px';
						document.body.style.height=(height/zoom)+'px';
						document.body.style.transform='scale('+zoom+')';
						change=true;
						change1=false;
					};
				}else{
					if(change1==false){
						game.documentZoom=game.deviceZoom*1;
						if(ui.updatez!=undefined) ui.updatez();
						change1=true;
						change=false;
					};
				};
			};
		};
	},1000);
}