window.func=function(lib,game,ui,get,ai,_status){
	//name,info,time,condition,reward,limit_times
	var date=new Date();
	if(lib.config.finish_task==undefined) game.saveConfig('finish_task',{});
	lib.onover.push(function(result){
		if(game.checkTime('2019-10-01 00:00:00','2019-10-07 23:59:59')&&result==true){
			lib.config.finish_task.guoqingkuaike=true;
			game.saveConfig('finish_task',lib.config.finish_task);
		};
	});
	if(lib.kzol_task==undefined) lib.kzol_task={};
	if(lib.config.kzol_task==undefined) lib.config.kzol_task={};//finished_times
	game.saveConfig('kzol_task',lib.config.kzol_task);
	var tasks={
		'国庆快乐':{
			info:'(限完成一次)',
			time:{
				b:'2019-10-01 00:00:00',
				e:'2019-10-07 23:59:59',
			},
			condition:function(){
				return lib.config.finish_task.guoqingkuaike==true;
			},
			condition_info:'2019国庆假期期间胜利一局',
			reward:{
				'guoqinghongqi':1,
			},
			finished_func:function(){
				delete lib.config.finish_task.guoqingkuaike;
				game.saveConfig('finish_task',lib.config.finish_task);
			},
			//reward_info:'，哈哈哈',
			limit_times:1,
		},
		'限时领取':{
			info:'(限完成一次)',
			time:{
				b:'2019-10-14 00:00:00',
				e:'2019-10-20 23:59:59',
			},
			condition:function(){
				return true;
			},
			condition_info:'2019年10月14日至20日打开游戏即可领取',
			reward:{
				'baozhu':1,
			},
			limit_times:1,
		},
		'限时领取：千面':{
			info:'(限完成一次)',
			time:{
				b:'2019-10-14 00:00:00',
				e:'2019-10-20 23:59:59',
			},
			condition:function(){
				return true;
			},
			condition_info:'2019年10月14日至20日打开游戏即可领取',
			reward:{
				'qianmian':1,
			},
			limit_times:1,
		},
		'限时领取：虚空·大剑':{
			info:'(限完成一次)',
			time:{
				b:'2019-10-22 00:00:00',
				e:'2019-10-29 23:59:59',
			},
			condition:function(){
				return true;
			},
			condition_info:'2019年10月22日至29日打开游戏即可领取',
			reward:{
				'xukongdajian':1,
			},
			limit_times:1,
		},
	};
	for(var i in tasks){
		var task=tasks[i];
		lib.kzol_task[i]=task;
	};
	game.checkTime=function(bTime,eTime){
		//game.checkTime('2019-09-18 00:00:00','2019-10-22 00:00:00')
		var time;
		var month=(date.getMonth()+1).toString();
		if(month.length==1) month='0'+month;
		var day=date.getDate().toString();
		if(day.length==1) day='0'+day;
		var hour=date.getHours().toString();
		if(hour.length==1) hour='0'+hour;
		var minute=date.getMinutes().toString();
		if(minute.length==1) minute='0'+minute;
		var second=date.getSeconds().toString();
		if(second.length==1) second='0'+second;
		time=date.getFullYear()+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;
		var beginTime=time;
		var endTime=bTime;
		var beginTimes=beginTime.substring(0,10).split('-');
		var endTimes=endTime.substring(0,10).split('-');
		beginTime=beginTimes[1]+'-'+beginTimes[2]+'-'+beginTimes[0]+' '+beginTime.substring(10,19);
		endTime=endTimes[1]+'-'+endTimes[2]+'-'+endTimes[0]+' '+endTime.substring(10,19);
		var a=(Date.parse(endTime)-Date.parse(beginTime))/3600/1000;
		if(a<0){
			var beginTime1=time;
			var endTime1=eTime;
			var beginTimes1=beginTime1.substring(0,10).split('-');
			var endTimes1=endTime1.substring(0,10).split('-');
			beginTime1=beginTimes1[1]+'-'+beginTimes1[2]+'-'+beginTimes1[0]+' '+beginTime1.substring(10,19);
			endTime1=endTimes1[1]+'-'+endTimes1[2]+'-'+endTimes1[0]+' '+endTime1.substring(10,19);
			var a=(Date.parse(endTime1)-Date.parse(beginTime1))/3600/1000;
			if(a>0){
				return true;
			};
		};
		return false;
	};
	game.openTask=function(){
		var dialog1={};
		var background=ui.create.dialog('hidden');
		//background.classList.add('popped');
		//background.classList.add('static');
		background.style.height='calc(100%)';
		background.style.width='calc(100%)';
		background.style.left='0px';
		background.style.top='0px';
		ui.window.appendChild(background);
		dialog1.background=background;
		var b=ui.create.dialog('hidden');
		b.style.height='calc(50%)';
		if(lib.device) b.style.height='calc(56%)';
		b.style.width='590px';
		b.style.left='calc(50% - 295px)';
		b.style.top='calc(25%)';
		b.classList.add('popped');
		b.classList.add('static');
		b.setBackgroundImage('extension/扩展ol/Background1.jpg');
		b.style.backgroundSize="cover";
		ui.window.appendChild(b);
		dialog1.b=b;
		for(var i in lib.kzol_task){
			var tasks=lib.kzol_task;
			var task=tasks[i];
			if(game.checkTime(task.time.b,task.time.e)&&(lib.config.kzol_task[i]==undefined||lib.config.kzol_task[i]<task.limit_times)){
				var str1='';
				for(var j in task.reward){
					str1+=get.translation(j)+'X'+task.reward[j]+'、';
				};
				if(str1!='') str1=str1.slice(0,str1.length-1);
				if(task.reward_info!=undefined) str1+=task.reward_info;
				var str='';
				str+='<span style="font-family:xinwei;white-space:pre;color:#FFFFFF;">'+'<span style="font-size:25px;font-weight:600;">'+i+'</span>'+'<br>'+task.info+'<br><br> '+'完成条件：<br> '+task.condition_info+'<br><br> '+'奖励：<br> '+str1+'<br><br> 限制时间：<br> '+task.time.b+'至'+task.time.e+'</span><br><br><br>';
				var task1=ui.create.div('',str);
				task1.style.textAlign='left';
				task1.style.display='table';
				task1.style.width='575px';
				task1.style.top='13px';
				task1.style.borderRadius='3px';
				//task1.setBackgroundImage('extension/扩展ol/Background3.jpg');
				//task1.style.backgroundSize="cover";
				//task1.style.backgroundColor="#E00000";
				task1.style.background='rgba(0,0,0,0.4)';
				task1.style.border='2px solid black';
				b.add(task1);
				var str2='<span style="cursor:pointer;color:#FFFFFF;">未完成</span>';
				if(task.condition()) str2='<span style="cursor:pointer;color:#FFFFFF;">领取奖励</span>';
				func=function(){
					var task=this.link;
					if(task.condition()){
						if(task.reward!=undefined){
							for(var j in task.reward){
								game.gainItem(j,task.reward[j]);
						};
						};
						if(task.finished_func!=undefined) task.finished_func();
						if(lib.config.kzol_task[this.link2]==undefined) lib.config.kzol_task[this.link2]=0;
						lib.config.kzol_task[this.link2]++;
						game.saveConfig('kzol_task',lib.config.kzol_task);
						if(!task.condition()||lib.config.kzol_task[this.link2]>=task.limit_times){
							if(lib.config.kzol_task[this.link2]>=task.limit_times){
								this.innerHTML='<span style="cursor:pointer;color:#FFFFFF;">已达上限</span>';
							}else{
								this.innerHTML='<span style="cursor:pointer;color:#FFFFFF;">未完成</span>';
							};
						};
						if(lib.config.kzol_task[this.link2]>=task.limit_times) this.link1.delete();
					}else if(lib.config.kzol_task[this.link2]>=task.limit_times){
						game.say1('该任务完成次数已达上限');
					}else{
						game.say1('未完成该任务');
					};
				};
				var finish_button=ui.create.div('',str2,func);
				finish_button.style['font-size']='30px';
				finish_button.style['line-height']='40px';
				finish_button.style['font-family']="'STXinwei','xinwei'";
				finish_button.style['background-image']='linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4))';
				finish_button.style['box-shadow']='rgba(0, 0, 0, 0.4) 0 0 0 1px, rgba(0, 0, 0, 0.2) 0 3px 10px';
				finish_button.style['text-align']='center';
				finish_button.style.height='40px';
				finish_button.style.width='120px';
				finish_button.style.borderRadius='8px';
				task1.appendChild(finish_button);
				finish_button.style.bottom='10px';
				finish_button.style.right='10px';
				finish_button.link=task;
				finish_button.link1=task1;
				finish_button.link2=i;
			};
		};
		var t=ui.create.dialog('hidden','<span style="color:#FFFFFF;font-size:23px;font-weight:600;font-family:xinwei">任务</span>');
		t.style.height='55px';
		t.style.width='150px';
		t.style.left='calc(50% - 75px)';
		t.style.top='calc(25% - 37px)';
		t.classList.add('popped');
		t.classList.add('static');
		t.setBackgroundImage('extension/扩展ol/Background2.jpg');
		t.style.backgroundSize="cover";
		ui.window.appendChild(t);
		dialog1.t=t;
		var div=ui.create.div();
		div.style.height='1000px';
		div.style.width='1000px';
		div.style.left='-10px';
		div.style.top='-10px';
		var func1=function(){
			for(var i in dialog1){
				dialog1[i].delete();
				delete dialog1[i];
			};
		};
		setTimeout(function(){
			div.onclick=function(){
				func1();
			};
		},750);
		background.add(div);
	};
	lib.extensionMenu.extension_扩展ol.task_title={
		"name":"<b><p align=center><span style=\"font-size:18px\">-----任务功能-----</span></b>",
		"clear":true,
		"nopointer":true,
	};
	lib.extensionMenu.extension_扩展ol.task_openTask={
		'name':'任务界面<div>&gt;</div>',
		"clear":true,
		onclick:function(){
			ui.click.configMenu();
			game.openTask();
		},
	};
}