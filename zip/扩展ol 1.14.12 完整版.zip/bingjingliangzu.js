window.func=function(lib,game,ui,get,ai,_status){
	if(lib.config.kzol_bingjingliangzu==undefined) game.saveConfig('kzol_bingjingliangzu','identity');
	if(lib.brawl) {
		game.bingjingliangzuSZ=false;
		lib.brawl.bingjingliangzu={
			name:'兵精粮足',
			mode:lib.config.kzol_bingjingliangzu,
			//submode:lib.config.kzol_bingjingliangzu1,
			intro:[
				'游戏开始时，所有人获得一点体力上限并恢复一点体力',
				'所有人摸牌阶段多摸一张牌，出牌阶段可以额外使用一张杀',
			],
			showcase:function(init){
				if(game.bingjingliangzuSZ!=true){
					var div=ui.create.div();
					div.style.height='20px';
					div.style.width=this.style.width;
					div.style.left='0px';
					div.style.top='-12.5px';
					//div.innerHTML='请选择兵精粮足的战斗模式：<select id="bingjingliangzu_choose" size="1" style="width:80px"><option value=identity>身份模式</option><option value=guozhan>国战模式</option></option></option><option value=2v2>2v2</option><option value=3v3>3v3</option><option value=3v3>4v4</option></select>';
					div.innerHTML='请选择兵精粮足的战斗模式：<select id="bingjingliangzu_choose" size="1" style="width:80px"><option value=identity>身份模式</option><option value=guozhan>国战模式</option></select>';
					this.appendChild(div);
					var div1=ui.create.div('','<span style="cursor:pointer;">确认</span>');
					div1.style.height='40px';
					div1.style.width=this.style.width;
					div1.style.left='0px';
					div1.style.top='10px';
					div1.style.zIndex="999";
					div1.onclick=function(){
						var choice=document.getElementById('bingjingliangzu_choose');
						var choice1=choice.options[choice.selectedIndex].value;
						if(choice1=='identity'||choice1=='guozhan'||choice1=='partner'){
							game.saveConfig('kzol_bingjingliangzu',choice1);
							game.saveConfig('kzol_bingjingliangzu1',undefined);
						};
						if(choice1=='4v4'||choice1=='2v2'||choice1=='3v3'){
							game.saveConfig('kzol_bingjingliangzu','versus');
							game.saveConfig('kzol_bingjingliangzu1',choice1);
						};
						game.say1('设置成功，即将刷新游戏');
						setTimeout(function(){
							game.reload();
						},1500);
					};
					this.appendChild(div1);
					var bjlz=ui.create.div();
					bjlz.style.height='267px';
					bjlz.style.width='500px';
					bjlz.style.left='calc(50% - 250px)';
					bjlz.style.top='17.5px';
					bjlz.setBackgroundImage('extension/扩展ol/bjlz.png');
					this.appendChild(bjlz);
					game.bingjingliangzuSZ=true;
				};
			},
			content:{
				//submode:'two',
				gameStart:function(){
					for(var i=0;i<game.players.length;i++){
						game.players[i].gainMaxHp();
						game.players[i].recover();
					};
				},
			},
			init:function(){
				game.saveConfig('identity_mode','normal','identity');
				lib.skill._mopaishuzengjia={
					trigger:{
						player:"phaseDrawBegin",
					},
					forced:true,
					content:function (){
						trigger.num++;
					},
				};
				lib.skill._chushashuzengjia={
					mod:{
						cardUsable:function (card,player,num){
							if(card.name=='sha') return num+1;
						},
					},
				};
			},
		};
	};
}