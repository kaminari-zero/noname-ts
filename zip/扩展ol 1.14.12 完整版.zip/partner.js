window.func=function(lib,game,ui,get,ai,_status){
	if(lib.config.mode_config.partner==undefined){
		lib.config.mode_config.partner={};
		lib.config.mode_config.partner.mode='standard';
		lib.config.mode_config.partner.players=4;
		lib.config.mode_config.partner.chooseCharacterLimit='no';
		lib.config.mode_config.partner.chooseCharacterPriority='random';
		lib.config.mode_config.partner.chooseCharacterNumber=3;
	};
	game.addMode('partner',{
		start:function(){
			'step 0'
			/*var cssStyle=function(){
				var style=document.createElement('style');
				style.innerHTML="[data-number='10']>.player[data-position='1']{top:calc(200% / 3 - 145px);left:calc(95% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='2']{top:calc(100% / 3 - 120px);left:calc(95% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='3']{top:30px;left:calc(80% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='4']{top:5px;left:calc(65% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='5']{top:0;left:calc(50% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='6']{top:5px;left:calc(35% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='7']{top:30px;left:calc(20% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='8']{top:calc(100% / 3 - 120px);left:calc(5% - 75px);}";
				style.innerHTML+="[data-number='10']>.player[data-position='9']{top:calc(200% / 3 - 145px);left:calc(5% - 75px);}";
				document.head.appendChild(style);
			};
			cssStyle();*/
			'step 1'
			_status.mode=get.config('mode');
			game.prepareArena(get.config('players'));
			var num=1;
			for(var i=0;i<game.players.length;i++){
				var pl=game.players[i];
				pl.getId();
				pl.style.backgroundSize='100% 100%';
				pl.setBackgroundImage('extension/扩展ol/'+num+'.jpg');
				pl.identity=get.cnNumber(num);
				pl.setIdentity(get.cnNumber(num));
				if(num==1) pl.node.identity.dataset.color='zhu';
				if(num==2) pl.node.identity.dataset.color='friend';
				if(num==3) pl.node.identity.dataset.color='fan';
				if(num==4) pl.node.identity.dataset.color='zhong';
				if(num==5) pl.node.identity.dataset.color='nei';
				if((i+1)%2==0) num++;
			};
			'step 2'
			game.chooseCharacter();
			'step 3'
			event.trigger('gameStart');
			game.gameDraw();
			game.phaseLoop(game.players.randomGet());
		},
		game:{
			chooseCharacter:function(){
				var next=game.createEvent('chooseCharacter',false);
				next.showConfig=true;
				next.setContent(function(){
					"step 0"
					var num=get.config('chooseCharacterNumber');
					if(get.config('chooseCharacterPriority')=='yes'){
						event.bool=true;
					}else if(get.config('chooseCharacterPriority')=='no'){
						event.bool=false;
					}else{
						if(Math.random()<=0.5){
							event.bool=true;
						}else{
							event.bool=false;
						};
					};
					event.list1=[];
					event.list2=[];
					event.list3=[];
					for(var i in lib.character){
						if(lib.filter.characterDisabled(i)) continue;
						var sex=lib.character[i][0];
						if(sex=='male') event.list1.push(i);
						if(sex=='female') event.list2.push(i);
						event.list3.push(i);
					};
					if(event.bool==true){
						for(var i=0;i<game.players.length;i++){
							var pl=game.players[i];
							if(pl!=game.me&&pl.identity==game.me.identity){
								var character=event.list3.randomGet();
								event.player=pl;
								pl.init(character);
								var DY_sex=lib.character[character][0];
								if(DY_sex=='male') event.list1.remove(character);
								if(DY_sex=='female') event.list2.remove(character);
								event.list3.remove(character);
							};
						};
					};
					var list=[];
					if(get.config('chooseCharacterLimit')=='yixing'&&event.bool==true){
						if(DY_sex=='male') list=event.list2.randomGets(num);
						if(DY_sex=='female') list=event.list1.randomGets(num);
					}else if(get.config('chooseCharacterLimit')=='tongxing'&&event.bool==true){
						if(DY_sex=='male') list=event.list1.randomGets(num);
						if(DY_sex=='female') list=event.list2.randomGets(num);
					}else{
						list=event.list3.randomGets(num);
					};
					var str='';
					var str1='';
					var list1='';
					if(event.bool==true&&lib.perfectPair[character]!=undefined){
						var partner=lib.perfectPair[character];
						var list2=[];
						for(var i=0;i<partner.length;i++){
							var pr=partner[i];
							if(lib.character[pr]!=undefined){
								var sex=lib.character[pr][0];
								if(get.config('chooseCharacterLimit')=='yixing'){
									if(sex!=DY_sex) list2.push(pr);
								}else if(get.config('chooseCharacterLimit')=='tongxing'){
									if(sex==DY_sex) list2.push(pr);
								}else{
									list2.push(pr);
								};
							};
						};
					};
					if(list2!=undefined&&list2.length>0){
						str='随机武将';
						str1='珠联璧合武将';
						list1=[list2,'character'];
					};
					var dialog=ui.create.dialog('选择角色','hidden',str,[list,'character'],str1,list1);
					dialog.setCaption('选择角色');
					game.me.chooseButton(dialog,true).set('onfree',true);
					ui.create.cheat=function(){
						_status.createControl=ui.cheat2;
						ui.cheat=ui.create.control('更换',function(){
							if(ui.cheat2&&ui.cheat2.dialog==_status.event.dialog) return;
							if(game.changeCoin) game.changeCoin(-3);
							var buttons=ui.create.div('.buttons');
							var node=_status.event.dialog.buttons[0].parentNode;
							if(get.config('chooseCharacterLimit')=='yixing'&&event.bool==true){
								if(DY_sex=='male') list=event.list2.randomGets(num);
								if(DY_sex=='female') list=event.list1.randomGets(num);
							}else if(get.config('chooseCharacterLimit')=='tongxing'&&event.bool==true){
								if(DY_sex=='male') list=event.list1.randomGets(num);
								if(DY_sex=='female') list=event.list2.randomGets(num);
							}else{
								list=event.list3.randomGets(num);
							};
							_status.event.dialog.buttons=ui.create.buttons(list,'character',buttons);
							_status.event.dialog.content.insertBefore(buttons,node);
							buttons.animate('start');
							node.remove();
							game.uncheck();
							game.check();
						});
						delete _status.createControl;
					};
					ui.create.cheat();
					"step 1"
					ui.cheat.close();
					delete ui.cheat;
					var PL_character=result.buttons[0].link;
					game.me.init(PL_character);
					var PL_sex=lib.character[PL_character][0];
					if(PL_sex=='male') event.list1.remove(PL_character);
					if(PL_sex=='female') event.list2.remove(PL_character);
					event.list3.remove(PL_character);
					for(var i=0;i<game.players.length;i++){
						var pl=game.players[i];
						if(pl!=game.me&&pl!=event.player){
							if(get.config('chooseCharacterLimit')=='yixing'){
								if(game.countPlayer(function(current){return pl.identity==current.identity&&current.sex=='male'})>0){
									var character=event.list2.randomGet();
								}else if(game.countPlayer(function(current){return pl.identity==current.identity&&current.sex=='female'})>0){
									var character=event.list1.randomGet();
								}else{
									var character=event.list3.randomGet();
								};
							}else if(get.config('chooseCharacterLimit')=='tongxing'){
								if(game.countPlayer(function(current){return pl.identity==current.identity&&current.sex=='male'})>0){
									var character=event.list1.randomGet();
								}else if(game.countPlayer(function(current){return pl.identity==current.identity&&current.sex=='female'})>0){
									var character=event.list2.randomGet();
								}else{
									var character=event.list3.randomGet();
								};
							}else{
								var character=event.list3.randomGet();
							};
							pl.init(character);
							var sex=lib.character[character][0];
							if(sex=='male') event.list1.remove(character);
							if(sex=='female') event.list2.remove(character);
							event.list3.remove(character);
						};
					};
					setTimeout(function(){
						ui.arena.classList.remove('choose-character');
					},500);
				});
			},
		},
		element:{
			player:{
				dieAfter:function(source){
					var list=[];
					for(var i=0;i<game.players.length;i++){
						var pl=game.players[i];
						if(list.contains(pl.identity)) continue;
						list.push(pl.identity);
					};
					if(game.countPlayer(function(current){
						if(list.contains(current.identity)){
							list.remove(current.identity);
							return true;
						};
					})==1){
						if(game.me.isDead()){
							game.over(false);
						}else{
							game.over(true);
						};
					};
					if(source&&this.identity==source.identity) source.discard(source.get('he'));
					if(source&&this.identity!=source.identity) source.draw(2);
					if(_status.mode=='gongsi'){
						for(var i=0;i<game.players.length;i++){
							var pl=game.players[i];
							if(pl.identity==this.identity){
								pl.popup('同生共死');
								game.delay(0.75);
								if(source) source.line(pl);
								var die=pl.die();
								if(source) die.source=source;
							};
						};
					};
				},
			},
		},
		ai:{
			get:{
				attitude:function(from,to){
					if(from.identity==to.identity) return 5;
					return -1-game.countPlayer(function(current){return to.identity==current.identity})*3;
				},
			},
		},
	},{
		translate:'成对',
		extension:'扩展ol',
		config:{
			mode:{
				name:'游戏模式',
				init:'standard',
				item:{
					'standard':'标准',
					'jieyi':'结义',
					'gongsi':'共死',
				},
				frequent:true,
				restart:true,
			},
			players:{
				name:'游戏人数',
				init:4,
				item:{
					4:'2对',
					6:'3对',
					8:'4对',
					10:'5对',
					/*12:'6对',
					14:'7对',
					16:'8对',*/
				},
				frequent:true,
				restart:true,
			},
			chooseCharacterLimit:{
				name:'成对限制',
				init:'no',
				item:{
					'no':'无',
					'tongxing':'同性',
					'yixing':'异性',
				},
				frequent:true,
				restart:true,
			},
			chooseCharacterPriority:{
				name:'队友先选',
				init:'random',
				item:{
					'random':'随机',
					'yes':'是',
					'no':'否',
				},
				frequent:true,
				restart:true,
			},
			/*seat:{
				name:'座位排列',
				init:'lianhe',
				item:{
					'lianhe':'联合',
					'jiaoti':'交替',
				},
				frequent:true,
				restart:true,
			},*/
			chooseCharacterNumber:{
				name:'候选人数',
				init:3,
				item:{
					1:'1',
					2:'2',
					3:'3',
					4:'4',
					5:'5',
					6:'6',
				},
				frequent:true,
				restart:true,
			},
		},
	});
}