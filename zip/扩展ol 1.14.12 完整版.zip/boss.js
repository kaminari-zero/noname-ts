window.func = function (lib, game, ui, get, ai, _status) {
	if(lib.config.尸魂==undefined) game.saveConfig('尸魂',0);
	lib.group.push('nyhzrlong');
	lib.translate.nyhzrlong = '<span style="color:#FF7E15">龙</span>';
	if(lib.boss!=undefined){
		var boss1='mnyhzr灭世魔星BOSS';
		if(lib.boss[boss1]==undefined) lib.boss[boss1]={};
		lib.boss[boss1].control=function(type,control){
			if(type=='cancel'){
				if(!control.classList.contains('glow')) return;
				game.uncheck();
				game.check();
			}else{
				var control=ui.create.control('尸魂换水晶',function(){
					if(lib.config.尸魂>0){
						var num=lib.config.尸魂;
						if(confirm('是否用'+num+'个尸魂换取'+(num*10)+'水晶？')){
							game.say1('失去了所有尸魂');
							game.gainItem('shuijing',lib.config.尸魂*10);
							game.saveConfig('尸魂',0);
						};
					}else{
						game.say1('尸魂不足');
					};
				});
				return control;
			};
		};
	};
	game.addCharacterPack({
		characterSort: {
			'mode_extension_<span style=\"font-size:17px;font-weight:600\">扩展ol-BOSS</span>': {
				'nyhzrlielong': ['nyhzrlielong', 'nyhzr火龙', 'nyhzr水龙', 'nyhzr雷龙', 'nyhzr土龙', 'nyhzr木龙', 'nyhzr风龙', 'nyhzr冰龙'],
				'mnyhzr灭世魔星BOSS': ['mnyhzr灭世魔星BOSS', 'nyhzr小僵尸'],
			},
		},
		character: {
			"nyhzrlielong":["male","",' ',["nyhzrlielong1"],['forbidai','boss','bossallowed','des:不同日子出现不同属性的龙'],'wu'],
			"nyhzr火龙":["male","nyhzrlong",7,["lielonghuolongjia","lielongweiyan","lielongbaoyan","niepan"],['forbidai']],
			"nyhzr水龙":["male","nyhzrlong",6,["lielongshuilongjia","lielongshilan","lielongxuanwo","lielonghaige","lielongjiliu"],['forbidai']],
			"nyhzr雷龙":["male","nyhzrlong",3,["lielongleilongjia","lielongjilei","lielongqianniao","lielongchaofu"],['forbidai']],
			"nyhzr土龙":["male","nyhzrlong",12,["lielongtulongjia","lielongmoyan","lielonghuachen","lielongdinu"],['forbidai']],
			"nyhzr木龙":["male","nyhzrlong",9,["lielongmulongjia","lielonglongxi","lielongduhua","lielongshenggen"],['forbidai']],
			"nyhzr风龙":["male","nyhzrlong",8,["lielongfenglongjia","lielongfengbao","lielongfengdun","lielongfengshi"],['forbidai']],
			"nyhzr冰龙":["male","nyhzrlong",5,["lielongbinglongjia","lielonghanxi","lielonghangu","lielongyondong"],['forbidai']],
			"mnyhzr灭世魔星BOSS":["male","li",'',["nyhzr亡者之碑BOSS","nyhzr小僵尸BOSS"],['ext:扩展ol/mnyhzr灭世魔星.jpg','forbidai','boss','bossallowed','des:<li>并不是每一个婴孩的诞生都得到祝福，犼面锁灵想起初见破靡的景象，一念竟觉已千年。<li>是时魔星出世，天象异乱，来自于太虚混沌的上神们急于知寻襁褓下落，围攻走影谷。破靡双亲虽贵为尸王尸后，也难敌神罚，不死之身归于尘土。谷中密道内通洪流，怒江之水直逼外界天地，肤体冥蓝的婴孩安睡于骨床中顺流疾走，周身尸气盘附，水不沾襟。上神们逐密道而出，却看那安胎骨床经过之处水流一退千里，河岸接壤处草被衰败，这刚出世的尸气便要枯了一整条水路，好在方圆几里渺无人畜，上神们及时截下这灭世胎，护天地人间一份安宁。<li>尸者，集天界晦气,取阴界死气,汇人界怨气而生。僵尸与僵尸所诞之子，溶混沌为体肉，赤瞳冥肤，无魄却任可生长，有别于一般走尸，唤为魔星。所幸世上仅会存有一位魔星，破靡不死，便无后者。上神们为绝后患，决定以神力铸成犼面锁缠绕骨床，贴附上古灵文封印魔星尸气，使其不生不长，永为婴孩，隐于落神坡。<li>当犼面锁因神力产生灵识之时，它陪护破靡已有数百年，从锁孔释放幽蓝色魂光，生成双手，小心翼翼地包裹着破靡。怀里的婴孩由于封印已无尸气，柔弱地好似一般胎儿，时而清醒，因双手被缠住有些恼怒，锁灵便偷偷放松链条，让他动个快活，这泼劲差点没把符文给撕扯坏；如若昏睡，锁灵便为他挡雨遮阳，驱虫赶兽，图个安眠。年华见长，符文越发残破，封印渐失，锁链被尸气灼断，本应及时向上神传信的锁灵，却有了心事，看着魔星从牙牙学语到少年模样，一拖再拖。不知是天资过人还是其他，破靡学话极快，缠着锁灵说自己会乖乖的不想再被捆着，心软彻底变为宠溺。<li>锁灵从初见继续想到破靡第一次落地。那时破靡跑到落神坡脚的花田，脚踏处花草枯竭，他开始意识到自己的尸气会给周围带来不幸，一路大跑直入锁灵怀抱哭诉，让尸气烧坏了犼面锁身的其他地方，发现后懊恼的趴在地上捶骂自己，他抬头，瞪着赤红大眼小心翼翼地问，“我以后还能抱你吗。”真是无可奈何，锁灵花了好久的功夫刚把这小东西哄好，破靡立马又被蛇吞兔吸引了注意，一个飞扑上前，用尸气让两者皆幻为走影，赋予永生，他拍拍蛇与兔的头告诫二位要友好往来，完后对锁灵挑着眉毛，“我的尸气有时候还是蛮有用的嘛！”。<li>眼下犼面锁身已千穿百孔，破靡忧心忡忡，碰也不是不碰也不是。锁灵暗暗决定要保护这个少年，哪怕要违逆上神，它也愿意相信自己所看到的纯粹。它对破靡说，“我的身已残败不堪，一旦损毁，上神便会有所感应。你虽有不死之身却盖不住尸气，而我的灵力可助你迷惑上神，无论你逃之何处，我只愿你童心依旧，天真长久。”语罢，魂光移体，那锁不再是锁，在灵气与尸气交融下越长越大，附着于破靡肩背，灵志尽失。<li>待合魂完毕，破靡方才露出一丝邪魅的笑容。对空一声口哨，唤来了尸蛇与兔，蹲下不耐烦地歪着头，听着尸兽的倾吐。末了兴奋地一拍腿，“找到村庄了？好啊，这场戏演了千年，终于可以吃人了。”<li>只见少年走向落神坡脚，信步缓缓，踩蔫了整片花田。'],'wei'],
			"nyhzr小僵尸":["male","li",3,['nyhzr迅猛','nyhzr噬魂'],['forbidai']],
		},
		skill: {
			"nyhzr尸王降世BOSS": {
				nobracket: true,
				enable: "phaseUse",
				usable: 1,
				filterCard: function (card) {
					return true;
				},
				check: function (card) {
					return 6 - ai.get.value(card);
				},
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i].name != 'mnyhzr灭世魔星BOSS') {
							if (game.players[i].name != 'nyhzr小僵尸') {
								game.players[i].damage();
							}
							else {
								game.players[i].recover();
							};
						}
						else {
							game.players[i].recover();
						};
					};
				},
				ai: {
					order: 8,
					result: {
						player: function (player, target) {
							return 1;
						},
					},
				},
			},
			"_timeLimit": {
				mode: ['boss'],
				trigger: {
					player: "phaseUseBegin",
				},
				forced: true,
				filter: function (event, player) {
					return player.storage.亡者之碑time != 1 && game.boss.name == 'mnyhzr灭世魔星BOSS';
				},
				content: function () {
					'step 0'
					_status.timeCount = 10;
					player.addTempSkill('_timeLimit_timeOver', 'phaseUseAfter');
				},
				subSkill: {
					timeOver: {
						trigger: {
							player: "useCardAfter",
						},
						popup: false,
						forced: true,
						content: function () {
							if (_status.timeCount <= 0) {
								delete _status.timeCount;
								game.stopCountChoose();
								var evt = _status.event;
								for (var i = 0; i < 10; i++) {
									if (evt && evt.getParent) {
										evt = evt.getParent();
									};
									if (evt.name == 'phaseUse') {
										evt.skipped = true;
										break;
									};
								};
							};
						},
					},
				},
			},
			"nyhzr迅猛": {
				nobracket: true,
				mod: {
					cardUsable: function (card, player, num) {
						if (card.name == 'sha') return Infinity;
					},
				},
				ai: {
					unequip: true,
					skillTagFilter: function (player, tag, arg) {
						if (!get.zhu(player, 'shouyue')) return false;
						if (arg && arg.name == 'sha') return true;
						return false;
					},
				},
				trigger: {
					player: "phaseDrawBegin",
				},
				forecd: true,
				content: function () {
					trigger.num++;
				},
			},
			"nyhzr噬魂": {
				nobracket: true,
				mode: ['boss'],
				trigger: {
					source: "damageAfter",
				},
				forced: true,
				content: function () {
					if (_status.亡者之碑time)_status.亡者之碑time += 4;
				},
			},
			"_nyhzr小僵尸minskinEquip": {
				mode: ['boss'],
				mod: {
					cardEnabled: function (card, player) {
						if (player.name == 'nyhzr小僵尸') {
							if (get.type(card) == 'equip') return true;
						}
					}
				}
			},
			"_nyhzr小僵尸minskinEquip1": {
				mode: ['boss'],
				trigger: {
					player: "equipBefore",
				},
				filter: function (event, player) {
					return player.name == 'nyhzr小僵尸';
				},
				forced: true,
				content: function () {
					player.classList.remove('minskin');
				},
			},
			"_nyhzr小僵尸minskinEquip2": {
				mode: ['boss'],
				trigger: {
					player: "equipAfter",
				},
				filter: function (event, player) {
					return player.name == 'nyhzr小僵尸';
				},
				forced: true,
				content: function () {
					player.classList.add('minskin');
				},
			},
			"nyhzr亡者之碑BOSS": {
				mode:['boss'],
				mod: {
					cardEnabled: function (card, player) {
						if (get.type(card) != 'equip' && player.storage.亡者之碑time != 1) return false;
					},
				},
				nobracket: true,
				trigger: {
					global: "gameStart",
				},
				forced: true,
				content: function () {
					game.countChoose=function(clear){
						if(_status.imchoosing){
							return;
						}
						_status.imchoosing=true;
						if(game.hasPlayer(function(target){return target.hasSkill('_timeLimit_timeOver')})&&!_status.countDown){
							ui.timer.show();
							var num=_status.timeCount;
								game.countDown(parseInt(num),function(){
								ui.timer.hide();
								delete _status.timeCount;
								game.stopCountChoose();
								var evt=_status.event;
								for(var i=0;i<10;i++){
									if(evt&&evt.getParent){
										evt=evt.getParent();
									}
									if(evt.name=='phaseUse'){
										evt.skipped=true;
										break;
									}
								}
								ui.click.auto();
							});
							if(!game.online&&game.me){
								if(_status.event.getParent().skillHidden){
									for(var i=0;i<game.players.length;i++){
										game.players[i].showTimer();
									}
									game.me._hide_all_timer=true;
								}
								else if(!_status.event._global_waiting){
									game.me.showTimer();
								}
							}
						}
						if(_status.connectMode&&!_status.countDown){
						    ui.timer.show();
						    var num;
						    if(_status.connectMode){
						        num=lib.configOL.choose_timeout;
						    }
						    else{
						        num=get.config('choose_timeout');
						    }
						    game.countDown(parseInt(num),function(){
						        ui.click.auto();
						        ui.timer.hide();
						    });
						    if(!game.online&&game.me){
						        if(_status.event.getParent().skillHidden){
						            for(var i=0;i<game.players.length;i++){
						                game.players[i].showTimer();
						            }
						            game.me._hide_all_timer=true;
						        }
						        else if(!_status.event._global_waiting){
						            game.me.showTimer();
						        }
						    }
						}
					};
					player.die = function (all) {},
					player.init = function (all) {},
					player.storage.nyhzr小僵尸BOSSadd = 0;
					game.bossinfo.chongzheng = 0;
					var 亡者之碑 = ui.create.player(null, true);亡者之碑.node.avatar.style.backgroundSize = 'cover';
					亡者之碑.node.avatar.setBackgroundImage('extension/扩展ol/亡者之碑.png');
					亡者之碑.node.avatar.show();
					亡者之碑.style.left = 'calc(45% - 75px)';
					亡者之碑.style.top = 'calc(40%)';
					亡者之碑.node.count.remove();
					亡者之碑.node.hp.remove();
					亡者之碑.classList.add('minskin');
					var nyhzr亡者之碑BOSSD = ui.create.div('', '');
					nyhzr亡者之碑BOSSD.innerHTML = '<span style="cursor:pointer;">尸魂：' + lib.config.尸魂 + '/100</span>';
					nyhzr亡者之碑BOSSD.style.left = '8px';
					nyhzr亡者之碑BOSSD.style.top = '6px';
					setInterval(function () {
						nyhzr亡者之碑BOSSD.innerHTML = '<span style="cursor:pointer;">尸魂：' + lib.config.尸魂 + '/100</span>';
						if (lib.config.尸魂 >= 100) {
							lib.config.kzol_jswj.mnyhzr灭世魔星=true;
							game.saveConfig('kzol_jswj', lib.config.kzol_jswj);
							game.say1('获得武将——灭世魔星');
							game.saveConfig('尸魂', lib.config.尸魂 - 100);
						};
					}, 100);
					亡者之碑.appendChild(nyhzr亡者之碑BOSSD);
					ui.window.appendChild(亡者之碑);亡者之碑.node.name.innerHTML = '<br><br><br>第一阶段';亡者之碑.node.name.style.fontFamily = 'huangcao';
					player.maxHp = Infinity;
					player.hp = Infinity;
					player.update();
					player.node.hp.hide();
					player.addSkill('qianxing');
					player.node.action.classList.add('freecolor');
					player.node.action.style.opacity = 1;
					player.node.action.style.letterSpacing = '4px';
					player.node.action.style.marginRight = 0;
					player.node.action.style.fontFamily = 'huangcao';
					player.node.action.innerHTML = '';
					_status.亡者之碑time = 240;
					var interval = setInterval(function () {
						if (_status.over) {
							clearInterval(interval);
							return;
						}
						var sec = _status.亡者之碑time % 60;
						if (sec < 10) {
							sec = '0' + sec;
						}
						player.node.action.innerHTML = Math.floor(_status.亡者之碑time / 60) + ':' + sec;
						if (_status.亡者之碑time <= 0 && player.storage.亡者之碑time != 1) {
							player.removeSkill('qianxing');亡者之碑.node.name.innerHTML = '<br><br><br>第二阶段';
							player.node.hp.show();
							player.maxHp = 10;
							if (4 + player.storage.nyhzr小僵尸BOSSadd > 10) {
								player.hp = 10;
								player.changeHujia(player.storage.nyhzr小僵尸BOSSadd - 6)
							}
							else {
								player.hp = 4 + player.storage.nyhzr小僵尸BOSSadd;
							};
							player.update();
							player.removeSkill('nyhzr小僵尸BOSS');
							player.storage.亡者之碑time = 1;
							player.addSkill('nyhzr生命凋零ol');
							player.addSkill('nyhzr尸王降世BOSS');
							for (var i = 0; i < game.players.length; i++) {
								if (game.players[i] != player && game.players[i].name != 'nyhzr小僵尸') {
									game.players[i].recover(2);
									game.players[i].draw(3);
								};
							};
							player.die = function () {
								if (_status.roundStart == player) {
									_status.roundStart = player.next || player.getNext() || game.players[0];
								}
								var unseen = false;
								if (player.classList.contains('unseen')) {
									player.classList.remove('unseen');
									unseen = true;
								}
								var logvid = game.logv(player, 'die', source);
								if (unseen) {
									player.classList.add('unseen');
								}
								if (source && source != player) {
									game.log(player, '被', source, '杀害');
									if (source.stat[source.stat.length - 1].kill == undefined) {
										source.stat[source.stat.length - 1].kill = 1;
									}
									else {
										source.stat[source.stat.length - 1].kill++;
									}
								}
								else {
									game.log(player, '阵亡')
								}
								event.cards = player.getCards('hej');
								event.playerCards = player.getCards('he');
								if (event.cards.length) {
									player.$throw(event.cards, 1000);
									game.log(player, '弃置了', event.cards, logvid);
								}
								if (!game.reserveDead) {
									for (var mark in player.marks) {
										player.unmarkSkill(mark);
									}
									while (player.node.marks.childNodes.length > 1) {
										player.node.marks.lastChild.remove();
									}
									game.broadcast(function (player) {
										while (player.node.marks.childNodes.length > 1) {
											player.node.marks.lastChild.remove();
										}
									}, player);
								}
								for (var i in player.tempSkills) {
									player.removeSkill(i);
								}
								var skills = player.getSkills();
								for (var i = 0; i < skills.length; i++) {
									if (lib.skill[skills[i]].temp) {
										player.removeSkill(skills[i]);
									}
								}
								player.removeEquipTrigger();
								game.broadcastAll(function (player, cards) {
									player.classList.add('dead');
									player.classList.remove('turnedover');
									player.classList.remove('out');
									player.node.count.innerHTML = '0';
									player.node.hp.hide();
									player.node.equips.hide();
									player.node.count.hide();
									player.previous.next = player.next;
									player.next.previous = player.previous;
									game.players.remove(player);
									game.dead.push(player);
									_status.dying.remove(player);

									for (var i = 0; i < cards.length; i++) {
										cards[i].goto(ui.discardPile);
									}
									if (game.online && player == game.me && !_status.over && !game.controlOver && !ui.exit) {
										if (lib.mode[lib.configOL.mode].config.dierestart) {
											ui.exit = ui.create.control('退出房间', ui.click.exit);
										}
									}

									if (lib.config.background_speak) {
										if (lib.character[player.name] && lib.character[player.name][4].contains('die_audio')) {
											game.playAudio('die', player.name);
										}
										else if (true) {
											game.playAudio('die', player.name, function () {
												game.playAudio('die', player.name.slice(player.name.indexOf('_') + 1));
											});
										}
									}
								}, player, event.cards);

								if (!_status.connectMode && player == game.me && !_status.over && !game.controlOver) {
									ui.control.show();
									if (get.config('revive') && lib.mode[lib.config.mode].config.revive && !ui.revive) {
										ui.revive = ui.create.control('revive', ui.click.dierevive);
									}
									if (get.config('continue_game') && !ui.continue_game && lib.mode[lib.config.mode].config.continue_game && !_status.brawl) {
										ui.continue_game = ui.create.control('再战', game.reloadCurrent);
									}
									if (get.config('dierestart') && lib.mode[lib.config.mode].config.dierestart && !ui.restart) {
										ui.restart = ui.create.control('restart', game.reload);
									}
								}

								if (!_status.connectMode && player == game.me && !game.modeSwapPlayer) {
									if (ui.auto) {
										ui.auto.hide();
									}
									if (ui.wuxie) ui.wuxie.hide();
								}
								game.addVideo('diex', player);
								if (event.animate !== false) {
									player.$die(source);
								}
								if (player.dieAfter) player.dieAfter(source);
								if (typeof _status.coin == 'number' && source && !_status.auto) {
									if (source == game.me || source.isUnderControl()) {
										_status.coin += 10;
									}
								}
								if (source && lib.config.border_style == 'auto' && (lib.config.autoborder_count == 'kill' || lib.config.autoborder_count == 'mix')) {
									switch (source.node.framebg.dataset.auto) {
										case 'gold':
										case 'silver':
											source.node.framebg.dataset.auto = 'gold';
											break;
										case 'bronze':
											source.node.framebg.dataset.auto = 'silver';
											break;
										default:
											source.node.framebg.dataset.auto = lib.config.autoborder_start || 'bronze';
									}
									if (lib.config.autoborder_count == 'kill') {
										source.node.framebg.dataset.decoration = source.node.framebg.dataset.auto;
									}
									else {
										var dnum = 0;
										for (var j = 0; j < source.stat.length; j++) {
											if (source.stat[j].damage != undefined) dnum += source.stat[j].damage;
										}
										source.node.framebg.dataset.decoration = '';
										switch (source.node.framebg.dataset.auto) {
											case 'bronze':
												if (dnum >= 4) source.node.framebg.dataset.decoration = 'bronze';
												break;
											case 'silver':
												if (dnum >= 8) source.node.framebg.dataset.decoration = 'silver';
												break;
											case 'gold':
												if (dnum >= 12) source.node.framebg.dataset.decoration = 'gold';
												break;
										}
									}
									source.classList.add('topcount');
								}
							};
						}
						if (player.storage.亡者之碑time == 1) player.node.action.innerHTML = '';
						if(_status.paused2==false) _status.亡者之碑time--;
					}, 1000);
				},
			},
			"nyhzr小僵尸BOSS": {
				mode:['boss'],
				nobracket: true,
				trigger: {
					player: "phaseEnd",
				},
				forced: true,
				filter: function (event, player) {
					return player.storage.nyhzr小僵尸BOSS1 != false || player.storage.nyhzr小僵尸BOSS2 != false || player.storage.nyhzr小僵尸BOSS3 != false;
				},
				content: function () {
					if (player.storage.nyhzr小僵尸BOSS1 != false) {
						player.storage.nyhzr小僵尸BOSSadd++;
						if (_status.亡者之碑time)_status.亡者之碑time -= 10;
						var fellow = game.addFellow(1, 'nyhzr小僵尸');
						fellow.style.left = 'calc(55% - 75px)';
						fellow.style.top = 'calc(25%)';
						fellow.classList.add('minskin');
						fellow.side = player.side;
						fellow.identity = player.identity;
						if (fellow.identity == 'zhu') fellow.identity = 'zhong';
						fellow.setIdentity('僵尸');
						fellow.node.identity.dataset.color = 'zhu';
						fellow.draw(1);
						fellow.addSkill('undist');
						fellow.storage.nyhzr小僵尸BOSS1 = false;
						player.storage.nyhzr小僵尸BOSS1 = false;
					};
					if (player.storage.nyhzr小僵尸BOSS2 != false) {
						player.storage.nyhzr小僵尸BOSSadd++;
						if (_status.亡者之碑time)_status.亡者之碑time -= 10;
						var fellow = game.addFellow(1, 'nyhzr小僵尸');
						fellow.style.left = 'calc(40% - 75px)';
						fellow.style.top = 'calc(50%)';
						fellow.classList.add('minskin');
						fellow.side = player.side;
						fellow.identity = player.identity;
						if (fellow.identity == 'zhu') fellow.identity = 'zhong';
						fellow.setIdentity('僵尸');
						fellow.node.identity.dataset.color = 'zhu';
						fellow.draw(1);
						fellow.addSkill('undist');
						fellow.storage.nyhzr小僵尸BOSS2 = false;
						player.storage.nyhzr小僵尸BOSS2 = false;
					};
					if (player.storage.nyhzr小僵尸BOSS3 != false) {
						player.storage.nyhzr小僵尸BOSSadd++;
						if (_status.亡者之碑time)_status.亡者之碑time -= 10;
						var fellow = game.addFellow(1, 'nyhzr小僵尸');
						fellow.style.left = 'calc(35% - 75px)';
						fellow.style.top = 'calc(20%)';
						fellow.classList.add('minskin');
						fellow.side = player.side;
						fellow.identity = player.identity;
						if (fellow.identity == 'zhu') fellow.identity = 'zhong';
						fellow.setIdentity('僵尸');
						fellow.node.identity.dataset.color = 'zhu';
						fellow.draw(1);
						fellow.addSkill('undist');
						fellow.storage.nyhzr小僵尸BOSS3 = false;
						player.storage.nyhzr小僵尸BOSS3 = false;
					};
				},
			},
			"_nyhzr小僵尸BOSS1": {
				mode: ['boss'],
				trigger: {
					player: 'dieBefore'
				},
				filter: function (event, player) {
					return player.name == 'nyhzr小僵尸';
				},
				forced: true,
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i].name == 'mnyhzr灭世魔星BOSS') {
							if (player.storage.nyhzr小僵尸BOSS1 == false) game.players[i].storage.nyhzr小僵尸BOSS1 = true;
							if (player.storage.nyhzr小僵尸BOSS2 == false) game.players[i].storage.nyhzr小僵尸BOSS2 = true;
							if (player.storage.nyhzr小僵尸BOSS3 == false) game.players[i].storage.nyhzr小僵尸BOSS3 = true;
						};
					};
				},
			},
			"nyhzrlielong1": {
				nobracket: true,
			},
			"_nyhzrlielong2": {
				trigger: {
					global: "gameStart",
				},
				forced: true,
				popup: false,
				filter: function (event, player) {
					return player.hasSkill('nyhzrlielong1');
				},
				content: function () {
					if (new Date().getDay() == 1) {
						player.init('nyhzr火龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 4;
					};
					if (new Date().getDay() == 2) {
						player.init('nyhzr水龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 10;
					};
					if (new Date().getDay() == 3) {
						player.init('nyhzr雷龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 5;
					};
					if (new Date().getDay() == 4) {
						player.init('nyhzr土龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 20;
					};
					if (new Date().getDay() == 5) {
						player.init('nyhzr木龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 5;
					};
					if (new Date().getDay() == 6) {
						player.init('nyhzr风龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 8;
					};
					if (new Date().getDay() == 0) {
						player.init('nyhzr冰龙');
						if (game.bossinfo != undefined) game.bossinfo.chongzheng = 4;
					};
				},
			},
			"lielonghuolongjia": {
				group: ["lielonghuolongjia_heart", "lielonghuolongjia_diamond"],
				subSkill: {
					heart: {
						trigger: {
							target: "shaBefore",
						},
						forced: true,
						priority: 6,
						filter: function (event) {
							return event.card && event.card.name == 'sha' && get.suit(event.card) == 'heart'
						},
						content: function () {
							trigger.untrigger();
							trigger.finish();
						},
					},
					diamond: {
						trigger: {
							player: "damageBegin",
						},
						forced: true,
						filter: function (event, player) {
							return event.card && event.card.name == 'sha' && get.suit(event.card) == 'diamond'
						},
						content: function () {
							trigger.num -= 1;
						}
					},
				},
			},
			"lielongweiyan": {
				trigger: {
					global: "gameDrawBefore",
				},
				forced: true,
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != player) game.players[i].damage(1, 'fire');
					};
				},
			},
			"lielongbaoyan": {
				enable: "phaseUse",
				usable: 1,
				filterTarget: function (card, player, target) {
					return player != target;
				},
				content: function () {
					target.damage(3, 'fire');
					player.loseHp();
				},
				ai: {
					order: 5,
					result: {
						player: function (player, target) {
							return player.hp - 2;
						},
					},
				},
			},
			"lielongshuilongjia": {
				trigger: {
					player: "damageBegin",
				},
				forced: true,
				filter: function (event, player) {
					return event.nature == 'fire';
				},
				content: function () {
					trigger.num -= 1;
				}
			},
			"lielongshilan": {
				trigger: {
					global: "phaseBefore",
				},
				forced: true,
				filter: function (event, player) {
					return event.player != player;
				},
				content: function () {
					'step 0'
					var list = ['流失一点体力'];
					if (trigger.player.num('h') >= 1) list.push('弃置一张手牌');
					trigger.player.chooseControl(list).set('ai', function () {
						if (trigger.player.num('h') >= 1) return '弃置一张手牌'
						return '流失一点体力'
					});
					'step 1'
					if (result.control == '流失一点体力') trigger.player.loseHp();
					if (result.control == '弃置一张手牌') trigger.player.chooseToDiscard(1, 'h', true);
				}

			},
			"lielongxuanwo": {
				trigger: {
					player: "changeHp",
				},
				direct: true,
				filter: function (event, player) {
					return event.num != 0;
				},
				content: function () {
					"step 0"
					player.chooseTarget(get.prompt('lielongxuanwo'), function (card, player, target) {
						return player != target
					}).ai = function (target) {
						if (target.hasSkillTag('noturn')) return 0;
						var player = _status.event.player;
						if (get.attitude(_status.event.player, target) == 0) return 0;
						if (get.attitude(_status.event.player, target) > 0) {
							if (target.classList.contains('turnedover')) return 1000 - target.countCards('h');
							if (player.maxHp - player.hp < 3) return -1;
							return 100 - target.countCards('h');
						}
						else {
							if (target.classList.contains('turnedover')) return -1;
							if (player.maxHp - player.hp >= 3) return -1;
							return 1 + target.countCards('h');
						}
					}
					"step 1"
					if (result.bool) {
						player.logSkill('lielongxuanwo', result.targets);
						result.targets[0].draw(result.targets[0].maxHp - result.targets[0].hp);
						result.targets[0].turnOver();
					}
				},
				ai: {
					effect: {
						target: function (card, player, target) {
							if (get.tag(card, 'damage')) {
								if (player.hasSkillTag('jueqing', false, target)) return [1, -2];
								if (target.hp <= 1) return;
								if (!target.hasFriend()) return;
								var hastarget = false;
								var turnfriend = false;
								var players = game.filterPlayer();
								for (var i = 0; i < players.length; i++) {
									if (get.attitude(target, players[i]) < 0 && !players[i].isTurnedOver()) {
										hastarget = true;
									}
									if (get.attitude(target, players[i]) > 0 && players[i].isTurnedOver()) {
										hastarget = true;
										turnfriend = true;
									}
								}
								if (get.attitude(player, target) > 0 && !hastarget) return;
								if (turnfriend || target.hp == target.maxHp) return [0.5, 1];
								if (target.hp > 1) return [1, 0.5];
							}
						},
					},
				},
			},
			"lielonghaige": {
				trigger: {
					player: "phaseEnd",
				},
				forced: true,
				content: function () {
					player.useCard({
						name: 'tao'
					}, player);;
				}
			},
			"lielongjiliu": {
				init: function (player) {
					player.storage.lielongjiliu = 0;
				},
				marktext: "激",
				intro: {
					content: function (storage) {
						return '当前拥有' + storage + '个激流标记'
					},
				},
				mark: true,
				group: ["lielongjiliu_lose", "lielongjiliu_use"],
				subSkill: {
					lose: {
						trigger: {
							player: 'loseAfter'
						},
						filter: function (event, player) {
							return _status.currentPhase != player;
						},
						forced: true,
						content: function () {
							player.storage.lielongjiliu++;
							player.syncStorage('lielongjiliu');
						}
					},
					use: {
						enable: "phaseUse",
						filterTarget: function (card, player, target) {
							return target != player;
						},
						filter: function (event, player) {
							return player.storage.lielongjiliu > 0;
						},
						content: function () {
							target.damage(player.storage.lielongjiliu);
							player.storage.lielongjiliu = 0;
							player.syncStorage('lielongjiliu');
						},
						ai: {
							order: 9,
							result: {
								player: function (player) {
									return 1;
								},
							},
						},
					},
				},
			},
			"lielongleilongjia": {
				trigger: {
					player: "damageBegin",
				},
				forced: true,
				filter: function (event, player) {
					return event.card && get.color(event.card) == 'black'
				},
				content: function () {
					trigger.untrigger();
					trigger.finish();
				}
			},
			"lielongjilei": {
				group: ["lielongjilei_Begin", "lielongjilei_After"],
				subSkill: {
					Begin: {
						trigger: {
							player: "phaseDrawBegin",
						},
						forced: true,
						content: function () {
							trigger.num += player.hp;
						},
					},
					After: {
						trigger: {
							player: "phaseDrawAfter",
						},
						forced: true,
						filter: function (event, player) {
							return player.num('h') > player.hp * 2
						},
						content: function () {
							player.skip('phaseUse');
							player.skip('phaseDiscard');
							for (var i = 0; i < game.players.length; i++) {
								if (game.players[i] != player) game.players[i].damage(1, 'thunder');
							};
						},
					},
				},
			},
			"lielongqianniao": {
				trigger: {
					player: "damageAfter",
				},
				filter: function (event, player) {
					return event.source && _status.currentPhase != player && player.num('h') >= 2;
				},
				content: function () {
					player.chooseToDiscard(2, 'h', true);
					trigger.source.damage(2, 'thunder');
				}
			},
			"lielongchaofu": {
				trigger: {
					player: "phaseBegin",
				},
				forced: true,
				filter: function (event, player) {
					return player.hp == 1;
				},
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != player) player.useCard({
							name: 'sha',
							nature: 'thunder'
						}, game.players[i]);
					};
					player.recover();
				}
			},
			"lielongtulongjia": {
				group: ["lielongtulongjia_card", "lielongtulongjia_loseHp"],
				subSkill: {
					card: {
						trigger: {
							player: "damageBegin",
						},
						forced: true,
						filter: function (event, player) {
							return event.card && (event.card.name == 'nanman' || event.card.name == 'wanjian')
						},
						content: function () {
							trigger.untrigger();
							trigger.finish();
						}
					},
					loseHp: {
						trigger: {
							player: "loseHpBegin",
						},
						forced: true,
						content: function () {
							trigger.num++;
						}
					},
				},
			},
			"lielongmoyan": {
				trigger: {
					player: "damageAfter",
				},
				forced: true,
				filter: function (event, player) {
					return event.nature;
				},
				content: function () {
					if (trigger.nature == 'fire') player.chooseToDiscard(2, 'h', true);
					if (trigger.nature == 'thunder') player.draw();
				}
			},
			"lielonghuachen": {
				unique: true,
				mark: true,
				skillAnimation: true,
				animationStr: "化尘",
				animationColor: "thunder",
				enable: "phaseUse",
				init: function (player) {
					player.storage.lielonghuachen = false;
				},
				filter: function (event, player) {
					if (player.storage.lielonghuachen) return false;
					return true;
				},
				filterTarget: function (card, player, target) {
					return player != target;
				},
				content: function () {
					player.awakenSkill('lielonghuachen');
					player.storage.lielonghuachen = true;
					player.loseHp();
					target.discard(target.get("he"));
					target.damage();
				},
				ai: {
					order: 13,
					result: {
						player: function (player, target) {
							return 1;
						},
					},
				},
				intro: {
					content: "limited",
				},
			},
			"lielongdinu": {
				trigger: {
					player: "phaseBegin",
				},
				forced: true,
				filter: function (event, player) {
					return player.hp < 5;
				},
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != player) player.useCard({
							name: 'nanman'
						}, game.players[i]);
					};
					player.recover();
				}
			},
			"lielongmulongjia": {
				trigger: {
					player: "damageBegin",
				},
				forced: true,
				content: function () {
					if (trigger.nature != 'fire') {
						trigger.untrigger();
						trigger.finish();
					}
					else {
						trigger.num++
					}
				}
			},
			"lielonglongxi": {
				trigger: {
					player: "phaseBegin",
				},
				forced: true,
				content: function () {
					if (player.hp <= 5) {
						player.recover();
					}
					else {
						for (var i = 0; i < game.players.length; i++) {
							if (game.players[i] != player) game.players[i].loseHp();
						};
					};
				}
			},
			"lielongduhua": {
				trigger: {
					player: "phaseEnd",
				},
				content: function () {
					"step 0"
					player.chooseTarget('选择【毒花】的目标', function (card, player, target) {
						return player != target
					}).ai = function (target) {
						return -ai.get.attitude(player, target)
					};
					"step 1"
					if (result.bool) {
						result.targets[0].damage();
						player.loseHp();
					}
					else {
						event.finish();
					}
				},
				check: function (event, player) {
					return player.hp > 3;
				},
			},
			"lielongshenggen": {
				unique: true,
				mark: true,
				skillAnimation: true,
				animationStr: "生根",
				enable: "phaseUse",
				init: function (player) {
					player.storage.lielongshenggen = false;
				},
				filter: function (event, player) {
					if (player.storage.lielongshenggen) return false;
					return true;
				},
				filterTarget: function (card, player, target) {
					return player != target;
				},
				content: function () {
					player.awakenSkill('lielongshenggen');
					player.storage.lielongshenggen = true;
					target.loseHp();
					player.storage.lielongshenggen1 = target.num('h');
					player.discard(player.get('h'));
					player.recover(2);
					player.addSkill('lielongshenggen1');
				},
				ai: {
					order: 1,
					result: {
						player: function (player, target) {
							if (player.hp <= 7) return 1;
							return 0;
						},
					},
				},
				intro: {
					content: "limited",
				},
			},
			"lielongshenggen1": {
				trigger: {
					player: "phaseEnd",
				},
				forced: true,
				content: function () {
					player.removeSkill("lielongshenggen1");
					player.draw(player.storage.lielongshenggen1);
					player.storage.lielongshenggen1 = 0;
				}
			},
			"lielongfenglongjia": {
				trigger: {
					player: "damageBegin",
				},
				forced: true,
				filter: function (event, player) {
					return event.nature;
				},
				content: function () {
					player.next.damage(trigger.nature);
					player.previous.damage(trigger.nature);
				},
			},
			"lielongfengbao": {
				mod: {
					cardUsable: function (card, player, num) {
						if (card.name == 'sha') return Infinity;
					},
				},
				enable: ['chooseToRespond', 'chooseToUse'],
				filterCard: function (card) {
					return get.color(card) == 'black';
				},
				position: 'he',
				viewAs: {
					name: 'sha',
					nature: 'thunder'
				},
				prompt: '将一张黑色牌当作雷杀使用或打出',
				ai: {
					respondSha: true,
				}
			},
			"lielongfengdun": {
				mod: {
					globalTo: function (from, to, distance) {
						return distance + 3;
					},
				},
			},
			"lielongfengshi": {
				trigger: {
					player: "useCardAfter",
				},
				filter: function (event, player) {
					return event.card.name == 'wanjian';
				},
				forced: true,
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != player) game.players[i].loseHp();
					};
				},
			},
			"lielongbinglongjia": {
				trigger: {
					player: "damageBefore",
				},
				forced: true,
				filter: function (event, player) {
					return event.source;
				},
				content: function () {
					trigger.source.discard(trigger.source.get('h'));
				},
			},
			"lielonghanxi": {
				trigger: {
					player: "phaseBefore",
				},
				forced: true,
				content: function () {
					game.players.randomGet(player).turnOver();
				},
			},
			"lielonghangu": {
				trigger: {
					player: "phaseAfter",
				},
				forced: true,
				content: function () {
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i].isTurnedOver()) {
							game.players[i].loseHp();
							game.players[i].discard(game.players[i].get('h'));
							player.recover();
						};
					};
				},
			},
			"lielongyondong": {
				unique: true,
				mark: true,
				skillAnimation: true,
				animationStr: "永冻",
				animationColor: "thunder",
				enable: "phaseUse",
				init: function (player) {
					player.storage.lielongyondong = false;
				},
				filter: function (event, player) {
					if (player.storage.lielongyondong) return false;
					return true;
				},
				content: function () {
					player.awakenSkill('lielongyondong');
					player.storage.lielongyondong = true;
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != player && !game.players[i].isTurnedOver()) game.players[i].turnOver();
					};
				},
				ai: {
					order: 1,
					result: {
						player: function (player, target) {
							return 1;
						},
					},
				},
				intro: {
					content: "limited",
				},
			},
			"_Gainshihun": {
				mode: ['boss'],
				trigger: {
					source: 'dieBefore'
				},
				filter: function (event, player) {
					return event.player.name == 'nyhzr小僵尸' && player.identity == game.me.identity;
				},
				forced: true,
				content: function () {
					var num=[1,2,3,4,5,6,7,8,9,10].randomGet();
					game.saveConfig('尸魂', lib.config.尸魂 + num);
					game.say1('获得'+num+'个尸魂');
				},
			},
		},
		translate: {
			"mnyhzr灭世魔星BOSS":"灭世魔星",
			"nyhzr小僵尸":"小僵尸",
            "nyhzr尸王降世BOSS":"尸王降世",
            "nyhzr尸王降世BOSS_info":"出牌阶段，你可以弃置一张手牌并对所有挑战者造成一点伤害，若如此做你与所有小僵尸恢复一点体力",
            "nyhzr亡者之碑BOSS":"亡者之碑",
            "nyhzr亡者之碑BOSS_info":"<span style=\"color:#EE7621\">被动：</span><br>游戏开始时，你放下亡者之碑，亡者之碑释放尸气，所有人无法重整",
            "nyhzr小僵尸BOSS":"小僵尸",
            "nyhzr小僵尸BOSS_info":"<span style=\"color:#EE7621\">被动：</span><br>回合结束阶段，若场上小僵尸数目不足三，你在亡者之碑附近召唤小僵尸至三只，每召唤一只小僵尸，第一阶段时间减少十秒",
            "nyhzr小僵尸BOSS_append":"<b><p align=center><span style=\"font-size:25px\">挑战规则</span></b><br><b><p align=center><span style=\"font-size:20px\">全部阶段</span></b><li>击杀小僵尸获得1-10个尸魂<li>尸魂达到100时，获得灭世魔星（武将）<li>当前拥有"+lib.config.尸魂+"个尸魂<br><b><p align=center><span style=\"font-size:20px\">第一阶段</span></b><li>灭世魔星处于无敌状态<li>灭世魔星处于潜行状态且无法使用除装备牌以外的牌<li>玩家的出牌时间变为10秒<li>第一阶段持续四分钟，挑战者需要在灭世魔星召唤的僵尸群中生存下来<br></b><br><b><p align=center><span style=\"font-size:20px\">第二阶段</span></b><li>灭世魔星失去技能【小僵尸】和【潜行】，获得技能【生命凋零】和【尸王降世】，体力上限变为10，体力变为4+X，X为第一阶段召唤的小僵尸数（体力大于10的部分转化为护甲）<li>所有挑战者恢复两点体力并摸三张牌",
            "nyhzr迅猛":"迅猛",
            "nyhzr迅猛_info":"<span style=\"color:#EE7621\">被动：</span><br>出牌阶段，你使用的【杀】没有数量限制<br>摸牌阶段，你多摸一张牌",
            "nyhzr噬魂":"噬魂",
            "nyhzr噬魂_info":"<span style=\"color:#EE7621\">被动：</span><br>挑战模式下，你每次造成伤害后，第一阶段增加四秒",
			"mnyhzr灭世魔星BOSS": "灭世魔星",
			"nyhzr小僵尸": "小僵尸",
			"nyhzr火龙": "火龙",
			"nyhzr水龙": "水龙",
			"nyhzr雷龙": "雷龙",
			"nyhzr土龙": "土龙",
			"nyhzr木龙": "木龙",
			"nyhzr风龙": "风龙",
			"nyhzr冰龙": "冰龙",
			"lielongbinglongjia": "龙甲",
			"lielongbinglongjia_info": "锁定技，当你受到伤害前，伤害来源弃置所有手牌",
			"lielonghanxi": "寒袭",
			"lielonghanxi_info": "锁定技，回合开始前，你随机令一名其他角色翻面",
			"lielonghangu": "寒骨",
			"lielonghangu_info": "锁定技，回合开始结束后，场上所有翻面角色流失一点体力并弃置所有手牌；场上每有一名翻面角色，你恢复一点体力",
			"lielonghangu": "寒骨",
			"lielonghangu_info": "锁定技，回合开始结束后，场上所有翻面角色流失一点体力并弃置所有手牌；场上每有一名翻面角色，你恢复一点体力",
			"lielongyondong": "永冻",
			"lielongyondong_info": "限定技，出牌阶段，你可以令所有其他未翻面的角色翻面",
			"lielongfenglongjia": "龙甲",
			"lielongfenglongjia_info": "锁定技，当你受到属性伤害时，你对你的上家与下家个造成一点属性伤害（属性为你受到的伤害属性）",
			"lielongfengbao": "风暴",
			"lielongfengbao_info": "你可以将一张黑色牌当作雷杀使用或打出<br>锁定技，出牌阶段，你使用的【杀】没有数量限制",
			"lielongfengdun": "风盾",
			"lielongfengdun_info": "锁定技，你的防御距离+3",
			"lielongfengshi": "风矢",
			"lielongfengshi_info": "锁定技，你使用【万箭齐发】后，其他角色流失一点体力",
			"lielongmulongjia": "龙甲",
			"lielongmulongjia_info": "锁定技，你不会受到非火焰伤害，你受到的火焰伤害+1",
			"lielonglongxi": "龙息",
			"lielonglongxi_info": "锁定技，准备阶段，若你的体力值不大于5，你恢复1点体力；若你的体力值大于5，你令其他角色流失一点体力",
			"lielongduhua": "毒花",
			"lielongduhua_info": "结束阶段，你可以对一名角色造成一点伤害，然后你失去一点体力",
			"lielongshenggen": "生根",
			"lielongshenggen1": "生根",
			"lielongshenggen_info": "限定技，出牌阶段，你可以弃置所有手牌并令一名角色流失一点体力，然后你恢复两点体力，若如此做，回合结束阶段，你摸X张牌（X为发动【生根】时，【生根】目标的手牌数，若目标死亡，你无法摸牌）",
			"lielongtulongjia": "龙甲",
			"lielongtulongjia_info": "锁定技，【南蛮入侵】和【万箭齐发】无法对你造成伤害；你流失体力时，流失量+1",
			"lielongmoyan": "魔岩",
			"lielongmoyan_info": "锁定技，当你受到雷属性伤害后，你摸一张牌，当你受到火属性伤害后，你弃置两张手牌",
			"lielonghuachen": "化尘",
			"lielonghuachen_info": "限定技，出牌阶段，你可以弃置一名角色手牌区和装备区内的所有牌，若如此做，你失去一点体力并对其造成一点伤害",
			"lielongdinu": "地怒",
			"lielongdinu_info": "锁定技，准备阶段，若你的体力值小于五，则视为你使用了1张【南蛮入侵】，然后你恢复一点体力",
			"lielonghuolongjia": "龙甲",
			"lielonghuolongjia_info": "锁定技，红桃【杀】对你无效，方片【杀】对你造成的伤害-1",
			"lielongweiyan": "威焰",
			"lielongweiyan_info": "锁定技，游戏开始时，你对所有其他角色造成一点火焰伤害",
			"lielongbaoyan": "爆炎",
			"lielongbaoyan_info": "回合开始阶段，你可以流失一点体力并对一名角色造成三点火焰伤害，每回合限一次",
			"lielongshuilongjia": "龙甲",
			"lielongshuilongjia_info": "锁定技，当你受到火焰伤害时，伤害-1",
			"lielongshilan": "噬浪",
			"lielongshilan_info": "锁定技，其他角色的回合开始前，其须选择一项：<br>1.弃置一张手牌<br>2.流失一点体力",
			"lielongxuanwo": "漩涡",
			"lielongxuanwo_info": "当你改变体力时，你可以将一名角色的武将牌翻面并令其摸X张牌。X为其当前已损失体力值",
			"lielonghaige": "海歌",
			"lielonghaige_info": "锁定技，结束阶段，你视为使用了一张【桃】",
			"lielongjiliu": "激流",
			"lielongjiliu_info": "锁定技，当你于回合外失去手牌后，你获得一个【激流】标记<br>出牌阶段，你可以清空【激流】标记，然后对一名角色造成X点伤害。X为“激流”牌的数量",
			"lielongleilongjia": "龙甲",
			"lielongleilongjia_info": "锁定技，你免疫黑色卡牌造成的伤害（免疫后仍可触发【千鸟】）",
			"lielongjilei": "疾雷",
			"lielongjilei_info": "锁定技，摸牌阶段，你多摸X张牌，若此时你的手牌数大于2X，你可以跳过出牌阶段和弃牌阶段并视为对所有其他角色造成一点雷电伤害。X为你当前体力值",
			"lielongqianniao": "千鸟",
			"lielongqianniao_info": "当你于回合外受到伤害后，你可以弃两张手牌牌并对伤害来源造成两点雷电伤害",
			"lielongchaofu": "超伏",
			"lielongchaofu_info": "锁定技，准备阶段，若你的体力值为一，你视为对所有其他角色使用了一张【雷杀】，然后你恢复一点体力",
			"nyhzrlielong": "猎龙战役",
			"nyhzrlielong1": "规则：",
			"nyhzrlielong1_info": "每天猎杀不同的龙",
			"nyhzrlielong1_append": '若今天是：<li>周一，猎火龙（4）<li>周二，猎水龙（10）<li>周三，猎雷龙（5）<li>周四，猎土龙（20）<li>周五，猎木龙（5）<li>周六，猎风龙（8）<li>周日，猎冰龙（4）<br>重整回合数为X<br>X为龙后面小括号内的数<br><br>猎杀当天的龙或猎龙方全军覆没，游戏结束',
		},
	}, '<span style=\"font-size:17px;font-weight:600\">扩展ol-BOSS</span>');
}