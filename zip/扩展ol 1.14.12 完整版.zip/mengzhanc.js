window.func=function(lib,game,ui,get,ai,_status){
	lib.element.player.mengzhanc_showCards=function(){
		var next=game.createEvent('mengzhanc_showCards');
		next.player=this;
		for(var i=0;i<arguments.length;i++){
			if(get.itemtype(arguments[i])=='cards'){
				next.cards=arguments[i];
			};
		};
		var event=_status.event;
		next.source=event.player;
		next.setContent(lib.element.event.mengzhanc_showCards);
		return next;
	};
	lib.element.event.mengzhanc_showCards=function(){
		event.trigger('mengzhanc_showCards');
		if(player.storage.mengzhanc_showCards==undefined) player.storage.mengzhanc_showCards=[];
		player.show(cards);
		for(var i=0;i<cards.length;i++){
			var card=cards[i];
			if(!player.storage.mengzhanc_showCards.contains(card)) player.storage.mengzhanc_showCards.push(card);
		};
		player.markSkill('mengzhanc_showCards');
		player.syncStorage('mengzhanc_showCards');
		game.log(player,'明置了',cards);
	};
	lib.element.player.mengzhanc_coverCards=function(){
		var next=game.createEvent('mengzhanc_coverCards');
		next.player=this;
		for(var i=0;i<arguments.length;i++){
			if(get.itemtype(arguments[i])=='cards'){
				next.cards=arguments[i];
			};
		};
		var event=_status.event;
		next.source=event.player;
		next.setContent(lib.element.event.mengzhanc_coverCards);
		return next;
	};
	lib.element.event.mengzhanc_coverCards=function(){
		event.trigger('mengzhanc_coverCards');
		if(player.storage.mengzhanc_showCards==undefined) player.storage.mengzhanc_showCards=[];
		for(var i=0;i<cards.length;i++){
			var card=cards[i];
			if(player.storage.mengzhanc_showCards.contains(card)) player.storage.mengzhanc_showCards.remove(card);
		};
		player.markSkill('mengzhanc_showCards');
		player.syncStorage('mengzhanc_showCards');
		if(player.storage.mengzhanc_showCards.length==0) player.unmarkSkill('mengzhanc_showCards');
		game.log(player,'暗置了',cards);
	};
	lib.element.player.mengzhanc_hasShownCards=function(){
		return this.storage.mengzhanc_showCards!=undefined&&this.storage.mengzhanc_showCards.length>0;
	};
	game.import('character',function(){
		var mengzhanc={
			name:'mengzhanc',
			connect:true,
			character:{
				"mengzhanc_小智":["male","meng",3,['mengzhanc_收服'],[]],
				"mengzhanc_小霞":["female","meng",3,['mengzhanc_抵水','mengzhanc_涓涓'],[]],
				"mengzhanc_古柳":["male","meng",3,['mengzhanc_严冬','mengzhanc_凌寒'],[]],
				"mengzhanc_坂木":["male","meng",4,['mengzhanc_撼地','mengzhanc_复燃'],[]],
				"mengzhanc_琪露诺":["female","meng",3,['mengzhanc_冰结','mengzhanc_负寒'],[]],
				"mengzhanc_橙":["female","meng",3,['mengzhanc_式符','mengzhanc_化猫'],[]],
				"mengzhanc_红美铃":["female","meng",4,['mengzhanc_彩极','mengzhanc_虎劲'],[]],
				"mengzhanc_蕾米莉亚":["female","meng",4,['mengzhanc_神枪','mengzhanc_运命'],[]],
				"mengzhanc_犬走椛":["female","meng",4,['mengzhanc_千里之视'],[]],
				"mengzhanc_米斯蒂娅":["female","meng",3,['mengzhanc_夜盲之曲','mengzhanc_放歌高吟'],[]],
				"mengzhanc_凰莲严之介":["male","meng",4,['mengzhanc_DuriNoko'],[]],
				"mengzhanc_上杉谦信":["male","meng",4,['mengzhanc_车悬之剑'],[]],
				"mengzhanc_朝田诗乃":["female","meng",3,['mengzhanc_冰之心境','mengzhanc_幽灵子弹'],[]],
				"mengzhanc_逢坂大河":["female","meng",3,['mengzhanc_夜袭','mengzhanc_娇蛮'],[]],
				"mengzhanc_小红帽":["female","meng",3,['mengzhanc_予糕','mengzhanc_坦心'],[]],
				"mengzhanc_亚里亚":["female","meng",4,['mengzhanc_绯天双战'],[]],
			},
			//characterTitle:{},
			skill:{
				"mengzhanc_showCards":{
					marktext:"明",
					intro:{
						content:'cards',
					},
				},
				"_mengzhanc_showCards":{
					trigger:{
						player:"loseAfter",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						if(player.storage.mengzhanc_showCards==undefined) return false;
						if(event.cards==undefined) return false;
						for(var i=0;i<event.cards.length;i++){
							var card=event.cards[i];
							if(player.storage.mengzhanc_showCards.contains(card)) return true;
						};
						return false;
					},
					content:function (){
						'step 0'
						for(var i=0;i<trigger.cards.length;i++){
							var card=trigger.cards[i];
							if(player.storage.mengzhanc_showCards.contains(card)){
								player.storage.mengzhanc_showCards.remove(card);
								player.syncStorage('mengzhanc_showCards');
							};
						};
						'step 1'
						if(player.storage.mengzhanc_showCards.length==0) player.unmarkSkill('mengzhanc_showCards');
					},
				},
				"mengzhanc_收服":{
					trigger:{
						global:"discardEnd",
					},
					filter:function(event,player){
						return event.cards!=undefined&&event.cards.length>0&&event.player!=player;
					},
					check:function(event,player){
						return player.countCards('h')<player.maxHp+1;
					},
					content:function (){
						'step 0'
						player.chooseControl(['摸一张牌','获得其中一张牌']).set('ai',function(event){
							return ['摸一张牌','获得其中一张牌'].randomGet();
						});
						'step 1'
						if(result.control=='摸一张牌'){
							player.draw();
							event.goto(4);
						}else{
							if(event.isMine()==false){
								event.dialog=ui.create.dialog('请选择需要获得的牌',trigger.cards);
								game.delay(2);
							};
						};
						'step 2'
						if(event.dialog) event.dialog.close();
						var dialog=ui.create.dialog('请选择需要获得的牌',trigger.cards);
						player.chooseButton(1,dialog).set('ai',function(button){
							return get.value(button.link);
						}).filterButton=function(button){
							for(var i=0;i<ui.selected.buttons.length;i++){
								if(get.suit(button.link)==get.suit(ui.selected.buttons[i].link)) return false;
							};
							return true;
						};
						'step 3'
						if(result.buttons) player.gain(result.buttons[0].link,'gain2');
						'step 4'
						if(player.countCards('h')>player.maxHp) player.chooseToDiscard('h',player.countCards('h')-player.maxHp,true);
					},
				},
				"mengzhanc_抵水":{
					group:["mengzhanc_抵水_sha","mengzhanc_抵水_shan"],
					subSkill:{
						"sha":{
							enable:['chooseToRespond','chooseToUse'],
							filterCard:function(card,player){
								return get.color(card)=='black';
							},
							position:'he',
							viewAs:{name:'sha'},
							viewAsFilter:function(player){
								return player.countCards('he',{color:'black'})>0&&_status.currentPhase==player;
							},
							prompt:'将一张黑色牌当【杀】使用或打出',
							check:function(card){return 4-get.value(card)},
							ai:{
								skillTagFilter:function(player){
									if(!player.countCards('he',{color:'black'})) return false;
								},
								respondSha:true,
							},
						},
						"shan":{
							enable:['chooseToRespond'],
							filterCard:function(card){
								return get.color(card)=='black';
							},
							viewAs:{name:'shan'},
							viewAsFilter:function(player){
								if(player.countCards('he',{color:'black'})==0||_status.currentPhase==player) return false;
							},
							position:'he',
							prompt:'将一张黑色牌当【闪】打出',
							check:function(card){return 6-get.value(card)},
							ai:{
								respondShan:true,
								skillTagFilter:function(player){
									if(!player.countCards('he',{color:'black'})) return false;
								},
								effect:{
									target:function(card,player,target,current){
										if(get.tag(card,'respondShan')&&current<0) return 0.6
									},
								},
							},
						},
					},
				},
				"mengzhanc_涓涓":{
					trigger:{
						player:["useCardAfter","respondAfter"],
					},
					filter:function(event,player){
						return get.color(event.card)=='black'&&get.type(event.card)=='basic'&&player.storage.mengzhanc_涓涓!=true;
					},
					frequent:true,
					content:function (){
						player.draw();
						player.storage.mengzhanc_涓涓=true;
					},
				},
				"_mengzhanc_涓涓":{
					trigger:{
						player:"phaseEnd",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return game.countPlayer(function(current){return current.storage.mengzhanc_涓涓==true})>0;
					},
					content:function (){
						for(var i=0;i<game.players.length;i++){
							var pl=game.players[i];
							if(pl.storage.mengzhanc_涓涓==true) delete pl.storage.mengzhanc_涓涓;
						};
					},
				},
				"mengzhanc_严冬":{
					trigger:{
						player:"phaseEnd",
					},
					direct:true,
					filter:function(event,player){
						return game.countPlayer(function(current){return current.countCards('h')>player.countCards('h')})>0;
					},
					content:function (){
						'step 0'
						player.chooseTarget(get.prompt('mengzhanc_严冬'),function(card,player,target){
							return target.countCards('h')>player.countCards('h');
						}).ai=function(target){
							return -get.attitude(player,target);
						};
						'step 1'
						if(result.bool){
							event.target=result.targets[0];
							player.logSkill('mengzhanc_严冬');
							player.line(event.target);
							player.discardPlayerCard(1,'he',event.target);
						}else{
							event.finish();
						};
						'step 2'
						if(result.cards!=undefined){
							if(get.color(result.cards[0])=='black') player.useCard({name:'sha'},event.target);
						};
					},
				},
				"mengzhanc_凌寒":{
					trigger:{
						global:"shaBegin",
					},
					direct:true,
					filter:function(event,player){
						return event.card!=undefined&&get.suit(event.card)=='club'&&event.targets!=undefined&&event.targets.contains(player);
					},
					content:function (){
						'step 0'
						player.chooseToDiscard(get.prompt('mengzhanc_严冬'),1,'he').set('ai',function(card){
							return 6-get.value(card);
						});
						'step 1'
						if(result.cards!=undefined){
							trigger.cancel();
							game.log(trigger.player,'的【杀】失效了');
						};
					},
				},
				"mengzhanc_撼地":{
					enable:'phaseUse',
					usable:1,
					discard:false,
					filter:function(event,player){
						return player.countCards('he',{color:'black'})>=2;
					},
					filterCard:true,
					selectCard:2,
					check:function(card){
						return 5-get.value(card);
					},
					filterTarget:function(card,player,target){
						return target!=player;
					},
					selectTarget:-1,
					content:function(){
						'step 0'
						target.chooseToRespond({name:'shan'},'请打出一张【闪】来响应【撼地】');
						'step 1'
						if(result.bool==false) target.damage();
					},
					ai:{
						expose:0.65,
						order:9,
						result:{
							player:function(player){
								if(game.countPlayer(function(current){return current.hp<=3&&get.attitude(player,current)<0})>0&&
								game.countPlayer(function(current){return current.hp<=1&&get.attitude(player,current)>0})==0) return 2;
								return 0;
							},
						},
					},
				},
				"mengzhanc_复燃":{
					trigger:{
						player:"phaseBegin",
					},
					filter:function(event,player){
						var num=player.maxHp-player.hp;
						return num>player.countCards('h');
					},
					frequent:true,
					content:function (){
						player.draw((player.maxHp-player.hp)-player.countCards('h'));
					},
				},
				"mengzhanc_冰结":{
					trigger:{
						player:"useCardBegin",
					},
					forced:true,
					filter:function(event,player){
						var bool=false;
						var targets=event.targets;
						var num=0;
						for(var i in player.getStat().card){
							num+=player.getStat().card[i];
						};
						for(var i=0;i<targets.length;i++){
							if(get.distance(player,targets[i])==num) bool=true;
						};
						return bool==true&&_status.currentPhase==player;
					},
					content:function (){
						var targets=trigger.targets;
						var num=0;
						for(var i in player.getStat().card){
							num+=player.getStat().card[i];
						};
						for(var i=0;i<targets.length;i++){
							if(get.distance(player,targets[i])==num){
								targets[i].addTempSkill('mengzhanc_冰结1',{player:'phaseAfter'});
								targets[i].markSkillCharacter('mengzhanc_冰结1',player,'冰结','无法使用或打出任何牌');
							};
						};
					},
					ai:{
						effect:{
							target:function(card,player,target){
								if(player==target&&_status.currentPhase==player){
									var num=0;
									for(var i in player.getStat().card){
										num+=player.getStat().card[i];
									};
									if(get.distance(player,target)==num&&get.attitude(player,target)<0) return 1;
									if(card.name=='tao') return 1;
									if(get.type(card)=='equip'&&player.needsToDiscard()<=1) return 1;
									if(get.distance(player,target)==num&&get.attitude(player,target)>=0) return 0;
									return 1;
								};
							},
							player:function(card,player,target){
								if(_status.currentPhase==player){
									var num=0;
									for(var i in player.getStat().card){
										num+=player.getStat().card[i];
									};
									if(get.distance(player,target)==num&&get.attitude(player,target)<0) return 1;
									if(get.distance(player,target)==num&&get.attitude(player,target)>=0) return 0;
									return 1;
								};
							},
						},
					},
				},
				'mengzhanc_冰结1':{
					mod:{
						cardEnabled:function(card,player){
							return false;
						},
						cardUsable:function(card,player){
							return false;
						},
						cardRespondable:function(card,player){
							return false;
						},
						cardSavable:function(card,player){
							return false;
						},
					},
				},
				"mengzhanc_负寒":{
					trigger:{
						player:"damageAfter",
					},
					forced:true,
					filter:function(event,player){
						if(event.source==undefined) return false;
						if(event.source.countCards('e')>0||(event.source.countCards('e')==0&&event.source.countCards('h')>0)) return true;
						return false;
					},
					content:function (){
						if(trigger.source.countCards('e')>0){
							player.discardPlayerCard(1,'e',trigger.source,true);
						}else{
							player.discardPlayerCard(1,'h',trigger.source,true);
							player.discardPlayerCard(1,'h',trigger.source,true);
						};
					},
				},
				"mengzhanc_式符":{
					trigger:{
						global:"discardEnd",
					},
					direct:true,
					filter:function(event,player){
						return event.cards!=undefined&&player.countCards('he')>=event.cards.length&&event.player!=player;
					},
					content:function (){
						'step 0'
						player.chooseToDiscard(get.prompt('mengzhanc_式符'),trigger.cards.length,'he').set('ai',function(card){
							if(get.attitude(player,trigger.player)>0&&player.countCards('he')-trigger.cards.length>=1) return 6-get.value(card);
							return -1;
						});
						'step 1'
						if(result.cards!=undefined) trigger.player.gain(trigger.cards,'gain2');
					},
				},
				"mengzhanc_化猫":{
					mod:{
						globalFrom:function(from,to){
							if(from.countCards('h')<to.countCards('h')) return 1;
						},
					},
				},
				"_mengzhanc_化猫":{
					mod:{
						attackFrom:function(from,to,distance){
							if(to.hasSkill('mengzhanc_化猫')&&from.countCards('h')>to.countCards('h')) return Infinity;
						},
					},
				},
				"mengzhanc_彩极":{
					trigger:{
						global:"shaBefore",
					},
					filter:function(event,player){
						/*if(event.targets==undefined) return false;
						for(var i=0;i<event.targets.length;i++){
							var target=event.targets[i];
							if(get.distance(player,target,'attack')<=1&&(player.countCards('h',{color:'black'})>0||(player.countCards('h',{color:'red'})>0&&target!=player))) return true;
						};*/
						var target=event.target;
						return get.distance(player,target,'attack')<=1&&(player.countCards('h',{color:'black'})>0||(player.countCards('h',{color:'red'})>0&&target!=player&&event.player!=player));
					},
					check:function(event,player){
						return (player.countCards('h',{color:'black'})>0&&(event.target.countCards('j')>0&&get.attitude(player,event.target)>0)||get.attitude(player,event.target)<0)||
						(player.countCards('h',{color:'red'})>0&&event.target!=player&&get.attitude(player,event.target)>0&&player.countCards('h',{name:'shan'})>0);
					},
					content:function (){
						'step 0'
						var list=[];
						if(player.countCards('h',{color:'black'})>0) list.push('弃置一张黑色手牌，然后弃置其一张牌');
						if(player.countCards('h',{color:'red'})>0&&trigger.target!=player&&trigger.player!=player) list.push('明置一张红色手牌，然后将此【杀】（使用者不为你）转移给你');
						player.chooseControl().set('ai',function(event){
							if(get.attitude(player,trigger.target)<0&&player.countCards('h',{color:'black'})>0) return '选项一';
							return '选项二';
						}).set('prompt','彩极').set('choiceList',list);
						'step 1'
						event.control=result.control;
						var color='';
						if(event.control=='选项一') color='black';
						if(event.control=='选项二') color='red';
						player.chooseCard(1,{color:color},'h').set('ai',function(card){
							return 6-get.value(card);
    					});
						'step 2'
						if(result.bool){
							if(event.control=='选项一'){
								player.discard(result.cards);
								player.discardPlayerCard(1,'hej',trigger.target);
							};
							if(event.control=='选项二'){
								player.mengzhanc_showCards(result.cards);
								trigger.targets.remove(trigger.target);
								trigger.targets.push(player);
								trigger.target=player;
							};
						};
					},
				},
				"mengzhanc_虎劲":{
					trigger:{
						global:"phaseAfter",
					},
					direct:true,
					filter:function(event,player){
						return player.storage.mengzhanc_虎劲==true;
					},
					content:function (){
						'step 0'
						delete player.storage.mengzhanc_虎劲;
						player.chooseTarget(get.prompt('mengzhanc_虎劲'),function(card,player,target){
							return get.distance(player,target,'attack')<=1;
						}).ai=function(target){
							return -get.attitude(player,target);
						};
						'step 1'
						if(result.bool){
							player.useCard({name:'sha'},result.targets[0]);
						};
					},
				},
				"_mengzhanc_虎劲":{
					trigger:{
						player:"damageAfter",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return event.card!=undefined&&event.card.name=='sha'&&player.storage.mengzhanc_虎劲!=true;
					},
					content:function (){
						player.storage.mengzhanc_虎劲=true;
					},
				},
				"mengzhanc_神枪":{
					group:["mengzhanc_神枪_1","mengzhanc_神枪_2","mengzhanc_神枪_3"],
					subSkill:{
						"1":{
							mod:{
								targetInRange:function(card){
									if(_status.event.skill=='mengzhanc_神枪_1') return true;
								},
							},
							enable:'chooseToUse',
							filterCard:true,
							selectCard:2,
							viewAs:{name:'sha'},
							viewAsFilter:function(player){
								return player.countCards('h')>=2;
							},
							prompt:'将两张手牌当无距离限制的【杀】使用',
							check:function(card){
								return 5-get.value(card);
							},
							ai:{
								order:3,
							},
						},
						"2":{
							trigger:{
								player:"shaBegin",
							},
							filter:function(event,player){
								return event.card!=undefined&&get.color(event.card)=='red';
							},
							prompt:'是否发到【神枪】令此【杀】不能被【闪】响应且此【杀】造成伤害后回复1点体力？',
							content:function (){
								trigger.directHit=true;
								player.storage.mengzhanc_神枪=true;
							},
						},
						"3":{
							trigger:{
								source:"damageAfter",
							},
							filter:function(event,player){
								return player.storage.mengzhanc_神枪==true;
							},
							forced:true,
							popup:false,
							content:function (){
								player.recover();
								delete player.storage.mengzhanc_神枪;
							},
						},
					},
				},
				"mengzhanc_运命":{
					trigger:{
						global:'judge'
					},
					filter:function(event,player){
						return get.distance(player,event.player,'attack')<=1;
					},
					check:function(event,player){
						var num=0;
						var trigger=_status.event.getTrigger();
						if(trigger==undefined) return false;
						var player=_status.event.player;
						var judging=event.player.judging;
						var result=-trigger.judge(judging);
						var attitude=get.attitude(player,trigger.player);
						if(attitude==0||result==0) num=0;
						if(attitude>0){
							num+=result;
						}else{
							num+=-result;
						};
						if(num>0){
							return true;
						}else{
							return false;
						};
					},
					content:function(){
						'step 0'
						player.gain(trigger.player.judging[0],'gain2');
						'step 1'
						event.card=get.cards()[0];
						player.showCards(event.card);
						'step 2'
						event.card.discard();
						trigger.player.judging[0]=event.card;
						game.log(trigger.player,'的判定牌改为',event.card);
					},
				},
				"mengzhanc_千里之视":{
					nobracket:true,
					enable:"phaseUse",
					filter:function(event,player){
						if(player.getStat().skill.mengzhanc_千里之视>=1) return false;
						return true;
					},
					filterTarget:function(card,player,target){
						return player!=target&&target.countCards('h')>0;
					},
					line:true,
					content:function (){
						'step 0'
						player.viewCards(get.translation(target)+'的手牌',target.get('h'));
						var list=['弃置其中的一张【杀】或锦囊牌'];
						if(player.storage.mengzhanc_千里之视!=true) list.push('重置此技能的使用次数且本回合不能再选择此项');
						player.chooseControl().set('ai',function(event){
							return '选项一';
						}).set('prompt','千里之视').set('choiceList',list);
						'step 1'
						if(result.control=='选项一'){
							var cards=target.get('h');
							var cards1=[];
							for(var i=0;i<cards.length;i++){
								if(cards[i].name=='sha'||get.type(cards[i])=='trick'||get.type(cards[i])=='delay'){
									cards1.push(cards[i]);
								};
							};
							if(cards1.length>0) player.chooseCardButton(cards1).set('ai',function(button){return 1});
						}else{
							player.getStat().skill.mengzhanc_千里之视--;
							player.storage.mengzhanc_千里之视=true;
							event.finish();
						};
						'step 2'
    					if(result.bool){
							target.discard(result.links[0]);
						}else{
							event.finish();
						};
					},
					ai:{
						order:13,
						expose:0.5,
						result:{
							target:-1,
						},
					},
				},
				"_mengzhanc_千里之视":{
					trigger:{
						player:"phaseAfter",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return player.storage.mengzhanc_千里之视==true;
					},
					content:function (){
						delete player.storage.mengzhanc_千里之视;
					},
				},
				"mengzhanc_夜盲之曲":{
					nobracket:true,
					trigger:{
						global:"phaseBefore",
					},
					filter:function(event,player){
						if(!event.player.mengzhanc_hasShownCards()) return false;
						var cards=event.player.storage.mengzhanc_showCards;
						for(var i=0;i<cards.length;i++){
							if(get.color(cards[i])=='red') return true;
						};
						return false;
					},
					check:function(event,player){
						return get.attitude(player,event.player)<0;
					},
					content:function (){
						var cards1=[];
						var cards=trigger.player.storage.mengzhanc_showCards;
						for(var i=0;i<cards.length;i++){
							if(get.color(cards[i])=='red') cards1.push(cards[i]);
						};
						trigger.player.mengzhanc_coverCards(cards1);
						trigger.player.addTempSkill('mengzhanc_夜盲之曲1',{player:'phaseAfter'});
						trigger.player.markSkillCharacter('mengzhanc_夜盲之曲1',player,'夜盲之曲','此回合不能响应任何牌，且除其之外的角色此回合不是其使用牌的合法目标');
					},
				},
				"mengzhanc_夜盲之曲1":{
					mod:{
						cardRespondable:function(card,player){
							return false;
						},
						targetInRange:function(card,player,target,now){
							if(target!=player) return false;
						},
					},
				},
				"mengzhanc_放歌高吟":{
					nobracket:true,
					group:["mengzhanc_放歌高吟_1","mengzhanc_放歌高吟_2"],
					subSkill:{
						"1":{
							trigger:{
								player:"useCardAfter",
							},
							filter:function(event,player){
								return event.targets!=undefined&&event.targets.length>0&&_status.currentPhase==player;
							},
							content:function (){
								if(player.storage.mengzhanc_放歌高吟==undefined) player.storage.mengzhanc_放歌高吟=[];
								var targets=trigger.targets;
								for(var i=0;i<targets.length;i++){
									if(targets[i].countCards('h')>0){
										var cards=targets[i].get('h');
										var cards1=[];
										for(var j=0;j<cards.length;j++){
											var card=cards[j];
											if(targets[i].storage.mengzhanc_showCards==undefined) targets[i].storage.mengzhanc_showCards=[];
											if(!targets[i].storage.mengzhanc_showCards.contains(card)&&card.mengzhanc_link==undefined) cards1.push(card);
										};
										if(cards1.length>0){
											var card1=cards1.randomGet();
											targets[i].mengzhanc_showCards([card1]);
											if(!player.storage.mengzhanc_放歌高吟.contains(targets[i])) player.storage.mengzhanc_放歌高吟.push(targets[i]);
										};
									};
								};
							},
						},
						"2":{
							trigger:{
								player:"phaseEnd",
							},
							direct:true,
							filter:function(event,player){
								var targets=player.storage.mengzhanc_放歌高吟;
								if(targets==undefined) return false;
								if(targets.length==0) return false;
								for(var i=0;i<targets.length;i++){
									if(targets[i].mengzhanc_hasShownCards()) return true;
								};
								return false;
							},
							content:function (){
								'step 0'
								event.num=0;
								player.chooseTarget('是否令一名角色使用明置手牌？').ai=function(target){
									return get.attitude(player,target);
								};
								'step 1'
								if(result.bool){
									event.target=result.targets[0];
									var cards=[];
									var cards1=[];
									var targets=player.storage.mengzhanc_放歌高吟;
									for(var i=0;i<targets.length;i++){
										if(targets[i].mengzhanc_hasShownCards()){
											var cards2=targets[i].storage.mengzhanc_showCards;
											for(var j=0;j<cards2.length;j++){
												cards1.push(cards2[j]);
											};
										};
									};
									for(var i=0;i<cards1.length;i++){
										var card=cards1[i];
										var card1=game.createCard(card);
										card1.mengzhanc_link=card;
										cards.push(card1);
									};
									event.target.gain(cards,'log');
									event.target.storage.mengzhanc_放歌高吟1=true;
								}else{
									delete player.storage.mengzhanc_放歌高吟;
									event.finish();
								};
								'step 2'
								event.target.chooseToUse('请使用明置手牌',function(card){
									if(event.num>=1&&get.type(card)!='delay') return false;
									if(!lib.filter.cardEnabled(card,_status.event.player,_status.event)) return false;
									return card.mengzhanc_link!=undefined;
								});
								'step 3'
								if(result.bool&&event.num<1){
									event.num++;
									event.goto(2);
								}else{
									var cards=event.target.get('h');
									var cards1=[];
									for(var i=0;i<cards.length;i++){
										if(cards[i].mengzhanc_link!=undefined) cards1.push(cards[i]);
									};
									event.target.lose(cards1,ui.special);
									delete event.target.storage.mengzhanc_放歌高吟1;
									delete player.storage.mengzhanc_放歌高吟;
								};
							},
						},
					},
				},
				"_mengzhanc_放歌高吟":{
					trigger:{
						player:"useCardBefore",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return player.storage.mengzhanc_放歌高吟1==true&&event.card.mengzhanc_link!=undefined;
					},
					content:function (){
						'step 0'
						//console.log(trigger.card.mengzhanc_link);
						for(var i=0;i<game.players.length;i++){
							var pl=game.players[i];
							if(pl.get('h').contains(trigger.card.mengzhanc_link)){
								pl.lose(trigger.card.mengzhanc_link,ui.special);
							};
						};
						'step 1'
						delete trigger.card.mengzhanc_link;
					},
				},
				"mengzhanc_DuriNoko":{
					nobracket:true,
					enable:"phaseUse",
					usable:1,
					filter:function(event,player){
						return game.countPlayer(function(current){return get.distance(player,current)<=1&&current.countCards('hej')>0})>0;
					},
					filterTarget:function(card,player,target){
						return get.distance(player,target)<=1&&target.countCards('hej')>0;
					},
					selectTarget:[1,Infinity],
					multitarget:true,
					line:false,
					content:function (){
						player.line(targets);
						for(var i=0;i<targets.length;i++){
							var target=targets[i];
							player.discardPlayerCard(1,'hej',target);
						};
						if(targets.length>player.maxHp-player.hp) player.loseHp();
					},
					ai:{
						order:12,
						expose:0.5,
						result:{
							target:function(player,target){
								var num=player.maxHp-player.hp;
								if(get.attitude(player,target)<0&&target.countCards('he')>0){
									if(num==0) return -1;
									if(ui.selected.targets.length==0&&num>0&&num<=1) return -1;
									if(ui.selected.targets.length==1&&num>1&&num<=2) return -1;
									if(ui.selected.targets.length==2&&num>2&&num<=3) return -1;
								};
								if(get.attitude(player,target)>=0&&target.countCards('j')>0){
									if(num==0) return 1;
									if(ui.selected.targets.length==0&&num>0&&num<=1) return 1;
									if(ui.selected.targets.length==1&&num>1&&num<=2) return 1;
									if(ui.selected.targets.length==2&&num>2&&num<=3) return 1;
								};
								return ;
							},
						},
					},
				},
				"mengzhanc_车悬之剑":{
					nobracket:true,
					group:["mengzhanc_车悬之剑_1","mengzhanc_车悬之剑_2","mengzhanc_车悬之剑_3"],
					subSkill:{
						"1":{
							mod:{
								cardUsable:function(card,player,num){
									if(card.name=='sha'&&player.storage.mengzhanc_车悬之剑!=undefined) return num+=player.storage.mengzhanc_车悬之剑;
								},
							},
							trigger:{
								source:"damageAfter",
							},
							frequent:true,
							filter:function(event,player){
								return player.storage.mengzhanc_车悬之剑!=undefined&&player.storage.mengzhanc_车悬之剑<player.maxHp-player.hp+1;
							},
							content:function (){
								player.draw();
								player.storage.mengzhanc_车悬之剑++;
							},
						},
						"2":{
							trigger:{
								player:"phaseUseBefore",
							},
							forced:true,
							popup:false,
							content:function (){
								player.storage.mengzhanc_车悬之剑=0;
							},
						},
						"3":{
							trigger:{
								player:"phaseUseAfter",
							},
							forced:true,
							popup:false,
							content:function (){
								delete player.storage.mengzhanc_车悬之剑;
							},
						},
					},
				},
				"mengzhanc_冰之心境":{
					nobracket:true,
					group:["mengzhanc_冰之心境_1"],
					subSkill:{
						"1":{
							mod:{
								globalFrom:function(from,to,distance){
									return distance-from.countCards('h');
								},
							},
							trigger:{
								player:'shaMiss'
							},
							forced:true,
							content:function(){
								player.disableSkill('mengzhanc_冰之心境',['mengzhanc_冰之心境']);
								player.storage.mengzhanc_冰之心境=true;
							},
						},
					},
				},
				"_mengzhanc_冰之心境":{
					mod:{
						targetInRange:function(card,player,target,now){
							var bool=true;
							for(var i in target.disabledSkills){
								if(target.disabledSkills[i].contains('mengzhanc_冰之心境')) bool=false;
							};
							if(target.hasSkill('mengzhanc_冰之心境')&&bool==true&&card.name=='sha'&&get.distance(target,player,'attack')>1) return false;
						},
					},
				},
				"_mengzhanc_冰之心境1":{
					trigger:{
						player:'phaseAfter'
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return player.storage.mengzhanc_冰之心境==true;
					},
					content:function(){
						player.enableSkill('mengzhanc_冰之心境');
						delete player.storage.mengzhanc_冰之心境;
					},
				},
				"mengzhanc_幽灵子弹":{
					nobracket:true,
					trigger:{
						global:'phaseBefore'
					},
					filter:function(event,player){
						return player.countCards('he',{color:'black'})>0&&(player.canUse('sha',event.player)||player==event.player);
					},
					direct:true,
					content:function(){
							'step 0'
							player.chooseToDiscard('是否对'+get.translation(trigger.player.name)+'使用【幽灵子弹】？',1,'he',{color:'black'}).ai=function(card){
								if(get.attitude(player,trigger.player)>0) return 0;
								if(get.attitude(player,trigger.player)<0&&trigger.player.countCards('h',{name:'shan'})==0) return 6-get.value(card);
							};
							'step 1'
							if(result.bool){
								trigger.player.storage.mengzhanc_幽灵子弹=true;
								player.useCard({name:'sha',color:'black'},trigger.player)
							}else{
								event.finish();
							};
							'step 2'
							delete trigger.player.storage.mengzhanc_幽灵子弹;
					},
				},
				"_mengzhanc_幽灵子弹":{
					trigger:{
						player:'shaMiss'
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return player.storage.mengzhanc_幽灵子弹==true;
					},
					content:function(){
						trigger.target.addTempSkill('mengzhanc_幽灵子弹1',{player:'phaseAfter'});
					},
				},
				"mengzhanc_幽灵子弹1":{
					mod:{
						cardUsable:function(card,player,num){
							if(card.name=='sha') return num+=1;
						},
					},
				},
				"mengzhanc_夜袭":{
					enable:'phaseUse',
					usable:1,
					discard:false,
					line:true,
					filterCard:function(card){
						return true;
					},
					check:function(card){
						return 5-get.value(card);
					},
					filterTarget:function(card,player,target){
						return target!=player;
					},
					content:function(){
						player.$give(cards.length,target);
						target.gain(cards);
						player.storage.mengzhanc_夜袭=target;
						target.storage.mengzhanc_夜袭1=player;
					},
					ai:{
						expose:0.35,
						order:1,
						result:{
							target:function(player,target){
								if(player.countCards('h',function(card){return (5-get.value(card))>0})>0&&(target.countCards('h')>=target.hp-1)) return -1;
								return ;
							},
						},
					},
				},
				"_mengzhanc_夜袭":{
					trigger:{
						player:'phaseUseBegin'
					},
					direct:true,
					filter:function(event,player){
						return game.countPlayer(function(current){return current.storage.mengzhanc_夜袭==player})>0;
					},
					content:function(){
						'step 0'
						event.pl=player.storage.mengzhanc_夜袭1;
						if(player.countCards('h')>player.hp){
							event.pl.logSkill('mengzhanc_夜袭');
							var list=['受到'+get.translation(event.pl.name)+'造成的1点伤害'];
							if(player.countCards('h')>0) list.push('令'+get.translation(event.pl.name)+'观看其手牌并获得其中的一张牌');
							player.chooseControl(list).set('ai',function(event){
								if(player.countCards('h')>0) return '令'+get.translation(event.pl.name)+'观看其手牌并获得其中的一张牌';
								return '受到'+get.translation(event.pl.name)+'造成的1点伤害';
							});
						}else{
							event.goto(2);
						};
						'step 1'
						if(result.control=='受到'+get.translation(event.pl.name)+'造成的1点伤害'){
							event.pl.line(player);
							player.damage().source=event.pl;
						};
						if(result.control=='令'+get.translation(event.pl.name)+'观看其手牌并获得其中的一张牌'){
							event.pl.line(player);
							event.pl.gainPlayerCard(player,'h','visible',true);
						};
						'step 2'
						delete event.pl.storage.mengzhanc_夜袭;
						delete player.storage.mengzhanc_夜袭1;
					},
				},
				"mengzhanc_娇蛮":{
					group:['mengzhanc_娇蛮_1','mengzhanc_娇蛮_2'],
					subSkill:{
						'1':{
							trigger:{
								player:'useCardBefore'
							},
							forced:true,
							filter:function(event,player){
								return event.targets!=undefined;
							},
							content:function(){
								var pls=trigger.targets;
								for(var i=0;i<pls.length;i++){
									var pl=pls[i];
									pl.addTempSkill('mengzhanc_娇蛮1',{global:'useCardAfter'});
								};
							},
						},
						'2':{
							trigger:{
								player:'damageBegin'
							},
							forced:true,
							filter:function(event,player){
								return event.card!=undefined&&get.number(event.card)!=undefined&&player.countCards('he',function(card){return get.number(card)<get.number(event.card)})>0;
							},
							content:function(){
								'step 0'
								player.chooseToDiscard('请弃置一张点数小于'+get.number(trigger.card)+'的牌',1,'he',function(card){
									return get.number(card)<get.number(trigger.card);
								});
								'step 1'
								if(result.bool){
									if(trigger.source) player.line(trigger.source);
									trigger.untrigger();
									trigger.finish();
								};
							},
						},
					},
				},
				"mengzhanc_娇蛮1":{
					mod:{
						cardRespondable:function(card,player){
							if(card!=undefined&&_status.event.parent.cards[0]!=undefined&&get.number(card)>=get.number(_status.event.parent.cards[0])) return false;
						},
					},
				},
				"mengzhanc_予糕":{
					enable:'phaseUse',
					usable:1,
					content:function(){
						'step 0'
						player.draw();
						player.chooseTarget('请选择【予糕】的目标',function(card,player,target){
							return target!=player;
						},true).ai=function(target){
							return get.attitude(target,player);
						};
						'step 1'
						if(result.bool){
							event.target=result.targets[0];
							player.chooseCard('请选择【予糕】需要给予的牌',1,'h',true).set('ai',function(card){
								if(player.maxHp>player.hp&&get.suit(card)=='heart') return 1;
								return 6-get.value(card);
							});
						}else{
							event.finish();
						};
						'step 2'
						if(result.bool){
							player.line(event.target);
							player.$give(result.cards.length,event.target);
							event.target.gain(result.cards);
							if(get.suit(result.cards[0])=='heart'){
								event.target.showCards(result.cards);
								player.recover();
							};
						};
					},
					ai:{
						expose:0.35,
						order:13,
						result:{
							target:function(player,target){
								if(player.countCards('h')>2||
								(player.countCards('h',{suit:'heart'})>0&&player.maxHp>player.hp)||
								game.countPlayer(function(current){return get.attitude(player,current)>0})) return 1;
								return ;
							},
						},
					},
				},
				"mengzhanc_坦心":{
					trigger:{
						player:"chooseToRespondBegin",
					},
					frequent:true,
					filter:function(event,player){
						return _status.currentPhase!=undefined&&player.countCards('h')>0;
					},
					content:function (){
						"step 0"
						player.showCards(player.get('h'));
						var pl=_status.currentPhase;
						pl.discardPlayerCard(player,1,'h','visible').set('ai',function(card){
    						if(get.attitude(pl,player)>0) return 5-get.value(card);
							return 0;
    					});
						"step 1"
						if(result.bool>0){
							trigger.untrigger();
							trigger.responded=true;
							trigger.result={bool:true,card:{name:'shan'}}
						}
					},
				},
				"mengzhanc_绯天双战":{
					nobracket:true,
					group:["mengzhanc_绯天双战_1","mengzhanc_绯天双战_2","mengzhanc_绯天双战_3","mengzhanc_绯天双战_4"],
					subSkill:{
						"1":{
							name:'绯天双战：红',
							enable:['chooseToUse','chooseToRespond'],
							filterCard:function(card){
								return get.color(card)=='red';
							},
							position:'he',
							viewAs:{
								name:'sha',
							},
							viewAsFilter:function(player){
								if(player.storage.countHasUsedCard==undefined) return true;
								var cards=player.storage.countHasUsedCard;
								var bool=true;
								for(var i=0;i<cards.length;i++){
									if(get.color(cards[i])=='red') bool=false;
								};
								return bool==true;
							},
							prompt:'将一张红色花色手牌当【杀】使用',
							check:function(card){
								return 5-get.value(card);
							},
							ai:{
								respondSha:true,
								skillTagFilter:function(player){
									var bool=true;
									if(player.storage.countHasUsedCard!=undefined){
										var cards=player.storage.countHasUsedCard;
										for(var i=0;i<cards.length;i++){
											if(get.color(cards[i])=='red') bool=false;
										};
									};
									return player.countCards('h',{color:'red'})>0&&bool==true;
								},
							},
						},
						"2":{
							mod:{
								cardUsable:function(card,player,num){
									if(card.name=='sha'&&get.color(card)=='red') return Infinity;
								},
							},
						},
						"3":{
							name:'绯天双战：黑',
							enable:['chooseToUse','chooseToRespond'],
							filterCard:function(card){
								return get.color(card)=='black';
							},
							position:'he',
							viewAs:{
								name:'sha',
							},
							viewAsFilter:function(player){
								if(player.storage.countHasUsedCard==undefined) return true;
								var cards=player.storage.countHasUsedCard;
								var bool=true;
								for(var i=0;i<cards.length;i++){
									if(get.color(cards[i])=='black') bool=false;
								};
								return bool==true;
							},
							prompt:'将一张红色花色手牌当【杀】使用',
							check:function(card){
								return 5-get.value(card);
							},
							ai:{
								respondSha:true,
								skillTagFilter:function(player){
									var bool=true;
									if(player.storage.countHasUsedCard!=undefined){
										var cards=player.storage.countHasUsedCard;
										for(var i=0;i<cards.length;i++){
											if(get.color(cards[i])=='black') bool=false;
										};
									};
									return player.countCards('h',{color:'black'})>0&&bool==true;
								},
							},
						},
						"4":{
							ai:{
								unequip:true,
								skillTagFilter:function (player,tag,arg){
									if(arg&&arg.name=='sha'&&get.color(arg)=='black') return true;
									return false;
								},
							},
						},
					},
				},
				
				
				
				
			},
			translate:{
				"mengzhanc_亚里亚":"亚里亚",
				"mengzhanc_绯天双战":"绯天双战",
				"mengzhanc_绯天双战_info":"出牌阶段限一次，你可摸一张牌，然后将一张手牌交给一名其他角色；若此牌为红桃牌，则其可于获得此牌后展示之，令你回复1点体力",
				"mengzhanc_小红帽":"小红帽",
				"mengzhanc_予糕":"予糕",
				"mengzhanc_予糕_info":"出牌阶段限一次，你可摸一张牌，然后将一张手牌交给一名其他角色；若此牌为红桃牌，则其可于获得此牌后展示之，令你回复1点体力",
				"mengzhanc_坦心":"坦心",
				"mengzhanc_坦心_info":"每当你需要使用或打出【闪】时，你可展示所有手牌，然后令当前回合角色弃置其中的一张牌；若如此做，你视为使用或打出【闪】",
				"mengzhanc_逢坂大河":"逢坂大河",
				"mengzhanc_夜袭":"夜袭",
				"mengzhanc_夜袭_info":"出牌阶段限一次，你可交给一名其他角色一张手牌；其下个出牌阶段开始时，若其手牌数大于其体力值，则其选择一项：1.受到你造成的1点伤害；2.令你观看其手牌并获得其中的一张牌",
				"mengzhanc_娇蛮":"娇蛮",
				"mengzhanc_娇蛮_info":"你的牌不能被点数小于此牌的牌响应；你受到牌造成的伤害时，可弃置一张点数小于此牌的牌，防止此伤害",
				"mengzhanc_朝田诗乃":"朝田诗乃",
				"mengzhanc_冰之心境":"冰之心境",
				"mengzhanc_冰之心境_info":"锁定技，你的攻击范围+X，你攻击范围外的角色无法对你使用【杀】；你使用的【杀】被抵消时，此技能无效直至你的回合结束（X为你的手牌数）",
				"mengzhanc_幽灵子弹":"幽灵子弹",
				"mengzhanc_幽灵子弹_info":"一名角色的回合开始时，你可将弃置一张黑色牌并视为对其使用一张黑色花色的【杀】；若此【杀】未造成伤害，则其于此回合出牌阶段使用【杀】的次数上限+1",
				"mengzhanc_上杉谦信":"上杉谦信",
				"mengzhanc_凰莲严之介":"凰莲严之介",
				"mengzhanc_车悬之剑":"车悬之剑",
				"mengzhanc_车悬之剑_info":"出牌阶段限X次，每当你造成伤害后，你可摸一张牌并令你本阶段使用【杀】的次数上限+1（X为你已损失的体力值+1）",
				"mengzhanc_DuriNoko":"Duri Noko",
				"mengzhanc_DuriNoko_info":"出牌阶段限一次，你可弃置任意名距离为1的角色区域内各一张牌；若你以此法弃置的牌多于X张，你流失1点体力（X为你已损失的体力值）",
				"mengzhanc_米斯蒂娅":"米斯蒂娅",
				"mengzhanc_夜盲之曲1":"夜盲之曲",
				"mengzhanc_夜盲之曲":"夜盲之曲",
				"mengzhanc_夜盲之曲_info":"一名角色的回合开始时，你可暗置一名有明置红色手牌的角色的红色手牌，令其此回合不能响应任何牌，且除其之外的角色此回合不是其使用牌的合法目标",
				"mengzhanc_放歌高吟":"放歌高吟",
				"mengzhanc_放歌高吟_info":"每当你于出牌阶段使用牌后，你可明置目标一张手牌；结束阶段，你可令一名角色使用本回合你明置手牌目标的所有明置手牌，目标角色最多以此法使用两张牌且第二张牌只能为延时性锦囊牌",
				"mengzhanc_犬走椛":"犬走椛",
				"mengzhanc_千里之视":"千里之视",
				"mengzhanc_千里之视_info":"出牌阶段限一次，你可观看一名角色的手牌，然后选择一项：1.弃置其中的一张【杀】或锦囊牌；2.重置此技能的使用次数且本回合不能再选择此项",
				"mengzhanc_蕾米莉亚":"蕾米莉亚",
				"mengzhanc_神枪":"神枪",
				"mengzhanc_神枪_info":"你可将两张手牌当无距离限制的【杀】使用；你使用的红色【杀】不能被【闪】响应，且此【杀】造成伤害后你回复1点体力",
				"mengzhanc_运命":"运命",
				"mengzhanc_运命_info":"每当你攻击范围内的角色的判定牌生效前，你可获得之并亮出牌堆顶的一张牌来代替",
				"mengzhanc_红美铃":"红美铃",
				"mengzhanc_彩极":"彩极",
				"mengzhanc_彩极_info":"每当你攻击范围内的一名角色成为【杀】的目标时，你可选择一项：1.弃置一张黑色手牌，然后弃置其一张牌；2.明置一张红色手牌，然后将此【杀】（使用者不为你）转移给你",
				"mengzhanc_虎劲":"虎劲",
				"mengzhanc_虎劲_info":"你受到过【杀】造成的伤害的回合结束时，你可视为对攻击范围内的一名角色使用【杀】",
				"mengzhanc_橙":"橙",
				"mengzhanc_式符":"式符",
				"mengzhanc_式符_info":"每当一名其他角色因弃置而失去牌后，你可弃置等量的手牌，令其获得被弃置的牌",
				"mengzhanc_化猫":"化猫",
				"mengzhanc_化猫_info":"锁定技，你与手牌数大于你的角色的距离视为1且视为不在其攻击范围内",
				"mengzhanc_琪露诺":"琪露诺",
				"mengzhanc_冰结1":"冰结",
				"mengzhanc_冰结":"冰结",
				"mengzhanc_冰结_info":"锁定技，每当你于回合内使用牌指定目标后，若你与目标角色距离为X，则其不能使用或打出手牌直至回合结束(X为你本回合已使用的牌数)",
				"mengzhanc_负寒":"负寒",
				"mengzhanc_负寒_info":"锁定技，每当你受到伤害后，若伤害来源装备区里：有牌，你弃置其装备区里的一张牌；无牌，你依次弃置其两张手牌",
				"mengzhanc_坂木":"坂木",
				"mengzhanc_撼地":"撼地",
				"mengzhanc_撼地_info":"出牌阶段限一次，你可弃置两张黑色牌，令所有其他角色选择一项：1.打出【闪】；2.受到你造成的1点伤害",
				"mengzhanc_复燃":"复燃",
				"mengzhanc_复燃_info":"准备阶段，你可将手牌补至X张（X为你已损失的体力值）",
				"mengzhanc_古柳":"古柳",
				"mengzhanc_严冬":"严冬",
				"mengzhanc_严冬_info":"结束阶段，你可弃置一名手牌数大于你的角色的一张牌，若此牌为黑色，则视为你对其使用【杀】",
				"mengzhanc_凌寒":"凌寒",
				"mengzhanc_凌寒_info":"每当你成为♣花色的【杀】的目标后，你可弃置一张牌，令此【杀】对你无效",
				"mengzhanc_小霞":"小霞",
				"mengzhanc_抵水":"抵水",
				"mengzhanc_抵水_info":"你于回合内可将一张黑色牌当【杀】使用或打出；你于回合外可将一张黑色牌当【闪】使用",
				"mengzhanc_涓涓":"涓涓",
				"mengzhanc_涓涓_info":"当你于一名角色的回合首次使用或打出黑色基础牌时，你可摸一张牌",
				"mengzhanc_小智":"小智",
				"mengzhanc_收服":"收服",
				"mengzhanc_收服_info":"每当其他角色的牌因弃置而置入弃牌堆后，你可选择一项：1.摸一张牌；2.获得其中的一张牌，然后若你的手牌多于X张，你将手牌弃置至X张（X为你的体力上限）",
				"mengzhanc_showCards":"明置的手牌",
			},
		};
		if(lib.device||lib.node){
			for(var i in mengzhanc.character){mengzhanc.character[i][4].push('ext:扩展ol/'+i+'.jpg');}
		}else{
			for(var i in mengzhanc.character){mengzhanc.character[i][4].push('db:extension-扩展ol:'+i+'.jpg');}
		}
		return mengzhanc;
	});
	lib.group.push('meng');
	lib.translate.meng='萌';
	lib.config.all.characters.push('mengzhanc');
	if(!lib.config.characters.contains('mengzhanc')) lib.config.characters.push('mengzhanc');
	lib.translate['mengzhanc_character_config']='<span style="font-size:15px;font-weight:600">萌战competition</span>';
}