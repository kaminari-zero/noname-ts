window.func = function (lib, game, ui, get, ai, _status) {
	if (lib.brawl) {
		lib.brawl.gongchengmoshi = {
			name: '攻城模式',
			mode: 'chess',
			intro: [
				'红方城池位于右下角，蓝方城池位于左上角。',
				'当一方的城池体力为零时，游戏结束。',
				'蓝方城池开始时，若游戏人数为三，比较双方城池的体力值，体力值大的一方获胜。',
				'回合开始前，若角色与自方城池距离小于或等于一，玩家恢复一点体力。',
				'我方攻破敌方城池后，你获得三点积分。<br><br><br><br>注：<br>城池是自身技能驱动的，若城池技能被删除，规则也会被破坏。'],
			content: {
				gameStart: function () {
					//ui.chess.setBackgroundImage('extension/扩展ol/ALD_ailudi1.jpg');
				},
			},
			init: function () {
				Object.defineProperty(ui, 'chessheight', {
					get: function () {
						return chessheight;
					},
					set: function () {
						chessheight = 15;
					}
				});
				Object.defineProperty(ui, 'chesswidth', {
					get: function () {
						return chesswidth;
					},
					set: function () {
						chesswidth = 15;
					}
				});
				game.saveConfig('chess_obstacle', '0', 'chess');
				game.saveConfig('single_control', false, 'chess');
				game.saveConfig('seat_order', '交替', 'chess');
				game.saveConfig('chess_mode', 'combat', 'chess');
				var character = {
					"蓝方城池": ["", "", 20, ["shenglitiaojian1", "threatencfz"],["ext:扩展ol/蓝方城池.jpg","forbidai"]],
					"红方城池": ["", "", 20, ["shenglitiaojian2", "threatencfz"],["ext:扩展ol/红方城池.jpg","forbidai"]],
				};
				for(var i in character){
					lib.character[i]=character[i];
				};
				var skill = {
					_addcheng: {
						trigger: {
							player: "gameDrawAfter",
						},
						forced: true,
						filter:function(event,player){
							return _status.hasAddcheng!=true;
						},
						content: function () {
							_status.hasAddcheng=true;
							var chengFriend = game.addChessPlayer("红方城池",true,0);
							chengFriend.moveTo(15, 15);
							chengFriend.setIdentity('城');
							chengFriend.phase=function(){};
							chengFriend.draw=function(){};
							chengFriend.recover=function(){};
							for (var i = 0; i < game.players.length; i++) {
								var xy = game.players[i].getXY();
								if (xy[0] == 15 && xy[1] == 15) game.swapSeat(game.players[i], chengFriend);
							};
							chengFriend.moveTo=function(){};
							var chengEnemy = game.addChessPlayer("蓝方城池",false,0);
							chengEnemy.moveTo(0, 0);
							chengEnemy.setIdentity('城');
							chengEnemy.phase=function(){};
							chengEnemy.draw=function(){};
							chengEnemy.recover=function(){};
							for (var i = 0; i < game.players.length; i++) {
								var xy = game.players[i].getXY();
								if (xy[0] == 0 && xy[1] == 0) game.swapSeat(game.players[i], chengEnemy);
							};
							chengEnemy.moveTo=function(){};
						},
					},
					shenglitiaojian1: {
						trigger: {
							player: "dying",
						},
						forced: true,
						popup:false,
						content: function () {
							if (game.me.side == true) {
								game.over(true);
							}else {
								game.over(false);
							}
						},
					},
					shenglitiaojian2: {
						trigger: {
							player: "dying",
						},
						forced: true,
						popup:false,
						content: function () {
							if (game.me.side == false) {
								game.over(true);
							}else {
								game.over(false);
							}
						},
					},
					threatencfz: {
						ai: {
							threaten: 10,
						}
					},
					_chengBuff: {
						trigger: {
							player: 'phaseBefore'
						},
						forced: true,
						popup:false,
						content: function () {
							for (var i = 0; i < game.players.length; i++) {
								if (game.players[i].name=='蓝方城池'||game.players[i].name=='红方城池') {
									if (game.players[i] !== player && get.distance(player, game.players[i]) <= 1) {
										if (player.side == game.players[i].side) player.recover();
									};
								};
							};
						},
					},
				};
				for(var i in skill){
					lib.skill[i]=skill[i];
				};
				var translate = {
					"蓝方城池": "蓝方城池",
					"红方城池": "红方城池",
				};
				for(var i in translate){
					lib.translate[i]=translate[i];
				};
			},
		};
	};
}