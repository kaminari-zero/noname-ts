window.func=function(lib,game,ui,get,ai,_status){
	game.say1=function(str,num){
		if(game.game_say_dialog_height==undefined) game.game_say_dialog_height=-45;
		var func=function(){
			game.game_say_dialog_onOpened=true;
			game.game_say_dialog_height+=45;
			var dialog=ui.create.dialog('hidden');
			dialog.classList.add('static');
			dialog.add('<div class="text" style="word-break:break-all;display:inline"><span style="color:#FFFFFF;">'+str+'</span></div>');
			dialog.classList.add('popped');
			dialog.style['font-family']="'STXinwei','xinwei'";
			dialog.style['background-image']='linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4))';
			dialog.style['box-shadow']='rgba(0, 0, 0, 0.4) 0 0 0 1px, rgba(0, 0, 0, 0.2) 0 3px 10px';
			ui.window.appendChild(dialog);
			var width=str.length*20;
			if(num!=undefined) width-=num*20;
			dialog._mod_height=-16;
			dialog.style.width=width+'px';
			lib.placePoppedDialog(dialog,{
				clientX:(this.offsetLeft+this.offsetWidth/2)*game.documentZoom,
				clientY:(this.offsetTop+this.offsetHeight/4)*game.documentZoom
			});
			if(dialog._mod_height) dialog.content.firstChild.style.padding=0;
			dialog.style.left='calc(50% - '+(width+16)/2+'px'+')';
			dialog.style.top='calc(5% + '+game.game_say_dialog_height+'px)';
			dialog.style['z-index']=999999;
			setTimeout(function(){
				dialog.delete();
				if(game.game_say_dialog_height>135) game.game_say_dialog_height=0;
			},1500);
			setTimeout(function(){
				delete game.game_say_dialog_onOpened;
			},500);
		};
		var interval=setInterval(function(){
			if(game.game_say_dialog_onOpened==undefined){
				func();
				clearInterval(interval);
			};
		},200);
	};
game.say2=function(str){
var dialog=ui.create.dialog('hidden');
dialog.classList.add('static');
dialog.add('<div class="text" style="word-break:break-all;display:inline">'+str+'</div>');
dialog.classList.add('popped');
ui.window.appendChild(dialog);
var width=dialog.content.firstChild.firstChild.offsetWidth;
if(width<500){
dialog._mod_height=-16;
}
else{
dialog.content.firstChild.style.textAlign='left';
}
dialog.style.width=(width+16)+'px';
lib.placePoppedDialog(dialog,{
clientX:(this.offsetLeft+this.offsetWidth/2)*game.documentZoom,
clientY:(this.offsetTop+this.offsetHeight/4)*game.documentZoom
});

if(dialog._mod_height){
dialog.content.firstChild.style.padding=0;
}
dialog.style.left='calc(50% - '+(width+16)/2+'px'+')';
dialog.style.top='calc(50% - 150px)';
setTimeout(function(){
dialog.delete();
},2000);
};
}