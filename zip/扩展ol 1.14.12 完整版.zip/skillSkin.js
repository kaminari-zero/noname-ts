window.func = function (lib, game, ui, get, ai, _status) {
	if (lib.config.kzol_skillSkin == undefined) game.saveConfig('kzol_skillSkin', {});
	if (lib.config.kzol_skillSkinEquiping == undefined) game.saveConfig('kzol_skillSkinEquiping', {});
	lib.skillSkin = {
		'强弩神射': {
			value: 300,
			owner: 'hnyhzr后羿ol',
			skills: ['nyhzr强弩'],
		},
		'幻影射手': {
			value: 990,
			owner: 'hnyhzr后羿ol',
			skills: ['nyhzr强化'],
		},
		'银月箭华': {
			value: 500,
			owner: 'hnyhzr后羿ol',
			skills: ['nyhzr银箭ol'],
		},
		'皎月王侯': {
			value: 800,
			owner: 'hnyhzr后羿ol',
			skills: ['nhyzr皎月之力'],
		},
		'黄金之翼': {
			value: 750,
			owner: 'hnyhzr后羿ol',
			skills: ['nyhzr黄金羽翼'],
		},
		'紫耀异星': {
			value: 990,
			owner: 'hnyhzr后羿ol',
			maxHp:-1,
			skills: ['nyhzr紫耀异星','nyhzr颠倒灵魂ol'],
		},
	};
	var bool = false;
	for (var i in lib.skillSkin) {
		if (lib.config.kzol_skillSkin[i] == undefined) {
			lib.config.kzol_skillSkin[i] = false;
			bool = true;
		};
	};
	game.saveConfig('kzol_skillSkin', lib.config.kzol_skillSkin);
	for(var i in lib.config.kzol_skillSkinEquiping){
		if(lib.character[i][4]!=undefined){
			var bool=false;
			for(var j=0;j<lib.character[i][4].length;j++){
				if(lib.character[i][4][j].indexOf('ext:扩展ol/')!=-1){
					lib.character[i][4][j]='ext:扩展ol/'+lib.config.kzol_skillSkinEquiping[i]+'.jpg';
					bool=true;
				};
			};
			if(bool==false) lib.character[i][4].push('ext:扩展ol/'+lib.config.kzol_skillSkinEquiping[i]+'.jpg');
		};
		var skills=lib.skillSkin[lib.config.kzol_skillSkinEquiping[i]].skills;
		var skills1=[];
		for(var j=0;j<skills.length;j++){
			skills1.unshift(skills[j]);
		};
		for(var j=0;j<skills1.length;j++){
			lib.character[i][3].unshift(skills1[j]);
		};
		var maxHp=lib.skillSkin[lib.config.kzol_skillSkinEquiping[i]].maxHp;
		if(maxHp!=undefined){
			lib.character[i][2]+=maxHp;
		};
	};
	var translate = {
		"nyhzr强弩": "强弩",
		"nyhzr强弩_info": "<span class=\"bluetext\" style=\"color:#EE7621\">被动：</span>当你的体力大于二时，你造成的伤害+1，你受到的伤害+1",
		"nyhzr强化":"强化",
		"nyhzr强化_info":"<span class=\"bluetext\" style=\"color:#EE7621\">被动：</span>游戏中，你可以通过提升能力等级来强化自身基本属性",
		"nyhzr银箭ol":"银箭",
		"nyhzr银箭ol_info":"<span class=\"bluetext\" style=\"color:#EE7621\">被动：</span><br>燎火之箭转化后的属性变为雷属性<br>当你造成雷属性伤害时，你随机复制目标一项技能",
		"nhyzr皎月之力":"皎月之力",
		"nhyzr皎月之力_info":"每个回合末，你可以流失一点体力进行一个额外的回合（无法连续使用），在额外的回合中，你使用的卡牌没有数量和距离限制",
		"nyhzr黄金羽翼":"黄金羽翼",
		"nyhzr黄金羽翼_info":"<span class=\"bluetext\" style=\"color:#EE7621\">被动：</span><li>场上除了对你造成的伤害外的伤害均视为由你造成<li>你造成伤害后，与被伤害者交换座位",
		"nyhzr紫耀异星":"紫耀异星",
		"nyhzr紫耀异星_info":"<span class=\"bluetext\" style=\"color:#EE7621\">被动：</span><li>你的体力上限-1<li>你获得技能【颠倒灵魂】",
	};
	for (var i in translate) {
		lib.translate[i] = translate[i];
	};
	var skill = {
		"nyhzr强弩": {
			nobracket: true,
			group: ["nyhzr强弩_1", "nyhzr强弩_2"],
			subSkill: {
				1: {
					trigger: {
						source: "damageBegin",
					},
					filter: function (event, player) {
						return player.hp > 2;
					},
					forced: true,
					content: function () {
						trigger.num++;
					},
				},
				2: {
					trigger: {
						player: "damageBegin",
					},
					forced: true,
					filter: function (event, player) {
						return player.hp > 2;
					},
					content: function () {
						trigger.num++;
					},
				},
			},
		},
		"nyhzr强化": {
			nobracket: true,
			group: ["nyhzr强化_攻击等级获得", "nyhzr强化_速度等级获得", "nyhzr强化_闪避等级获得", "nyhzr强化_暴击等级获得", "nyhzr强化_防御等级获得", "nyhzr强化_攻击等级", "nyhzr强化_速度等级", "nyhzr强化_闪避等级", "nyhzr强化_暴击等级", "nyhzr强化_防御等级"],
			subSkill: {
				"攻击等级获得": {
					trigger: {
						global: "gameDrawAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_攻击等级获得 == undefined) player.storage.nyhzr强化_攻击等级获得 = 0;
						player.markSkill('nyhzr强化_攻击等级获得');
					},
					marktext: "攻",
					intro: {
						content: function (storage) {
							return '<li>当前攻击等级为：' + storage + '级' + '<li>攻击二级=造成伤害+1' + '<li>攻击等级最高6级' + '<li>造成伤害后攻击等级+1'
						},
					},
				},
				"速度等级获得": {
					trigger: {
						global: "gameDrawAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_速度等级获得 == undefined) player.storage.nyhzr强化_速度等级获得 = 0;
						player.markSkill('nyhzr强化_速度等级获得');
					},
					marktext: "速",
					intro: {
						content: function (storage) {
							return '<li>当前速度等级为：' + storage + '级' + '<li>速度一级=回合末1%进行一个额外的回合' + '<li>速度等级最高6级' + '<li>回合末速度等级+1'
						},
					},
				},
				"闪避等级获得": {
					trigger: {
						global: "gameDrawAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_闪避等级获得 == undefined) player.storage.nyhzr强化_闪避等级获得 = 0;
						player.markSkill('nyhzr强化_闪避等级获得');
					},
					marktext: "闪",
					intro: {
						content: function (storage) {
							return '<li>当前闪避等级为：' + storage + '级' + '<li>闪避一级=受到伤害1%闪避' + '<li>闪避等级最高6级' + '<li>受到伤害闪避等级+1'
						},
					},
				},
				"暴击等级获得": {
					trigger: {
						global: "gameDrawAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_暴击等级获得 == undefined) player.storage.nyhzr强化_暴击等级获得 = 0;
						player.markSkill('nyhzr强化_暴击等级获得');
					},
					marktext: "暴",
					intro: {
						content: function (storage) {
							return '<li>当前暴击等级为：' + storage + '级' + '<li>暴击一级=造成伤害后1%+1' + '<li>暴击等级最高6级' + '<li>造成伤害暴击等级+1'
						},
					},
				},
				"防御等级获得": {
					trigger: {
						global: "gameDrawAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_防御等级获得 == undefined) player.storage.nyhzr强化_防御等级获得 = 0;
						player.markSkill('nyhzr强化_防御等级获得');
					},
					marktext: "防",
					intro: {
						content: function (storage) {
							return '<li>当前防御等级为：' + storage + '级' + '<li>防御五级=受到伤害-1' + '<li>防御等级最高10级' + '<li>受到伤害防御等级+1'
						},
					},
				},
				"攻击等级": {
					trigger: {
						source: "damageBegin",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_暴击等级获得 <= 6) {
							player.storage.nyhzr强化_暴击等级获得 += 1;
							player.syncStorage('nyhzr强化_暴击等级获得');
						}
						if (player.storage.nyhzr强化_攻击等级获得 >= 2 && player.storage.nyhzr强化_攻击等级获得 < 4) {
							trigger.num += 1;
						}
						if (player.storage.nyhzr强化_攻击等级获得 >= 4 && player.storage.nyhzr强化_攻击等级获得 < 6) {
							trigger.num += 2;
						}
						if (player.storage.nyhzr强化_攻击等级获得 >= 6) {
							trigger.num += 3;
						}
						if (player.storage.nyhzr强化_攻击等级获得 <= 6) {
							player.storage.nyhzr强化_攻击等级获得 += 1;
							player.syncStorage('nyhzr强化_攻击等级获得');
						}
					},
				},
				"速度等级": {
					trigger: {
						player: "phaseAfter",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_速度等级获得 <= 6) {
							player.storage.nyhzr强化_速度等级获得 += 1;
							player.syncStorage('nyhzr强化_速度等级获得');
						}
						if (Math.random() <= player.storage.nyhzr强化_速度等级获得 * 0.01) {
							player.phase();
							game.log(player, '的速度快，进行一个额外的回合');
						}
					},
				},
				"闪避等级": {
					trigger: {
						player: "damageBegin",
					},
					filter: function (event, player) {
						if (Math.random() > player.storage.nyhzr强化_闪避等级获得 * 0.01) return false;
						return true;
					},
					forced: true,
					content: function () {
						trigger.untrigger();
						trigger.finish();
						game.log(player, '闪避了对方的攻击');
					},
				},
				"暴击等级": {
					trigger: {
						source: "damageBegin",
					},
					filter: function (event, player) {
						if (Math.random() > player.storage.nyhzr强化_暴击等级获得 * 0.1) return false;
						return true;
					},
					forced: true,
					content: function () {
						trigger.num += 1;
						game.log(player, '暴击了');
					},
				},
				"防御等级": {
					trigger: {
						player: "damageBegin",
					},
					forced: true,
					content: function () {
						if (player.storage.nyhzr强化_闪避等级获得 <= 6) {
							player.storage.nyhzr强化_闪避等级获得 += 1;
							player.syncStorage('nyhzr强化_闪避等级获得');
						}
						if (player.storage.nyhzr强化_防御等级获得 <= 6) {
							player.storage.nyhzr强化_防御等级获得 += 1;
							player.syncStorage('nyhzr强化_防御等级获得');
						}
						if (player.storage.nyhzr强化_防御等级获得 >= 5 && player.storage.nyhzr强化_防御等级获得 < 10) {
							trigger.num -= 1;
						}
						if (player.storage.nyhzr强化_防御等级获得 >= 10) {
							trigger.num -= 2;
						}
					},
				},
			},
		},
		"nyhzr银箭ol": {
			nobracket: true,
			trigger: {
				source: "damageEnd",
			},
			filter: function (event) {
				return event.nature == 'thunder';
			},
			forced: true,
			content: function () {
				var skill = trigger.player.get('s', false, false).randomGet();
				game.log(player, '获得了【', lib.translate[skill], '】');
				player.addSkill(skill);
			},
		},
		"nhyzr皎月之力1": {
			nobracket: true,
			mod: {
				cardUsable: function (card) {
					if (get.info(card) && get.info(card).forceUsable) return;
					return Infinity;
				},
				targetInRange: function () {
					return true;
				},
			},
			trigger: {
				player: "phaseEnd",
			},
			forced: true,
			popup:false,
			content: function () {
				player.addSkill('nhyzr皎月之力');
				player.removeSkill('nhyzr皎月之力1');
			}
		},
		"nhyzr皎月之力": {
			nobracket: true,
			trigger: {
				player: "phaseEnd",
			},
			content: function () {
				player.loseHp();
				player.phase();
				player.addSkill('nhyzr皎月之力1');
				player.removeSkill('nhyzr皎月之力');
			},
			check: function (event, player) {
				if (player.num('h') < 2) return false;
				if (player.hp < 2) return false;
				return true;
			},
		},
		"nyhzr黄金羽翼": {
			nobracket: true,
			group: ["nyhzr黄金羽翼_1", "nyhzr黄金羽翼_2"],
			subSkill: {
				1: {
					trigger: {
						global: "damageBefore",
					},
					forced: true,
					filter: function (event, player) {
						return event.source != player && event.player != player;
					},
					content: function () {
						trigger.source = player;
					},
				},
				2: {
					trigger: {
						source: 'damageEnd'
					},
					forced: true,
					content: function () {
						game.swapSeat(trigger.player, player);
					}
				},
			}
		},
		"nyhzr紫耀异星": {
			nobracket: true,
		},
	};
	for (var i in skill) {
		lib.skill[i] = skill[i];
	};
	lib.kzol_charactercard_func['createSkillSkin']=function(name,sourcenode,noedit,resume,avatar){
		var list=[];
		for(var i in lib.skillSkin){
			if(lib.skillSkin[i].owner==name) list.push(i);
		};
		if(list.length==0) return ;
		var dialog=ui.create.dialog('hidden');
		dialog.classList.add('popped');
		dialog.classList.add('static');
		dialog.style.height='105px';
		dialog.style.width='500px';
		dialog.style.left='calc(50% - 250px)';
		dialog.style.top='calc(50% + 154px)';
		dialog.style['z-index']=99999;
		var divs={};
		for(var i=0;i<list.length;i++){
			var name=list[i];
			var skin=lib.skillSkin[name];
			var div=ui.create.div('.shadowed.reduce_radius');
			div.style.height='90px';
			div.style.width='75px';
			div.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+name+'.jpg")';
			div.style.backgroundSize="cover";
			div.link=name;
			div.onclick=function(){
				var name=this.link;
				var skin=lib.skillSkin[name];
				if(_status.skillSkin_clickTimes==undefined) _status.skillSkin_clickTimes=0;
				_status.skillSkin_clickTimes++;
				_status.skillSkin_clickTimes_timeout=setTimeout(function(){
					if(_status.skillSkin_clickTimes==1){
						if(lib.config.kzol_skillSkin[name]==true){
							if(lib.config.kzol_skillSkinEquiping[skin.owner]==name){
								delete lib.config.kzol_skillSkinEquiping[skin.owner];
								game.saveConfig('kzol_skillSkinEquiping',lib.config.kzol_skillSkinEquiping);
								game.say1(get.translation(skin.owner)+'卸下了技能皮肤：'+name);
							}else{
								lib.config.kzol_skillSkinEquiping[skin.owner]=name;
								game.saveConfig('kzol_skillSkinEquiping',lib.config.kzol_skillSkinEquiping);
								game.say1(get.translation(skin.owner)+'装备了技能皮肤：'+name);
							};
						}else{
							if(skin.value>=0&&game.getItem('shuijing')!=false){
								if(confirm('是否花费'+skin.value+'水晶购买'+name+'?')){
									if(lib.config.kzol_bag[game.getItem('shuijing')].num>skin.value){
										game.loseItem('shuijing',skin.value,false);
										lib.config.kzol_skillSkin[name]=true;
										game.saveConfig('kzol_skillSkin', lib.config.kzol_skillSkin);
										game.say1('花费了'+skin.value+'水晶');
										game.say1('获得了技能皮肤：'+name+'（'+get.translation(skin.owner)+'）');
									}else{
										game.say1('水晶不足');
									};
								};
							}else if(skin.value<0){
								game.say1('该技能皮肤是非卖品');
							}else{
								if(confirm('是否花费'+skin.value+'水晶购买'+name+'?')){
									game.say1('水晶不足');
								};
							};
						};
					}else{
						if(_status.openingSkillSkin!=true){
							lib.character['kzol_skillSkin_'+name]=['','','',skin.skills,["ext:扩展ol/"+name+".jpg","des:"+get.translation(skin.owner)+"的技能皮肤","skillSkin"]];
							game.kzol_charactercard('kzol_skillSkin_'+name);
						};
					};
					delete _status.skillSkin_clickTimes;
					delete _status.skillSkin_clickTimes_timeout;
				},250);
			};
			var sname=ui.create.div(div);
			sname.style.height='20px';
			sname.style.width='75px';
			sname.style.bottom='0px';
			sname.style.left='0px';
			sname.innerHTML='<span style="font-family:xinwei">'+name+'</span>';
			if(lib.config.kzol_skillSkin[name]==false||lib.config.kzol_skillSkin[name]==undefined) div.classList.add('out');
			divs[name]=div;
			dialog.add(div);
		};
		var div_interval=setInterval(function(){
			for(var i in divs){
				var div=divs[i];
				if(lib.config.kzol_skillSkin[i]!=false&&lib.config.kzol_skillSkin[i]!=undefined&&div.classList.contains('out')) div.classList.remove('out');
				if(lib.config.kzol_skillSkinEquiping[lib.skillSkin[i].owner]==i){
					div.classList.add('selected');
				}else if(div.classList.contains('selected')){
					div.classList.remove('selected');
				};
			};
		},150);;
		ui.window.appendChild(dialog);
		var interval=setInterval(function(){
			if(_status.openingSkillSkin==true){
				dialog.hide();
			}else{
				dialog.show();
			};
			if((lib.config.theme=='simple'&&!ui.window.classList.contains('systempaused'))||(lib.config.theme!='simple'&&!ui.window.classList.contains('shortcutpaused'))){
				clearInterval(div_interval);
				dialog.delete();
				clearInterval(interval);
			};
		},100);
	};
	game.kzol_charactercard=function(name,sourcenode,noedit,resume,avatar){
		if(_status.dragged) return;
		_status.openingSkillSkin=true;
		var layer=ui.create.div('.popup-container');
		var clicklayer=function(e){
			delete lib.character[name];
			delete _status.openingSkillSkin;
			this.delete();
		}
		var uiintro=ui.create.div('.menubg.charactercard',layer);
		var playerbg=ui.create.div('.menubutton.large.ava',uiintro);
		var bg=ui.create.div('.avatar',playerbg,function(){
			if(changeskinfunc){
				changeskinfunc();
			}
		}).setBackground(name,'character');
		var changeskinfunc=null;
		var intro=ui.create.div('.characterintro',get.characterIntro(name),uiintro);
		var intro2=ui.create.div('.characterintro.intro2',uiintro);
		var list=get.character(name,3)||[];
		var skills=ui.create.div('.characterskill',uiintro);
		if(lib.config.touchscreen){
			lib.setScroll(intro);
			lib.setScroll(intro2);
			lib.setScroll(skills);
		}

		if(lib.config.mousewheel){
			skills.onmousewheel=ui.click.mousewheel;
		}
		var clickSkill=function(e){
			var current=this.parentNode.querySelector('.active');
			if(current){
				current.classList.remove('active');
			}
			this.classList.add('active');
			intro2.innerHTML='<span style="font-weight:bold;margin-right:5px">'+get.translation(this.link)+'</span>'+get.skillInfoTranslation(this.link);
			var info=get.info(this.link);
			var skill=this.link;
			var skillnode=this;
			if(info.derivation){
				var derivation=info.derivation;
				if(typeof derivation=='string'){
					derivation=[derivation];
				}
				for(var i=0;i<derivation.length;i++){
					intro2.innerHTML+='<br><br><span style="font-weight:bold;margin-right:5px">'+get.translation(derivation[i])+'</span>'+get.skillInfoTranslation(derivation[i]);
				}
			}
			if(info.alter){
				intro2.innerHTML+='<br><br><div class="hrefnode skillversion"></div>';
				var skillversionnode=intro2.querySelector('.hrefnode.skillversion');
				if(lib.config.vintageSkills.contains(skill)){
					skillversionnode.innerHTML='切换至新版';
				}
				else{
					skillversionnode.innerHTML='切换至旧版';
				}
				skillversionnode.listen(function(){
					if(lib.config.vintageSkills.contains(skill)){
						lib.config.vintageSkills.remove(skill);
						lib.translate[skill+'_info']=lib.translate[skill+'_info_alter'];
					}
					else{
						lib.config.vintageSkills.push(skill);
						lib.translate[skill+'_info']=lib.translate[skill+'_info_origin'];
					}
					game.saveConfig('vintageSkills',lib.config.vintageSkills);
					clickSkill.call(skillnode,'init');
				});
			}
			if(lib.config.background_speak&&e!=='init'){
				var audioname=this.link;
				var audioinfo=info.audio;
				var that=this;
				var getIndex=function(i){
					if(typeof that.audioindex!='number'){
						that.audioindex=i;
					}
					that.audioindex++;
					if(that.audioindex>i){
						that.audioindex=1;
					}
					return that.audioindex;
				};
				if(typeof audioinfo=='string'){
					if(audioinfo.indexOf('ext:')==0){
						audioinfo=audioinfo.split(':');
						if(audioinfo.length==3){
							if(audioinfo[2]=='true'){
								game.playAudio('..','extension',audioinfo[1],audioname);
							}
							else{
								audioinfo[2]=parseInt(audioinfo[2]);
								if(audioinfo[2]){
									game.playAudio('..','extension',audioinfo[1],audioname+getIndex(audioinfo[2]));
								}
							}
						}
						return;
					}
					else{
						audioname=audioinfo;
						if(lib.skill[audioinfo]){
							audioinfo=lib.skill[audioinfo].audio;
						}
					}
				}
				else if(Array.isArray(audioinfo)){
					audioname=audioinfo[0];
					audioinfo=audioinfo[1];
				}
				if(typeof audioinfo=='number'){
					game.playAudio('skill',audioname+getIndex(audioinfo));
				}
				else if(audioinfo){
					game.playAudio('skill',audioname);
				}
				else if(true&&info.audio!==false){
					game.playSkillAudio(audioname,getIndex(2));
				}
			}
		}
		var initskill=false;
		for(var i=0;i<list.length;i++){
			if(!get.info(list[i])||get.info(list[i]).nopop) continue;
			if(!lib.translate[list[i]]||!lib.translate[list[i]+'_info']) continue;
			var skilltrans=get.translation(list[i]);
			if(skilltrans.indexOf('&nbsp;')==0){
				skilltrans=skilltrans.slice(6);
			}
			var current=ui.create.div('.menubutton.large',skills,clickSkill,skilltrans);
			current.link=list[i];
			if(!initskill){
				initskill=true;
				clickSkill.call(current,'init');
			}
		}

		uiintro.addEventListener(lib.config.touchscreen?'touchend':'click',ui.click.touchpop);
		layer.addEventListener(lib.config.touchscreen?'touchend':'click',clicklayer);
		ui.window.appendChild(layer);
	}
}