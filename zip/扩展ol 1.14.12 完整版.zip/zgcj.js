window.func=function(lib,game,ui,get,ai,_status){
	var date=new Date();
	if(lib.config.achievement==undefined) game.saveConfig('achievement',{course:{},wu:{},shu:{},wei:{},qun:{}});
	var achievement={
		course:{
			'chuchumaolu':{
				name:'初出茅庐',
				condition:{
					1:{
						info:'进行一局游戏',
						t_name:'chuchumaolu',
						need_times:1,
					},
				},
			},
			'chushishenshou':{
				name:'初试身手',
				condition:{
					1:{
						info:'进行五局游戏',
						t_name:'chuchumaolu',
						need_times:5,
					},
				},
			},
			'xiaoshiniudao':{
				name:'小试牛刀',
				condition:{
					1:{
						info:'进行十局游戏',
						t_name:'chuchumaolu',
						need_times:10,
					},
				},
			},
			'xiaoyoumingqi':{
				name:'小有名气',
				condition:{
					1:{
						info:'进行二十局游戏',
						t_name:'chuchumaolu',
						need_times:20,
					},
				},
			},
			'fengmangbilu':{
				name:'锋芒毕露',
				condition:{
					1:{
						info:'进行三十局游戏',
						t_name:'chuchumaolu',
						need_times:30,
					},
				},
			},
			'chuchangshengguo':{
				name:'初尝胜果',
				condition:{
					1:{
						info:'获得一局胜利',
						t_name:'chuchangshengguo',
						need_times:1,
					},
				},
			},
			'chujishashou':{
				name:'初级杀手',
				condition:{
					1:{
						info:'获得五局胜利',
						t_name:'chuchangshengguo',
						need_times:5,
					},
				},
			},
			'zhongjishashou':{
				name:'中级杀手',
				condition:{
					1:{
						info:'获得十局胜利',
						t_name:'chuchangshengguo',
						need_times:10,
					},
				},
			},
			'gaojishashou':{
				name:'高级杀手',
				condition:{
					1:{
						info:'获得二十局胜利',
						t_name:'chuchangshengguo',
						need_times:20,
					},
				},
			},
			'quanzhishashou':{
				name:'全职杀手',
				condition:{
					1:{
						info:'获得三十局胜利',
						t_name:'chuchangshengguo',
						need_times:30,
					},
				},
			},
		},
		wu:{
			'nianqingdexianjun':{
				name:'年轻的贤君',
				condition:{
					1:{
						info:'使用孙权获得100场胜利',
						owner:'sunquan',
						t_name:'nianqingdexianjun',
						need_times:100,
					},
				},
			},
			'nianqingyouwei':{
				name:'年轻有为',
				condition:{
					1:{
						info:'使用孙权在一局游戏中被吴国武将用桃救至少3次',
						t_name:'nianqingyouwei',
						need_times:3,
					},
				},
			},
			'jinfanyouxia':{
				name:'锦帆游侠',
				condition:{
					1:{
						info:'使用甘宁获得100场胜利',
						owner:'ganning',
						t_name:'jinfanyouxia',
						need_times:100,
					},
				},
			},
			'shenchuguimo':{
				name:'神出鬼没',
				condition:{
					1:{
						info:'使用甘宁在一个回合内至少发动6次奇袭',
						t_name:'shenchuguimo',
						need_times:6,
					},
				},
			},
			'qingshenweiguo':{
				name:'轻身为国',
				condition:{
					1:{
						info:'使用黄盖获得100场胜利',
						owner:'huanggai',
						t_name:'qingshenweiguo',
						need_times:100,
					},
				},
			},
			'wujindebianta':{
				name:'无尽的鞭挞',
				condition:{
					1:{
						info:'使用黄盖在一个回合内至少发动8次苦肉',
						t_name:'wujindebianta',
						need_times:8,
					},
				},
			},
			'baiyidujiang':{
				name:'白衣渡江',
				condition:{
					1:{
						info:'使用吕蒙获得100场胜利',
						owner:'lvmeng',
						t_name:'baiyidujiang',
						need_times:100,
					},
				},
			},
			'sijidaifa':{
				name:'伺机待发',
				condition:{
					1:{
						info:'使用吕蒙将手牌囤积到20张',
						t_name:'sijidaifa',
						need_times:20,
					},
				},
			},
			'jinchizhihua':{
				name:'矜持之花',
				condition:{
					1:{
						info:'使用大乔获得100场胜利',
						owner:'daqiao',
						t_name:'jinchizhihua',
						need_times:100,
					},
				},
			},
			'yihuajiemu':{
				name:'移花接木',
				condition:{
					1:{
						info:'使用大乔在一局游戏中连续发动流离至少5次',
						t_name:'yihuajiemu',
						need_times:5,
					},
				},
			},
			'gongyaoji':{
				name:'弓腰姬',
				condition:{
					1:{
						info:'使用孙尚香获得100场胜利',
						owner:'sunshangxiang',
						t_name:'gongyaoji',
						need_times:100,
					},
				},
			},
			'yinhuodefu':{
				name:'因祸得福',
				condition:{
					1:{
						info:'使用孙尚香在一局游戏中累积失去至少5张已装备的装备牌',
						t_name:'yinhuodefu',
						need_times:5,
					},
				},
			},
			'dadudu':{
				name:'大都督',
				condition:{
					1:{
						info:'使用周瑜获得100场胜利',
						owner:'zhouyu',
						t_name:'dadudu',
						need_times:100,
					},
				},
			},
			'wujindezhengzha':{
				name:'无尽的挣扎',
				condition:{
					1:{
						info:'使用周瑜在一局游戏中使用反间击败至少3名角色',
						t_name:'wujindezhengzha',
						need_times:3,
					},
				},
			},
			'rushengxiongcai':{
				name:'儒生雄才',
				condition:{
					1:{
						info:'使用陆逊获得100场胜利',
						owner:'luxun',
						t_name:'rushengxiongcai',
						need_times:100,
					},
				},
			},
			'lianmianbujue':{
				name:'连绵不绝',
				condition:{
					1:{
						info:'使用陆逊在一个回合内发动至少10次连营',
						t_name:'lianmianbujue',
						need_times:10,
					},
				},
			},
		},
		shu:{
			'luanshidexiaoxiong':{
				name:'乱世的枭雄',
				condition:{
					1:{
						info:'使用刘备获得100场胜利',
						owner:'liubei',
						t_name:'luanshidexiaoxiong',
						need_times:100,
					},
				},
			},
			'jiujiezhixin':{
				name:'纠结之心',
				condition:{
					1:{
						info:'使用刘备在一局游戏中发动雌雄双股剑特效击败至少1名女性角色',
						t_name:'jiujiezhixin',
						need_times:1,
					},
				},
			},
			'wanfubudang':{
				name:'万夫不当',
				condition:{
					1:{
						info:'使用张飞获得100场胜利',
						owner:'zhangfei',
						t_name:'wanfubudang',
						need_times:100,
					},
				},
			},
			'yanrendepaoxiao':{
				name:'燕人的咆哮',
				condition:{
					1:{
						info:'使用张飞在一局游戏中发动丈八蛇矛特效击败至少1名角色',
						t_name:'yanrendepaoxiao',
						need_times:1,
					},
				},
			},
			'yiqidangqian':{
				name:'一骑当千',
				condition:{
					1:{
						info:'使用马超获得100场胜利',
						owner:'machao',
						t_name:'yiqidangqian',
						need_times:100,
					},
				},
			},
			'quanjuntuji':{
				name:'全军突击',
				condition:{
					1:{
						info:'使用马超在一局游戏中发动铁骑连续判定红色花色至少5次',
						t_name:'quanjuntuji',
						need_times:5,
					},
				},
			},
			'meirangong':{
				name:'美髯公',
				condition:{
					1:{
						info:'使用关羽获得100场胜利',
						owner:'guanyu',
						t_name:'meirangong',
						need_times:100,
					},
				},
			},
			'wushengxianling':{
				name:'武圣显灵',
				condition:{
					1:{
						info:'使用关羽在一局游戏中发动青龙偃月刀特效击败至少1名角色（国战模式下无法完成）',
						t_name:'wushengxianling',
						need_times:1,
					},
				},
			},
			'shaonianjiangjun':{
				name:'少年将军',
				condition:{
					1:{
						info:'使用赵云获得100场胜利',
						owner:'zhaoyun',
						t_name:'shaonianjiangjun',
						need_times:100,
					},
				},
			},
			'hunshenshidan':{
				name:'浑身是胆',
				condition:{
					1:{
						info:'使用赵云在一局游戏中发动青釭剑特效击败至少1名角色',
						t_name:'hunshenshidan',
						need_times:1,
					},
				},
			},
			'guiyindejienv':{
				name:'归隐的杰女',
				condition:{
					1:{
						info:'使用黄月英获得100场胜利',
						owner:'huangyueying',
						t_name:'guiyindejienv',
						need_times:100,
					},
				},
			},
			'jinnangdai':{
				name:'锦囊袋',
				condition:{
					1:{
						info:'使用黄月英在一个回合内至少发动10次集智',
						t_name:'jinnangdai',
						need_times:10,
					},
				},
			},
			'chimudechengxiang':{
				name:'迟暮的丞相',
				condition:{
					1:{
						info:'使用诸葛亮获得100场胜利',
						owner:'zhugeliang',
						t_name:'chimudechengxiang',
						need_times:100,
					},
				},
			},
			'kongchengjuechang':{
				name:'空城绝唱',
				condition:{
					1:{
						info:'使用诸葛亮在一局游戏中有至少5个回合结束时是空城状态',
						t_name:'kongchengjuechang',
						need_times:10,
					},
				},
			},
		},
		wei:{
			'weiwudi':{
				name:'魏武帝',
				condition:{
					1:{
						info:'使用曹操获得100场胜利',
						owner:'caocao',
						t_name:'weiwudi',
						need_times:100,
					},
				},
			},
			'luanshidejianxiong':{
				name:'乱世的奸雄',
				condition:{
					1:{
						info:'使用曹操在一局游戏中发动奸雄得到至少3张南蛮入侵和1张万箭齐发<li>南蛮入侵：',
						t_name:'luanshidejianxiong1',
						need_times:3,
					},
					2:{
						info:'万箭齐发：',
						t_name:'luanshidejianxiong2',
						need_times:1,
					},
				},
			},
			'qianjiangjun':{
				name:'前将军',
				condition:{
					1:{
						info:'使用张辽获得100场胜利',
						owner:'zhangliao',
						t_name:'qianjiangjun',
						need_times:100,
					},
				},
			},
			'shenqiwubei':{
				name:'神其无备',
				condition:{
					1:{
						info:'使用张辽在一局游戏中发动至少10次突袭',
						t_name:'shenqiwubei',
						need_times:10,
					},
				},
			},
			'duyandeluocha':{
				name:'独眼的罗刹',
				condition:{
					1:{
						info:'使用夏侯惇获得100场胜利',
						owner:'xiahoudun',
						t_name:'duyandeluocha',
						need_times:100,
					},
				},
			},
			'liangbaijushang':{
				name:'两败俱伤',
				condition:{
					1:{
						info:'使用夏侯惇在一局游戏中发动刚烈击败至少一名角色',
						t_name:'liangbaijushang',
						need_times:1,
					},
				},
			},
			'huchi':{
				name:'虎痴',
				condition:{
					1:{
						info:'使用许褚获得100场胜利',
						owner:'xuzhu',
						t_name:'huchi',
						need_times:100,
					},
				},
			},
			'mawoleng':{
				name:'妈，我冷',
				condition:{
					1:{
						info:'使用许褚在一局游戏中发动裸衣至少两次并在裸衣的回合中使用杀或决斗击败过至少2名角色<li>发动裸衣：',
						t_name:'mawoleng1',
						need_times:2,
					},
					2:{
						info:'击败角色：',
						t_name:'mawoleng2',
						need_times:2,
					},
				},
			},
			'zaozhongdexianzhi':{
				name:'早终的先知',
				condition:{
					1:{
						info:'使用郭嘉获得100场胜利',
						owner:'guojia',
						t_name:'zaozhongdexianzhi',
						need_times:100,
					},
				},
			},
			'buyiyuli':{
				name:'不遗余力',
				condition:{
					1:{
						info:'使用郭嘉在一局游戏中发动遗计给其他角色发牌至少5次',
						t_name:'buyiyuli',
						need_times:5,
					},
				},
			},
			'langguzhigui':{
				name:'狼顾之鬼',
				condition:{
					1:{
						info:'使用司马懿获得100场胜利',
						owner:'simayi',
						t_name:'langguzhigui',
						need_times:100,
					},
				},
			},
			'shouyantongtian':{
				name:'手眼通天',
				condition:{
					1:{
						info:'使用司马懿在一局游戏中有至少2次发动反馈都抽到对方1张桃',
						t_name:'shouyantongtian',
						need_times:2,
					},
				},
			},
			'boxingdemeiren':{
				name:'薄幸的美人',
				condition:{
					1:{
						info:'使用甄姬获得100场胜利',
						owner:'zhenji',
						t_name:'boxingdemeiren',
						need_times:100,
					},
				},
			},
			'luoshenfu':{
				name:'洛神赋',
				condition:{
					1:{
						info:'使用甄姬一回合内发动洛神连续判定黑色花色至少8次',
						t_name:'luoshenfu',
						need_times:8,
					},
				},
			},
		},
		qun:{
			'wudehuashen':{
				name:'武的化身',
				condition:{
					1:{
						info:'使用吕布获得100场胜利',
						owner:'lvbu',
						t_name:'wudehuashen',
						need_times:100,
					},
				},
			},
			'feijiang':{
				name:'飞将',
				condition:{
					1:{
						info:'使用吕布发动方天画戟特效使用一张杀击败至少2名角色',
						t_name:'feijiang',
						need_times:2,
					},
				},
			},
			'jueshidewuji':{
				name:'绝世的舞姬',
				condition:{
					1:{
						info:'使用貂蝉获得100场胜利',
						owner:'diaochan',
						t_name:'jueshidewuji',
						need_times:100,
					},
				},
			},
			'qingguoqingcheng':{
				name:'倾国倾城',
				condition:{
					1:{
						info:'使用貂蝉在一局游戏中发动离间造成至少3名角色被击败',
						t_name:'qingguoqingcheng',
						need_times:3,
					},
				},
			},
			'shenyi':{
				name:'神医',
				condition:{
					1:{
						info:'使用华佗获得100场胜利',
						owner:'huatuo',
						t_name:'shenyi',
						need_times:100,
					},
				},
			},
			'luanshimingyi':{
				name:'乱世名医',
				condition:{
					1:{
						info:'使用华佗在一局游戏中发动急救使至少3个不同的角色脱离求桃阶段',
						t_name:'luanshimingyi',
						need_times:3,
					},
				},
			},
			'feiyangbahu':{
				name:'飞扬跋扈',
				condition:{
					1:{
						info:'使用华雄获得100场胜利',
						owner:'huaxiong',
						t_name:'feiyangbahu',
						need_times:100,
					},
				},
			},
			'yaowuyangwei':{
				name:'耀武扬威',
				condition:{
					1:{
						info:'使用华雄在一局游戏中发动耀武至少4次并获胜',
						t_name:'yaowuyangwei',
						need_times:4,
					},
				},
			},
			'yexinjianzeng':{
				name:'野心渐增',
				condition:{
					1:{
						info:'使用袁术获得100场胜利',
						owner:'yuanshu',
						t_name:'yexinjianzeng',
						need_times:100,
					},
				},
			},
			'dengjizhizun':{
				name:'登极至尊',
				condition:{
					1:{
						info:'使用袁术在一局游戏中作为反贼或内奸对主公发动妄尊至少5次并获胜',
						t_name:'dengjizhizun',
						need_times:5,
					},
				},
			},
		}
	};
	var num=0;
	for(var i in achievement){
		var a=achievement[i];
		for(var j in a){
			var b=a[j];
			if(lib.config.achievement[i][j]==undefined){
				num++;
				lib.config.achievement[i][j]={};
				lib.config.achievement[i][j].finished=false;
				lib.config.achievement[i][j].finished_times={};
				for(var k in b.condition){
					lib.config.achievement[i][j].finished_times[b.condition[k].t_name]=0;
				};
			};
		};
	};
	if(num>0) game.saveConfig('achievement',lib.config.achievement);
	setInterval(function(){
		for(var i in lib.config.achievement){
			var a=lib.config.achievement[i];
			for(var j in a){
				var b=a[j];
				if(b.finished!=true){
					var bool=true;
					for(var k in b.finished_times){
						var need_times=Infinity;
						for(var l in achievement[i][j].condition){
							if(achievement[i][j].condition[l].t_name==k) need_times=achievement[i][j].condition[l].need_times;
						};
						if(b.finished_times[k]<need_times) bool=false;
					};
					if(bool==true){
						lib.config.achievement[i][j].finished=true;
						lib.config.achievement[i][j].finished_data=date.getFullYear()+'年'+(date.getMonth()+1)+'月'+date.getDate()+'日  '+date.getHours()+'时'+date.getMinutes()+'分'+date.getSeconds()+'秒';
						game.saveConfig('achievement',lib.config.achievement);
						game.say1('完成战功：'+achievement[i][j].name);
					};
				};
			};
		};
	},750);
	lib.onover.push(function(result){
		for(var i in lib.config.achievement.course){
			var a=lib.config.achievement.course[i];
			for(var j in a.finished_times){
				if(j=='chuchumaolu') lib.config.achievement.course[i].finished_times[j]+=1;
				if(result==true&&j=='chuchangshengguo') lib.config.achievement.course[i].finished_times[j]+=1;
			};
		};
		for(var i in achievement){
			var a=achievement[i];
			for(var j in a){
				for(var k in a[j].condition){
					if(result==true&&a[j].condition[k].owner!=undefined&&(game.me.name.indexOf(a[j].condition[k].owner)!=-1||(game.me.name2!=undefined&&game.me.name2.indexOf(a[j].condition[k].owner)!=-1))){
						lib.config.achievement[i][j].finished_times[a[j].condition[k].t_name]+=1;
					};
				};
			};
		};
		if(_status.achievement1!=undefined){
			for(var i in _status.achievement1){
				for(var j in lib.config.achievement){
					var a=lib.config.achievement[j];
					for(var k in a){
						for(var l in a[k].finished_times){
							if(l==i&&lib.config.achievement[j][k].finished_times[l]<_status.achievement1[i]) lib.config.achievement[j][k].finished_times[l]=_status.achievement1[i];
						};
					};
				};
			};
		};
		if(_status.achievement2!=undefined&&result==true){
			for(var i in _status.achievement2){
				for(var j in lib.config.achievement){
					var a=lib.config.achievement[j];
					for(var k in a){
						for(var l in a[k].finished_times){
							if(l==i&&lib.config.achievement[j][k].finished_times[l]<_status.achievement2[i]) lib.config.achievement[j][k].finished_times[l]=_status.achievement2[i];
						};
					};
				};
			};
		};
		game.saveConfig('achievement',lib.config.achievement);
	});
	lib.extensionMenu.extension_扩展ol['zgcj']={
		"name":"<b><p align=center><span style=\"font-size:18px\">-----战功查看-----</span></b>",
		"clear":true,
		"nopointer":true,
	};
	lib.extensionMenu.extension_扩展ol['zgcj_show']={
		"name":"显示可完成战功",
		"init":false,
		"intro":"开启后在武将详情页显示该武将可以完成的战功"
    };
	lib.extensionMenu.extension_扩展ol['zgcj_check']={
		name:'查看战功 <div>&gt;</div>',
		onclick:function(){
			if(game.扩展ol_menu_config==undefined) ui.click.configMenu();
			var e2;
			var dialog1={};
			var dialog2={};
			var n=0;
			for(var i in lib.config.achievement){
				n++;
			};
			var background=ui.create.dialog('hidden');
			//background.classList.add('popped');
			//background.classList.add('static');
			background.style.height='calc(100%)';
			background.style.width='calc(100%)';
			background.style.left='0px';
			background.style.top='0px';
			ui.window.appendChild(background);
			dialog1.background=background;
			var b=ui.create.dialog('hidden');
			b.style.height='calc(50%)';
			if(lib.device) b.style.height='calc(56%)';
			b.style.width=(n*110+40)+'px';
			b.style.left='calc(50% - '+((n*110+40)/2)+'px)';
			b.style.top='calc(25%)';
			b.classList.add('popped');
			b.classList.add('static');
			b.setBackgroundImage('extension/扩展ol/Background1.jpg');
			b.style.backgroundSize="cover";
			ui.window.appendChild(b);
			dialog1['b']=b;
			for(var i in lib.config.achievement){
				var a=lib.config.achievement[i];
				var b1=ui.create.dialog('hidden');
				b1.style.height='calc(50%)';
				if(lib.device) b1.style.height='calc(56%)';
				b1.style.width=(n*110+40)+'px';
				b1.style.left='calc(50% - '+((n*110+40)/2)+'px)';
				b1.style.top='calc(25%)';
				b1.classList.add('popped');
				b1.classList.add('static');
				b1.setBackgroundImage('extension/扩展ol/Background1.jpg');
				b1.style.backgroundSize="cover";
				for(var j in a){
					var item=ui.create.div('.card.fullskin');
					item.style.height='50px';
					item.style.width='50px';
					item.style.top='13px';
					item.setBackgroundImage('extension/扩展ol/'+j+'.jpg');
					item.style.backgroundSize="cover";
					if(a[j].finished!=true){
						item.classList.add('out');
						item.classList.add('dead');
					};
					item.link=i;
					item.link1=j;
					item.link2=a;
					var info=ui.create.dialog('hidden');
					info.classList.add('popped');
					info.classList.add('static');
					item.onmouseover=function(){
						var i=this.link;
						var j=this.link1;
						var a=this.link2;
						var a1=achievement[i][j];
						var str='';
						str+='<span style="font-size:18px;font-weight:600">战功：'+a1.name+'</span><br>';
						if(a[j].finished==true){
							str+='状态：已完成<br>完成时间：'+a[j].finished_data;
						}else{
							str+='状态：未完成';
						};
						str+='<br>完成条件：';
						for(var x in a1.condition){
							var c=a1.condition[x];
							if(a[j].finished==true){
								str+='<li>'+c.info+'<br>--进度：'+c.need_times+'/'+c.need_times;
							}else{
								str+='<li>'+c.info+'<br>--进度：'+a[j].finished_times[c.t_name]+'/'+c.need_times;
							};
						};
						str='<span style="font-family:xinwei">'+str+'</span>'
						if(info.content.firstChild==undefined) info.addText(str,false);
						if(info.content.firstChild!=undefined&&info.content.firstChild.firstChild!=undefined) info.content.firstChild.firstChild.innerHTML=str;
						ui.window.appendChild(info);
						info.setBackgroundImage('extension/扩展ol/Background3.jpg');
						info.style.backgroundSize="100% 100%";
						info.hide();
						info.style.left=event.clientX+10+document.body.scrollLeft+'px';
						info.style.top=event.clientY+document.body.scrollTop+'px';
						info.style.height=(info.content.firstChild.firstChild.offsetHeight+34)+'px';
						info.style.width='310px';
						info.show();
						_status.kzol_bag_onOpenInfo=true;
					};
					item.onmouseout=function(){
						info.hide();
						setTimeout(function(){
							delete _status.kzol_bag_onOpenInfo;
						},250);
					};
					b1.add(item);
				};
				dialog2[i]=b1;
			};
			var t=ui.create.dialog('hidden','<span style="color:#FFFFFF;font-size:23px;font-weight:600;font-family:xinwei">战功</span>');
			t.style.height='55px';
			t.style.width='150px';
			t.style.left='calc(50% - 75px)';
			t.style.top='calc(25% - 37px)';
			t.classList.add('popped');
			t.classList.add('static');
			t.setBackgroundImage('extension/扩展ol/Background2.jpg');
			t.style.backgroundSize="cover";
			ui.window.appendChild(t);
			dialog1['t']=t;
			var n1=-1;
			for(var i in lib.config.achievement){
				n1++;
				var a=lib.config.achievement[i];
				var d=ui.create.dialog('hidden');
				d.style.height='200px';
				d.style.width='100px';
				d.style.left='calc(50% - '+((n*110+30)/2-(20+n1*110))+'px)';
				d.style.top='calc(30%)';
				d.classList.add('popped');
				d.classList.add('static');
				d.setBackgroundImage('extension/扩展ol/'+i+'.jpg');
				ui.window.appendChild(d);
				dialog1[i]=d;
				var e1=ui.create.div(function(){
					var link_dialog=dialog2[this.link];
					for(var i in dialog1){
						dialog1[i].delete();
					};
					var background1=ui.create.dialog('hidden');
					background1.style.height='calc(100%)';
					background1.style.width='calc(100%)';
					background1.style.left='0px';
					background1.style.top='0px';
					ui.window.appendChild(background1);
					dialog2.background1=background1;
					ui.window.appendChild(dialog2[this.link]);
					var div=ui.create.div();
					div.style.height='1000px';
					div.style.width='1000px';
					div.style.left='-10px';
					div.style.top='-10px';
					var func2=function(){
						if(_status.kzol_bag_onOpenInfo!=true){
							link_dialog.delete();
							setTimeout(function(){
								background1.delete();
								for(var i in dialog1){
									ui.window.appendChild(dialog1[i]);
								};
							},250);
						};
					};
					setTimeout(function(){
						div.onclick=function(){
							func2();
						};
					},250);
					background1.add(div);
				});
				e1.style.height='200px';
				e1.style.width='100px';
				e1.style.left='-10px';
				e1.style.top='-10px';
				e1.link=i;
				d.add(e1);
				var d1=ui.create.dialog('hidden');
				d1.style.height='55px';
				d1.style.width='100px';
				d1.style.left='calc(50% - '+((n*110+30)/2-(20+n1*110))+'px)';
				d1.style.top='calc(30% + 215px)';
				d1.classList.add('popped');
				d1.classList.add('static');
				d1.setBackgroundImage('extension/扩展ol/Background.jpg');
				d1.style.backgroundSize="cover";
				var num=0;
				var num1=0;
				for(var i in a){
					num++;
					if(a[i].finished==true) num1++;
				};
				d1.add('<span style="color:#FFFFFF">'+num1+'/'+num+'<span>');
				ui.window.appendChild(d1);
				dialog1[i+'_count']=d1;
			};
			var func1=function(){
				if(game.扩展ol_menu_config!=undefined) delete game.扩展ol_menu_config;
				for(var i in dialog1){
					dialog1[i].delete();
					delete dialog1[i];
				};
				for(var i in dialog2){
					dialog2[i].delete();
					delete dialog2[i];
				};
				e.close();
				if(e2!=undefined) e2.close();
			};
			var div=ui.create.div();
			div.style.height='1000px';
			div.style.width='1000px';
			div.style.left='-10px';
			div.style.top='-10px';
			var func1=function(){
				for(var i in dialog1){
					dialog1[i].delete();
					delete dialog1[i];
				};
			};
			setTimeout(function(){
				div.onclick=function(){
					func1();
				};
			},750);
			background.add(div);
		},
		clear:true
	};
			lib.skill.xinjianxiong={
				audio:'jianxiong',
				alter:true,
				trigger:{player:'damageEnd'},
				filter:function(event,player){
					return get.itemtype(event.cards)=='cards'&&get.position(event.cards[0])=='d';
				},
				content:function(){
					player.gain(trigger.cards);
					player.$gain2(trigger.cards);
					if(player==game.me&&((player.name.indexOf('caocao')!=-1||player.name.indexOf('曹操')!=-1)||(player.name2!=undefined&&(player.name2.indexOf('caocao')!=-1||player.name2.indexOf('曹操')!=-1)))&&lib.config.achievement.wei.luanshidejianxiong.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						for(var i=0;i<trigger.cards.length;i++){
							if(trigger.cards[i].name=='nanman'){
								if(_status.achievement1.luanshidejianxiong1==undefined) _status.achievement1.luanshidejianxiong1=0;
								_status.achievement1.luanshidejianxiong1++;
							};
							if(trigger.cards[i].name=='wanjian'){
								if(_status.achievement1.luanshidejianxiong2==undefined) _status.achievement1.luanshidejianxiong2=0;
								_status.achievement1.luanshidejianxiong2++;
							};
						};
					};
					if(get.is.altered('xinjianxiong')){
						player.draw();
					};
				},
				ai:{
					maixie:true,
					maixie_hp:true,
					effect:{
						target:function(card,player,target){
							if(player.hasSkillTag('jueqing',false,target)) return [1,-1];
							if(get.tag(card,'damage')) return [1,0.55];
						}
					}
				}
			};
			lib.skill.jianxiong={
				audio:2,
				trigger:{player:'damageEnd'},
				filter:function(event,player){
					return get.itemtype(event.cards)=='cards'&&get.position(event.cards[0])=='d';
				},
				content:function(){
					player.gain(trigger.cards);
					player.$gain2(trigger.cards);
					if(player==game.me&&((player.name.indexOf('caocao')!=-1||player.name.indexOf('曹操')!=-1)||(player.name2!=undefined&&(player.name2.indexOf('caocao')!=-1||player.name2.indexOf('曹操')!=-1)))&&lib.config.achievement.wei.luanshidejianxiong.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						for(var i=0;i<trigger.cards.length;i++){
							if(trigger.cards[i].name=='nanman'){
								if(_status.achievement1.luanshidejianxiong1==undefined) _status.achievement1.luanshidejianxiong1=0;
								_status.achievement1.luanshidejianxiong1++;
							};
							if(trigger.cards[i].name=='wanjian'){
								if(_status.achievement1.luanshidejianxiong2==undefined) _status.achievement1.luanshidejianxiong2=0;
								_status.achievement1.luanshidejianxiong2++;
							};
						};
					};
				},
				ai:{
					maixie:true,
					maixie_hp:true,
					effect:{
						target:function(card,player,target){
							if(player.hasSkillTag('jueqing',false,target)) return [1,-1];
							if(get.tag(card,'damage')) return [1,0.55];
						}
					}
				}
			};
           lib.skill.new_rejianxiong={
                audio:"rejianxiong",
                trigger:{
                    player:"damageEnd",
                },
                content:function (){
					"step 0"
					if(get.itemtype(trigger.cards)=='cards'&&get.position(trigger.cards[0])=='d'){
						player.gain(trigger.cards,"gain2");
						if(player==game.me&&((player.name.indexOf('caocao')!=-1||player.name.indexOf('曹操')!=-1)||(player.name2!=undefined&&(player.name2.indexOf('caocao')!=-1||player.name2.indexOf('曹操')!=-1)))&&lib.config.achievement.wei.luanshidejianxiong.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							for(var i=0;i<trigger.cards.length;i++){
								if(trigger.cards[i].name=='nanman'){
									if(_status.achievement1.luanshidejianxiong1==undefined) _status.achievement1.luanshidejianxiong1=0;
									_status.achievement1.luanshidejianxiong1++;
								};
								if(trigger.cards[i].name=='wanjian'){
									if(_status.achievement1.luanshidejianxiong2==undefined) _status.achievement1.luanshidejianxiong2=0;
									_status.achievement1.luanshidejianxiong2++;
								};
							};
						};
					}
					player.draw('nodelay');
				},
                ai:{
                    maixie:true,
                    "maixie_hp":true,
                    effect:{
                        target:function (card,player,target){
							if(player.hasSkillTag('jueqing',false,target)) return [1,-1];
							if(get.tag(card,'damage')&&player!=target) return [1,0.6];
						},
                    },
                },
            };
			lib.skill.tuxi={
				audio:2,
				trigger:{player:'phaseDrawBefore'},
				direct:true,
				content:function(){
					"step 0"
					var check;
					var i,num=game.countPlayer(function(current){
						return current!=player&&current.countCards('h')&&get.attitude(player,current)<=0;
					});
					check=(num>=2);
					player.chooseTarget(get.prompt('tuxi'),[1,2],function(card,player,target){
						return target.countCards('h')>0&&player!=target;
					},function(target){
						if(!_status.event.aicheck) return 0;
						var att=get.attitude(_status.event.player,target);
						if(target.hasSkill('tuntian')) return att/10;
						return 1-att;
					}).set('aicheck',check);
					"step 1"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('zhangliao')!=-1||
						player.name.indexOf('张辽')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('zhangliao')!=-1||
						player.name2.indexOf('张辽')!=-1)))&&
						lib.config.achievement.wei.shenqiwubei.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.shenqiwubei==undefined) _status.achievement1.shenqiwubei=0;
							_status.achievement1.shenqiwubei++;
						};
						player.logSkill('tuxi',result.targets);
						player.gainMultiple(result.targets);
						trigger.cancel();
					}
					else{
						event.finish();
					}
					"step 2"
					game.delay();
				},
				ai:{
					threaten:2,
					expose:0.3
				}
			};
            lib.skill.new_retuxi={
                audio:"retuxi",
                trigger:{
                    player:"phaseDrawBegin",
                },
                direct:true,
                priority:-10,
                filter:function (event){
					return event.num>0;
				},
                content:function (){
					"step 0"
					player.chooseTarget(get.prompt('new_retuxi'),[1,trigger.num],function(card,player,target){
						return target.countCards('h')>0&&player!=target;
					},function(target){
						var att=get.attitude(_status.event.player,target);
						if(target.hasSkill('tuntian')) return att/10;
						return 1-att;
					});
					"step 1"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('zhangliao')!=-1||
						player.name.indexOf('张辽')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('zhangliao')!=-1||
						player.name2.indexOf('张辽')!=-1)))&&
						lib.config.achievement.wei.shenqiwubei.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.shenqiwubei==undefined) _status.achievement1.shenqiwubei=0;
							_status.achievement1.shenqiwubei++;
						};
						player.logSkill('new_retuxi',result.targets);
						player.gainMultiple(result.targets);
						trigger.num-=result.targets.length;
					}
					else{
						event.finish();
					}
					"step 2"
					if(trigger.num<=0) game.delay();
				},
                ai:{
                    threaten:1.6,
                    expose:0.2,
                },
            };
		lib.skill._achieve_gl={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_gl==true;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('xiahoudun')!=-1||
				player.name.indexOf('夏侯惇')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('xiahoudun')!=-1||
				player.name2.indexOf('夏侯惇')!=-1)))&&
				lib.config.achievement.wei.liangbaijushang.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.liangbaijushang==undefined) _status.achievement1.liangbaijushang=0;
					_status.achievement1.liangbaijushang++;
				};
			},
		 };
			lib.skill.ganglie={
				audio:2,
				trigger:{player:'damageEnd'},
				filter:function(event,player){
					return (event.source!=undefined);
				},
				check:function(event,player){
					return (get.attitude(player,event.source)<=0);
				},
				logTarget:'source',
				content:function(){
					"step 0"
					player.judge(function(card){
						if(get.suit(card)=='heart') return -2;
						return 2;
					})
					"step 1"
					if(result.judge<2){
						event.finish();return;
					}
					trigger.source.chooseToDiscard(2).set('ai',function(card){
						if(card.name=='tao') return -10;
						if(card.name=='jiu'&&_status.event.player.hp==1) return -10;
						return get.unuseful(card)+2.5*(5-get.owner(card).hp);
					});
					"step 2"
					if(result.bool==false){
						trigger.source.damage();
						player.storage.achieve_gl=true;
					}else{
						event.finish();
					};
					"step 3"
					delete player.storage.achieve_gl;
				},
				ai:{
					maixie_defend:true,
					effect:{
						target:function(card,player,target){
							if(player.hasSkillTag('jueqing',false,target)) return [1,-1];
							return 0.8;
							// if(get.tag(card,'damage')&&get.damageEffect(target,player,player)>0) return [1,0,0,-1.5];
						}
					}
				}
			};
			lib.skill.reganglie={
				audio:2,
				trigger:{player:'damageEnd'},
				filter:function(event,player){
					return (event.source!=undefined&&event.num>0);
				},
				check:function(event,player){
					return (get.attitude(player,event.source)<=0);
				},
				logTarget:'source',
				content:function(){
					"step 0"
					event.num=trigger.num;
					"step 1"
					player.judge(function(card){
						if(get.color(card)=='red') return 1;
						return 0;
					});
					"step 2"
					if(result.color=='black'){
						if(trigger.source.countCards('he')){
							player.discardPlayerCard(trigger.source,'he',true);
						}
					}
					else if(trigger.source.isIn()){
						trigger.source.damage();
						player.storage.achieve_gl=true;
					}
					"step 3"
					delete player.storage.achieve_gl;
					event.num--;
					if(event.num>0){
						player.chooseBool(get.prompt2('reganglie'));
					}else{
						event.finish();
					}
					"step 4"
					if(result.bool){
						player.logSkill('reganglie',trigger.source);
						event.goto(1);
					}
				},
				ai:{
					maixie_defend:true,
					expose:0.4
				}
			};
			lib.skill.luoyi={
				audio:2,
				trigger:{player:'phaseDrawBegin'},
				check:function(event,player){
					if(player.countCards('h')<3) return false;
					if(!player.hasSha()) return false;
					return game.hasPlayer(function(current){
						return get.attitude(player,current)<0&&player.canUse('sha',current);
					});
				},
				content:function(){
					player.addTempSkill('luoyi2','phaseEnd');
					trigger.num--;
					if(player==game.me&&((player.name.indexOf('xuzhu')!=-1||
					player.name.indexOf('许褚')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('xuzhu')!=-1||
					player.name2.indexOf('许褚')!=-1)))&&
					lib.config.achievement.wei.mawoleng.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.mawoleng1==undefined) _status.achievement1.mawoleng1=0;
						_status.achievement1.mawoleng1++;
					};
				}
			};
            lib.skill.new_reluoyi={
                audio:"reluoyi",
                trigger:{
                    player:"phaseDrawBegin",
                },
                content:function (){
					"step 0"
					if(player==game.me&&((player.name.indexOf('xuzhu')!=-1||
					player.name.indexOf('许褚')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('xuzhu')!=-1||
					player.name2.indexOf('许褚')!=-1)))&&
					lib.config.achievement.wei.mawoleng.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.mawoleng1==undefined) _status.achievement1.mawoleng1=0;
						_status.achievement1.mawoleng1++;
					};
					event.cards=get.cards(3);
					player.showCards(event.cards,'裸衣');
					player.chooseBool("是否放弃摸牌？").ai=function(event,player){
						var num=3
						for(var i=0;i<event.cards.length;i++){
							if(get.type(event.cards[i])!='basic'&&event.cards[i].name!='juedou'&&
								(get.type(event.cards[i])!='equip'||get.subtype(event.cards[i])!='equip1')){
								num--;
							}
						}
						return num>1
					};
					"step 1"
					if(result.bool){
					for(var i=0;i<cards.length;i++){
						if(get.type(cards[i])!='basic'&&cards[i].name!='juedou'&&
							(get.type(cards[i])!='equip'||get.subtype(cards[i])!='equip1')){
							cards[i].discard();
							cards.splice(i--,1);
						}
					}
					player.gain(cards,'gain2');
					player.addTempSkill('reluoyi2',{player:'phaseBefore'});
					trigger.cancel();
					}
					else for(var i=0;i<cards.length;i++){
							cards[i].discard();
					}
				},
            };
		lib.skill._achieve_ly1={
			trigger:{
				player:"useCardBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return event.card!=undefined&&(event.card.name=='sha'||event.card.name=='juedou')&&(player.hasSkill('luoyi2')||player.hasSkill('reluoyi2'));
			},
			content:function (){
				player.storage.achieve_ly1=true;
			},
		 };
		lib.skill._achieve_ly2={
			trigger:{
				player:"useCardAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_ly1==true;
			},
			content:function (){
				delete player.storage.achieve_ly1;
			},
		 };
		lib.skill._achieve_ly3={
			trigger:{
				player:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return event.source!=undefined&&(event.source.hasSkill('luoyi2')||event.source.hasSkill('reluoyi2'))&&event.source.storage.achieve_ly1==true;
			},
			content:function (){
				var pl=trigger.source;
				if(pl==game.me&&((pl.name.indexOf('xuzhu')!=-1||
				pl.name.indexOf('许褚')!=-1)||
				(pl.name2!=undefined&&(pl.name2.indexOf('xuzhu')!=-1||
				pl.name2.indexOf('许褚')!=-1)))&&
				lib.config.achievement.wei.mawoleng.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.mawoleng2==undefined) _status.achievement1.mawoleng2=0;
					_status.achievement1.mawoleng2++;
				};
			},
		 };
			lib.skill.yiji={
				audio:2,
				trigger:{player:'damageEnd'},
				frequent:true,
				filter:function(event){
					return (event.num>0)
				},
				content:function(){
					"step 0"
					event.cards=get.cards(2*trigger.num);
					"step 1"
					if(event.cards.length>1){
						player.chooseCardButton('将“遗计”牌分配给任意角色',true,event.cards,[1,event.cards.length]).set('ai',function(button){
							if(ui.selected.buttons.length==0) return 1;
							return 0;
						});
					}
					else if(event.cards.length==1){
						event._result={links:event.cards.slice(0),bool:true};
					}
					else{
						event.finish();
					}
					"step 2"
					if(result.bool){
						for(var i=0;i<result.links.length;i++){
							event.cards.remove(result.links[i]);
						}
						event.togive=result.links.slice(0);
						player.chooseTarget('将'+get.translation(result.links)+'交给一名角色',true).set('ai',function(target){
							var att=get.attitude(_status.event.player,target);
							if(_status.event.enemy){
								return -att;
							}
							else if(att>0){
								return att/(1+target.countCards('h'));
							}
							else{
								return att/100;
							}
						}).set('enemy',get.value(event.togive[0])<0);
					}
					"step 3"
					if(result.targets.length){
						if(player==game.me&&((player.name.indexOf('guojia')!=-1||
						player.name.indexOf('郭嘉')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('guojia')!=-1||
						player.name2.indexOf('郭嘉')!=-1)))&&
						lib.config.achievement.wei.buyiyuli.finished!=true&&
						result.targets[0]!=player){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.buyiyuli==undefined) _status.achievement1.buyiyuli=0;
							_status.achievement1.buyiyuli++;
						};
						result.targets[0].gain(event.togive,'draw');
						player.line(result.targets[0],'green');
						game.log(result.targets[0],'获得了'+get.cnNumber(event.togive.length)+'张牌');
						event.goto(1);
					}
				},
				ai:{
					maixie:true,
					maixie_hp:true,
					effect:{
						target:function(card,player,target){
							if(get.tag(card,'damage')){
								if(player.hasSkillTag('jueqing',false,target)) return [1,-2];
								if(!target.hasFriend()) return;
								var num=1;
								if(get.attitude(player,target)>0){
									if(player.needsToDiscard()){
										num=0.7;
									}
									else{
										num=0.5;
									}
								}
								if(target.hp>=4) return [1,num*2];
								if(target.hp==3) return [1,num*1.5];
								if(target.hp==2) return [1,num*0.5];
							}
						}
					}
				}
			};
           lib.skill.new_reyiji={
                audio:"reyiji",
                trigger:{
                    player:"damageEnd",
                },
                frequent:true,
                filter:function (event){
					return (event.num>0)
				},
                content:function (){
					"step 0"
					event.count=1;
					"step 1"
					player.draw(2);
					event.given=0;
					"step 2"
					player.chooseCardTarget({
						filterCard:true,
						selectCard:[1,2-event.given],
						filterTarget:function(card,player,target){
							return player!=target&&target!=event.temp;
						},
						ai1:function(card){
							if(ui.selected.cards.length>0) return -1;
							if(card.name=='du') return 20;
							return (_status.event.player.countCards('h')-_status.event.player.hp);
						},
						ai2:function(target){
							var att=get.attitude(_status.event.player,target);
							if(ui.selected.cards.length&&ui.selected.cards[0].name=='du'){
								if(target.hasSkillTag('nodu')) return 0;
								return 1-att;
							}
							return att-4;
						},
						prompt:'请选择要送人的卡牌'
					});
					"step 3"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('guojia')!=-1||
						player.name.indexOf('郭嘉')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('guojia')!=-1||
						player.name2.indexOf('郭嘉')!=-1)))&&
						lib.config.achievement.wei.buyiyuli.finished!=true&&
						result.targets[0]!=player){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.buyiyuli==undefined) _status.achievement1.buyiyuli=0;
							_status.achievement1.buyiyuli++;
						};
						player.$giveAuto(result.cards,result.targets[0]);
						player.line(result.targets,'green');
						result.targets[0].gain(result.cards);
						event.given+=result.cards.length;
						if(event.given<2){
							event.temp=result.targets[0];
							event.goto(2);
						}
						else if(event.count<trigger.num){
							delete event.temp;
							event.count++;
							event.goto(1);
						}
					}
					else if(event.count<trigger.num){
						delete event.temp;
						event.num=1;
						event.count++;
						event.goto(1);
					}
				},
                ai:{
                    maixie:true,
                    "maixie_hp":true,
                    result:{
                        effect:function (card,player,target){
							if(get.tag(card,'damage')){
								if(player.hasSkillTag('jueqing',false,target)) return [1,-2];
								if(!target.hasFriend()) return;
								var num=1;
								if(get.attitude(player,target)>0){
									if(player.needsToDiscard()){
										num=0.7;
									}
									else{
										num=0.5;
									}
								}
								if(player.hp>=4) return [1,num*2];
								if(target.hp==3) return [1,num*1.5];
								if(target.hp==2) return [1,num*0.5];
							}
						},
                    },
                    threaten:0.6,
                },
            };
			 lib.skill.fankui={
				audio:2,
				trigger:{player:'damageEnd'},
				direct:true,
				filter:function(event,player){
					return (event.source&&event.source.countGainableCards(player,'he')&&event.num>0&&event.source!=player);
				},
				content:function(){
					'step 0'
					player.gainPlayerCard(get.prompt('fankui',trigger.source),trigger.source,get.buttonValue,'he').set('logSkill',['fankui',trigger.source]);
					'step 1'
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('simayi')!=-1||
						player.name.indexOf('司马懿')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('simayi')!=-1||
						player.name2.indexOf('司马懿')!=-1)))&&
						lib.config.achievement.wei.shouyantongtian.finished!=true&&
						result.cards[0].name=='tao'){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.shouyantongtian==undefined) _status.achievement1.shouyantongtian=0;
							_status.achievement1.shouyantongtian++;
						};
					};
				},
				ai:{
					maixie_defend:true,
					effect:{
						target:function(card,player,target){
							if(player.countCards('he')>1&&get.tag(card,'damage')){
								if(player.hasSkillTag('jueqing',false,target)) return [1,-1.5];
								if(get.attitude(target,player)<0) return [1,1];
							}
						}
					}
				}
			};
			 lib.skill.refankui={
				audio:2,
				trigger:{player:'damageEnd'},
				direct:true,
				filter:function(event,player){
					return (event.source&&event.source.countGainableCards(player,'he')&&event.num>0&&event.source!=player);
				},
				content:function(){
					'step 0'
					player.gainPlayerCard(get.prompt('fankui',trigger.source),trigger.source,get.buttonValue,'he').set('logSkill',['refankui',trigger.source]);
					'step 1'
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('simayi')!=-1||
						player.name.indexOf('司马懿')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('simayi')!=-1||
						player.name2.indexOf('司马懿')!=-1)))&&
						lib.config.achievement.wei.shouyantongtian.finished!=true&&
						result.cards[0].name=='tao'){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.shouyantongtian==undefined) _status.achievement1.shouyantongtian=0;
							_status.achievement1.shouyantongtian++;
						};
					};
				},
				ai:{
					maixie_defend:true,
					effect:{
						target:function(card,player,target){
							if(player.countCards('he')>1&&get.tag(card,'damage')){
								if(player.hasSkillTag('jueqing',false,target)) return [1,-1.5];
								if(get.attitude(target,player)<0) return [1,1];
							}
						}
					}
				}
			};
			 lib.skill.luoshen={
				audio:2,
				trigger:{player:'phaseBegin'},
				frequent:true,
				content:function(){
					"step 0"
					if(event.cards==undefined) event.cards=[];
					player.judge(function(card){
						if(get.color(card)=='black') return 1.5;
						return -1.5;
					},ui.special);
					"step 1"
					if(result.judge>0){
						event.cards.push(result.card);
						if(lib.config.autoskilllist.contains('luoshen')){
							player.chooseBool('是否再次发动【洛神】？');
						}
						else{
							event._result={bool:true};
						}
					}
					else{
						for(var i=0;i<event.cards.length;i++){
							if(get.position(event.cards[i])!='s'){
								event.cards.splice(i,1);i--;
							}
						}
						if(event.cards.length){
							if(player==game.me&&((player.name.indexOf('zhenji')!=-1||
							player.name.indexOf('甄姬')!=-1)||
							(player.name2!=undefined&&(player.name2.indexOf('zhenji')!=-1||
							player.name2.indexOf('甄姬')!=-1)))&&
							lib.config.achievement.wei.luoshenfu.finished!=true&&
							event.cards.length>0){
								if(_status.achievement1==undefined) _status.achievement1={};
								if(_status.achievement1.luoshenfu==undefined) _status.achievement1.luoshenfu=0;
								if(_status.achievement1.luoshenfu<event.cards.length&&lib.config.achievement.wei.luoshenfu.finished_times.luoshenfu<event.cards.length) _status.achievement1.luoshenfu=event.cards.length;
							};
							player.gain(event.cards);
							player.$draw(event.cards);
						}
						event.finish();
					}
					"step 2"
					if(result.bool){
						event.goto(0);
					}else{
						if(event.cards.length){
							if(player==game.me&&((player.name.indexOf('zhenji')!=-1||
							player.name.indexOf('甄姬')!=-1)||
							(player.name2!=undefined&&(player.name2.indexOf('zhenji')!=-1||
							player.name2.indexOf('甄姬')!=-1)))&&
							lib.config.achievement.wei.luoshenfu.finished!=true&&
							event.cards.length>0){
								if(_status.achievement1==undefined) _status.achievement1={};
								if(_status.achievement1.luoshenfu==undefined) _status.achievement1.luoshenfu=0;
								if(_status.achievement1.luoshenfu<event.cards.length&&lib.config.achievement.wei.luoshenfu.finished_times.luoshenfu<event.cards.length) _status.achievement1.luoshenfu=event.cards.length;
							};
							player.gain(event.cards);
							player.$draw(event.cards);
						}
					}
				}
			};
			 lib.skill.reluoshen={
				audio:'luoshen',
				trigger:{player:'phaseBegin'},
				frequent:true,
				content:function(){
					"step 0"
					if(event.cards==undefined) event.cards=[];
					player.judge(function(card){
						if(get.color(card)=='black') return 1.5;
						return -1.5;
					},ui.special);
					"step 1"
					if(result.judge>0){
						event.cards.push(result.card);
						if(lib.config.autoskilllist.contains('luoshen')){
							player.chooseBool('是否再次发动【洛神】？');
						}
						else{
							event._result={bool:true};
						}
					}
					else{
						for(var i=0;i<event.cards.length;i++){
							if(get.position(event.cards[i])!='s'){
								event.cards.splice(i,1);i--;
							}
						}
						if(player==game.me&&((player.name.indexOf('zhenji')!=-1||
						player.name.indexOf('甄姬')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('zhenji')!=-1||
						player.name2.indexOf('甄姬')!=-1)))&&
						lib.config.achievement.wei.luoshenfu.finished!=true&&
						event.cards.length>0){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.luoshenfu==undefined) _status.achievement1.luoshenfu=0;
							if(_status.achievement1.luoshenfu<event.cards.length&&lib.config.achievement.wei.luoshenfu.finished_times.luoshenfu<event.cards.length) _status.achievement1.luoshenfu=event.cards.length;
						};
						player.gain(event.cards,'gain2');
						player.storage.reluoshen=event.cards.slice(0);
						event.finish();
					}
					"step 2"
					if(result.bool){
						event.goto(0);
					}
					else{
						if(event.cards.length){
							if(player==game.me&&((player.name.indexOf('zhenji')!=-1||
							player.name.indexOf('甄姬')!=-1)||
							(player.name2!=undefined&&(player.name2.indexOf('zhenji')!=-1||
							player.name2.indexOf('甄姬')!=-1)))&&
							lib.config.achievement.wei.luoshenfu.finished!=true&&
							event.cards.length>0){
								if(_status.achievement1==undefined) _status.achievement1={};
								if(_status.achievement1.luoshenfu==undefined) _status.achievement1.luoshenfu=0;
								if(_status.achievement1.luoshenfu<event.cards.length&&lib.config.achievement.wei.luoshenfu.finished_times.luoshenfu<event.cards.length) _status.achievement1.luoshenfu=event.cards.length;
							};
							player.gain(event.cards,'gain2');
							player.storage.reluoshen=event.cards.slice(0);
						}
					}
				},
				mod:{
					ignoredHandcard:function(card,player){
						if(player.storage.reluoshen&&player.storage.reluoshen.contains(card)){
							return true;
						}
					},
					cardDiscardable:function(card,player,name){
						if(name=='phaseDiscard'&&player.storage.reluoshen&&player.storage.reluoshen.contains(card)){
							return true;
						}
					},
				},
				group:'reluoshen_clear',
				subSkill:{
					clear:{
						trigger:{player:'phaseAfter'},
						silent:true,
						content:function(){
							delete player.storage.reluoshen;
						}
					}
				}
			};
			lib.skill._achieve_jy={
				trigger:{
					target:'taoBegin'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					if(player.hp>0) return false;
					if(event.player.group!='wu') return false;
					var bool=false;
					if(player==game.me&&((player.name.indexOf('sunquan')!=-1||
					player.name.indexOf('孙权')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('sunquan')!=-1||
					player.name2.indexOf('孙权')!=-1)))&&
					lib.config.achievement.wu.nianqingyouwei.finished!=true) bool=true;
					return bool;
				},
				content:function(){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.nianqingyouwei==undefined) _status.achievement1.nianqingyouwei=0;
					_status.achievement1.nianqingyouwei++;
				}
			};
			lib.skill._achieve_qx={
				trigger:{
					player:'phaseAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					return player.storage.ext_shenchuguimo!=undefined;
				},
				content:function(){
					delete player.storage.ext_shenchuguimo;
				}
			};
			lib.skill.qixi={
				audio:2,
				audioname:['ganning','re_ganning'],
				enable:'chooseToUse',
				filterCard:function(card){
					return get.color(card)=='black';
				},
				position:'he',
				viewAs:{name:'guohe'},
				viewAsFilter:function(player){
					if(!player.countCards('he',{color:'black'})) return false;
				},
				prompt:'将一张黑色牌当过河拆桥使用',
				check:function(card){return 4-get.value(card)},
				onuse:function(result,player){
					if(player==game.me&&((player.name.indexOf('ganning')!=-1||
					player.name.indexOf('甘宁')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('ganning')!=-1||
					player.name2.indexOf('甘宁')!=-1)))&&
					lib.config.achievement.wu.shenchuguimo.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.shenchuguimo==undefined) _status.achievement1.shenchuguimo=0;
						if(player.storage.ext_shenchuguimo==undefined) player.storage.ext_shenchuguimo=0;
						player.storage.ext_shenchuguimo++;
						if(_status.achievement1.shenchuguimo<player.storage.ext_shenchuguimo) _status.achievement1.shenchuguimo=player.storage.ext_shenchuguimo;
					};
				},
			};
			lib.skill._achieve_kr={
				trigger:{
					player:'phaseAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					return player.storage.ext_wujindebianta!=undefined;
				},
				content:function(){
					delete player.storage.ext_wujindebianta;
				}
			};
			lib.skill.kurou={
				audio:4,
				enable:'phaseUse',
				prompt:'失去一点体力并摸两张牌',
				content:function(){
					"step 0"
					if(player==game.me&&((player.name.indexOf('huanggai')!=-1||
					player.name.indexOf('黄盖')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huanggai')!=-1||
					player.name2.indexOf('黄盖')!=-1)))&&
					lib.config.achievement.wu.wujindebianta.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.wujindebianta==undefined) _status.achievement1.wujindebianta=0;
						if(player.storage.ext_wujindebianta==undefined) player.storage.ext_wujindebianta=0;
						player.storage.ext_wujindebianta++;
						if(_status.achievement1.wujindebianta<player.storage.ext_wujindebianta) _status.achievement1.wujindebianta=player.storage.ext_wujindebianta;
					};
					player.loseHp(1);
					"step 1"
					player.draw(2);
				},
				ai:{
					basic:{
						order:1
					},
					result:{
						player:function(player){
							if(player.countCards('h')>=player.hp-1) return -1;
							if(player.hp<3) return -1;
							return 1;
						}
					}
				}
			};
			lib.skill.rekurou={
				audio:2,
				enable:'phaseUse',
				usable:1,
				filterCard:true,
				check:function(card){
					return 8-get.value(card);
				},
				position:'he',
				content:function(){
					if(player==game.me&&((player.name.indexOf('huanggai')!=-1||
					player.name.indexOf('黄盖')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huanggai')!=-1||
					player.name2.indexOf('黄盖')!=-1)))&&
					lib.config.achievement.wu.wujindebianta.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.wujindebianta==undefined) _status.achievement1.wujindebianta=0;
						if(player.storage.ext_wujindebianta==undefined) player.storage.ext_wujindebianta=0;
						player.storage.ext_wujindebianta++;
						if(_status.achievement1.wujindebianta<player.storage.ext_wujindebianta) _status.achievement1.wujindebianta=player.storage.ext_wujindebianta;
					};
					player.loseHp();
				},
				ai:{
					order:8,
					result:{
						player:function(player){
							if(player.hp<=2) return player.countCards('h')==0?1:0;
							if(player.countCards('h',{name:'sha',color:'red'})) return 1;
							return player.countCards('h')<=player.hp?1:0;
						}
					},
					effect:function(card,player,target){
						if(get.tag(card,'damage')){
							if(player.hasSkillTag('jueqing',false,target)) return [1,1];
							return 1.2;
						}
						if(get.tag(card,'loseHp')){
							if(player.hp<=1) return;
							return [0,0];
						}
					}
				}
			};
			lib.skill._achieve_kz={
				trigger:{
					player:'gainAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					var bool=false;
					if(player==game.me&&((player.name.indexOf('lvmeng')!=-1||
					player.name.indexOf('吕蒙')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('lvmeng')!=-1||
					player.name2.indexOf('吕蒙')!=-1)))&&
					lib.config.achievement.wu.sijidaifa.finished!=true) bool=true;
					return bool;
				},
				content:function(){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.sijidaifa==undefined) _status.achievement1.sijidaifa=0;
					if(_status.achievement1.sijidaifa<player.countCards('h')) _status.achievement1.sijidaifa=player.countCards('h');
				}
			};
			lib.skill.liuli={
				audio:2,
				audioname:['re_daqiao','daxiaoqiao'],
				trigger:{target:'shaBefore'},
				direct:true,
				priority:5,
				filter:function(event,player){
					if(player.countCards('he')==0) return false;
					return game.hasPlayer(function(current){
						return get.distance(player,current,'attack')<=1&&current!=event.player&&
							current!=player&&lib.filter.targetEnabled(event.card,event.player,current);
					});
				},
				content:function(){
					"step 0"
					var next=player.chooseCardTarget({
						position:'he',
						filterCard:lib.filter.cardDiscardable,
						filterTarget:function(card,player,target){
							var trigger=_status.event.getTrigger();
							if(get.distance(player,target,'attack')<=1&&
								target!=trigger.player&&!trigger.targets.contains(target)){
								if(player.canUse(trigger.card,target)) return true;
							}
							return false;
						},
						ai1:function(card){
							return get.unuseful(card)+9;
						},
						ai2:function(target){
							if(_status.event.player.countCards('h','shan')){
								return -get.attitude(_status.event.player,target);
							}
							if(get.attitude(_status.event.player,target)<5){
								return 6-get.attitude(_status.event.player,target);
							}
							if(_status.event.player.hp==1&&player.countCards('h','shan')==0){
								return 10-get.attitude(_status.event.player,target);
							}
							if(_status.event.player.hp==2&&player.countCards('h','shan')==0){
								return 8-get.attitude(_status.event.player,target);
							}
							return -1;
						},
						prompt:get.prompt2('liuli')
					});
					"step 1"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('daqiao')!=-1||
						player.name.indexOf('大乔')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('daqiao')!=-1||
						player.name2.indexOf('大乔')!=-1)))&&
						lib.config.achievement.wu.yihuajiemu.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.yihuajiemu==undefined) _status.achievement1.yihuajiemu=0;
							if(player.storage.ext_yihuajiemu==undefined) player.storage.ext_yihuajiemu=0;
							player.storage.ext_yihuajiemu++;
							if(_status.achievement1.yihuajiemu<player.storage.ext_yihuajiemu) _status.achievement1.yihuajiemu=player.storage.ext_yihuajiemu;
						};
						player.discard(result.cards);
						player.logSkill(event.name,result.targets);
						trigger.target=result.targets[0];
						for(var i=0;i<trigger.targets.length;i++){
						    if(trigger.targets[i]==player) break;
						}
						var t1=trigger.targets.slice(0,i);
						var t2=trigger.targets.slice(i+1);
						trigger.targets=t1.concat([result.targets[0]]).concat(t2);
					}
					else{
						player.storage.ext_yihuajiemu=0;
						event.finish();
					}
					"step 2"
					trigger.untrigger();
					trigger.trigger('useCardToBefore');
					trigger.trigger('shaBefore');
					game.delay();
				},
				ai:{
					effect:{
						target:function(card,player,target){
							if(target.countCards('he')==0) return;
							if(card.name!='sha') return;
							var min=1;
							var friend=get.attitude(player,target)>0;
							var vcard={name:'shacopy',nature:card.nature,suit:card.suit};
							var players=game.filterPlayer();
							for(var i=0;i<players.length;i++){
								if(player!=players[i]&&
									get.attitude(target,players[i])<0&&
									target.canUse(card,players[i])){
									if(!friend) return 0;
									if(get.effect(players[i],vcard,player,player)>0){
										if(!player.canUse(card,players[0])){
											return [0,0.1];
										}
										min=0;
									}
								}
							}
							return min;
						}
					}
				}
			};
			lib.skill._achieve_xj={
				trigger:{
					player:'loseEnd'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					var bool=false;
					var bool1=false;
					for(var i=0;i<event.cards.length;i++){
						if(event.cards[i].original=='e') bool=true;
					};
					if(player==game.me&&((player.name.indexOf('sunshangxiang')!=-1||
					player.name.indexOf('孙尚香')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('sunshangxiang')!=-1||
					player.name2.indexOf('孙尚香')!=-1)))&&
					lib.config.achievement.wu.yinhuodefu.finished!=true) bool1=true;
					return bool&&bool1;
				},
				content:function(){
					var num=0;
					for(var i=0;i<trigger.cards.length;i++){
						if(trigger.cards[i].original=='e') num++;
					};
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.yinhuodefu==undefined) _status.achievement1.yinhuodefu=0;
					_status.achievement1.yinhuodefu+=num;
				},
			};
		lib.skill._achieve_fj={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_fj==true;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('zhouyu')!=-1||
				player.name.indexOf('周瑜')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('zhouyu')!=-1||
				player.name2.indexOf('周瑜')!=-1)))&&
				lib.config.achievement.wu.wujindezhengzha.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.wujindezhengzha==undefined) _status.achievement1.wujindezhengzha=0;
					_status.achievement1.wujindezhengzha++;
				};
			},
		 };
			lib.skill.fanjian={
				audio:2,
				enable:'phaseUse',
				usable:1,
				filter:function(event,player){
					return player.countCards('h')>0;
				},
				filterTarget:function(card,player,target){
					return player!=target;
				},
				content:function(){
					"step 0"
					target.chooseControl('heart2','diamond2','club2','spade2').set('ai',function(event){
						switch(Math.floor(Math.random()*6)){
							case 0:return 'heart2';
							case 1:case 4:case 5:return 'diamond2';
							case 2:return 'club2';
							case 3:return 'spade2';
						}
					});
					"step 1"
					game.log(target,'选择了'+get.translation(result.control));
					event.choice=result.control;
					target.popup(event.choice);
					event.card=player.getCards('h').randomGet();
					target.gain(event.card,player);
					player.$give(event.card,target);
					game.delay();
					"step 2"
					if(get.suit(event.card)+'2'!=event.choice){
						target.damage('nocard');
						player.storage.achieve_fj=true;
					};
					"step 3"
					delete player.storage.achieve_fj;
				},
				ai:{
					order:1,
					result:{
						target:function(player,target){
							var eff=get.damageEffect(target,player);
							if(eff>=0) return 1+eff;
							var value=0,i;
							var cards=player.getCards('h');
							for(i=0;i<cards.length;i++){
								value+=get.value(cards[i]);
							}
							value/=player.countCards('h');
							if(target.hp==1) return Math.min(0,value-7);
							return Math.min(0,value-5);
						}
					}
				}
			};
			lib.skill._achieve_lying={
				trigger:{
					player:'phaseAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					return player.storage.ext_lianmianbujue!=undefined;
				},
				content:function(){
					delete player.storage.ext_lianmianbujue;
				}
			};
			lib.skill.lianying={
				audio:2,
				trigger:{player:'loseEnd'},
				frequent:true,
				filter:function(event,player){
					if(player.countCards('h')) return false;
					for(var i=0;i<event.cards.length;i++){
						if(event.cards[i].original=='h') return true;
					}
					return false;
				},
				content:function(){
					if(player==game.me&&((player.name.indexOf('luxun')!=-1||
					player.name.indexOf('陆逊')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('luxun')!=-1||
					player.name2.indexOf('陆逊')!=-1)))&&
					lib.config.achievement.wu.lianmianbujue.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.lianmianbujue==undefined) _status.achievement1.lianmianbujue=0;
						if(player.storage.ext_lianmianbujue==undefined) player.storage.ext_lianmianbujue=0;
						player.storage.ext_lianmianbujue++;
						if(_status.achievement1.lianmianbujue<player.storage.ext_lianmianbujue) _status.achievement1.lianmianbujue=player.storage.ext_lianmianbujue;
					};
					player.draw();
				},
				ai:{
					threaten:0.8,
					effect:{
						target:function(card){
							if(card.name=='guohe'||card.name=='liuxinghuoyu') return 0.5;
						}
					},
					noh:true,
					skillTagFilter:function(player,tag){
						if(tag=='noh'){
							if(player.countCards('h')!=1) return false;
						}
					}
				}
			};
			lib.skill.relianying={
				audio:2,
				trigger:{player:'loseEnd'},
				direct:true,
				filter:function(event,player){
					if(player.countCards('h')) return false;
					for(var i=0;i<event.cards.length;i++){
						if(event.cards[i].original=='h') return true;
					}
					return false;
				},
				content:function(){
					"step 0"
					var num=0;
					for(var i=0;i<trigger.cards.length;i++){
						if(trigger.cards[i].original=='h') num++;
					}
					player.chooseTarget('选择发动连营的目标',[1,num]).ai=function(target){
						var player=_status.event.player;
						if(player==target) return get.attitude(player,target)+10;
						return get.attitude(player,target);
					}
					"step 1"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('luxun')!=-1||
						player.name.indexOf('陆逊')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('luxun')!=-1||
						player.name2.indexOf('陆逊')!=-1)))&&
						lib.config.achievement.wu.lianmianbujue.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.lianmianbujue==undefined) _status.achievement1.lianmianbujue=0;
							if(player.storage.ext_lianmianbujue==undefined) player.storage.ext_lianmianbujue=0;
							player.storage.ext_lianmianbujue++;
							if(_status.achievement1.lianmianbujue<player.storage.ext_lianmianbujue) _status.achievement1.lianmianbujue=player.storage.ext_lianmianbujue;
						};
						player.logSkill('relianying',result.targets);
						game.asyncDraw(result.targets);
					}
				},
				ai:{
					threaten:0.8,
					effect:{
						target:function(card){
							if(card.name=='guohe'||card.name=='liuxinghuoyu') return 0.5;
						}
					},
					noh:true,
				}
			};
		lib.skill._achieve_cxsgj={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_cxsgj==true;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('liubei')!=-1||
				player.name.indexOf('刘备')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('liubei')!=-1||
				player.name2.indexOf('刘备')!=-1)))&&
				lib.config.achievement.shu.jiujiezhixin.finished!=true&&
				trigger.player.sex=='female'){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.jiujiezhixin==undefined) _status.achievement1.jiujiezhixin=0;
					_status.achievement1.jiujiezhixin++;
				};
			},
		 };
			lib.skill.cixiong_skill={
				trigger:{player:'shaBegin'},
				priority:7,
				audio:true,
				logTarget:'target',
				filter:function(event,player){
					if(player.sex=='male'&&event.target.sex=='female') return true;
					if(player.sex=='female'&&event.target.sex=='male') return true;
					return false;
				},
				content:function(){
					"step 0"
					player.storage.achieve_cxsgj=true;
					trigger.target.chooseToDiscard('弃置一张手牌，或令'+get.translation(player)+'摸一张牌').set('ai',function(card){
						var trigger=_status.event.getTrigger();
						return -get.attitude(trigger.target,trigger.player)-get.value(card);
					});
					"step 1"
					if(result.bool==false) player.draw();
				}
			};
		lib.skill._achieve_cxsgj1={
			trigger:{
				player:"shaAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_cxsgj==true;;
			},
			content:function (){
				delete player.storage.achieve_cxsgj;
			},
		 };
		lib.skill._achieve_zbsm={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_zbsm==true;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('zhangfei')!=-1||
				player.name.indexOf('张飞')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('zhangfei')!=-1||
				player.name2.indexOf('张飞')!=-1)))&&
				lib.config.achievement.shu.yanrendepaoxiao.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.yanrendepaoxiao==undefined) _status.achievement1.yanrendepaoxiao=0;
					_status.achievement1.yanrendepaoxiao++;
				};
			},
		 };
		lib.skill._achieve_zbsm1={
			trigger:{
				player:"shaAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_zbsm==true;
			},
			content:function (){
				delete player.storage.achieve_zbsm;
			},
		 };
			lib.skill.zhangba_skill={
				enable:['chooseToUse','chooseToRespond'],
				filterCard:true,
				selectCard:2,
				position:'h',
				viewAs:{name:'sha'},
				filter:function(event,player){
					return player.countCards('h')>=2;
				},
				audio:true,
				prompt:'将两张手牌当杀使用或打出',
				check:function(card){
					if(card.name=='sha') return 0;
					return 6-get.useful(card)
				},
				onuse:function(result,player){
					player.storage.achieve_zbsm=true;
				},
				ai:{
					respondSha:true,
					skillTagFilter:function(player){
						return player.countCards('h')>=2;
					},
				}
			};
			lib.skill.tieji={
				audio:2,
				trigger:{player:'shaBegin'},
				check:function(event,player){
					return get.attitude(player,event.target)<=0;
				},
				logTarget:'target',
				content:function(){
					"step 0"
					player.judge(function(card){
						if(get.zhu(_status.event.player,'shouyue')){
							if(get.suit(card)!='spade') return 2;
						}
						else{
							if(get.color(card)=='red') return 2;
						}
						return -0.5;
					});
					"step 1"
					if(result.bool){
						if(player==game.me&&((player.name.indexOf('machao')!=-1||
						player.name.indexOf('马超')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('machao')!=-1||
						player.name2.indexOf('马超')!=-1)))&&
						lib.config.achievement.shu.quanjuntuji.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.quanjuntuji==undefined) _status.achievement1.quanjuntuji=0;
							if(player.storage.ext_quanjuntuji==undefined) player.storage.ext_quanjuntuji=0;
							player.storage.ext_quanjuntuji++;
							if(_status.achievement1.quanjuntuji<player.storage.ext_quanjuntuji) _status.achievement1.quanjuntuji=player.storage.ext_quanjuntuji;
						};
						trigger.directHit=true;
					}else{
						player.storage.ext_quanjuntuji=0;
					};
				}
			};
			lib.skill.retieji={
				audio:2,
				audioname:['boss_lvbu3'],
				trigger:{player:'shaBegin'},
				check:function(event,player){
					return get.attitude(player,event.target)<0;
				},
				logTarget:'target',
				content:function(){
					"step 0"
					player.judge(function(){return 0});
					if(!trigger.target.hasSkill('fengyin')){
						trigger.target.addTempSkill('fengyin');
					}
					"step 1"
					if(get.color(result.card)=='red'){
						if(player==game.me&&((player.name.indexOf('machao')!=-1||
						player.name.indexOf('马超')!=-1)||
						(player.name2!=undefined&&(player.name2.indexOf('machao')!=-1||
						player.name2.indexOf('马超')!=-1)))&&
						lib.config.achievement.shu.quanjuntuji.finished!=true){
							if(_status.achievement1==undefined) _status.achievement1={};
							if(_status.achievement1.quanjuntuji==undefined) _status.achievement1.quanjuntuji=0;
							if(player.storage.ext_quanjuntuji==undefined) player.storage.ext_quanjuntuji=0;
							player.storage.ext_quanjuntuji++;
							if(_status.achievement1.quanjuntuji<player.storage.ext_quanjuntuji) _status.achievement1.quanjuntuji=player.storage.ext_quanjuntuji;
						};
					}else{
						player.storage.ext_quanjuntuji=0;
					};
					var suit=get.suit(result.card);
					var target=trigger.target;
					var num=target.countCards('h','shan');
					target.chooseToDiscard('请弃置一张'+get.translation(suit)+'牌，否则不能使用闪抵消此杀','he',function(card){
						return get.suit(card)==_status.event.suit;
					}).set('ai',function(card){
						var num=_status.event.num;
						if(num==0) return 0;
						if(card.name=='shan') return num>1?2:0;
						return 8-get.value(card);
					}).set('num',num).set('suit',suit);
					"step 2"
					if(!result.bool){
						trigger.directHit=true;
					}
				}
			};
		lib.skill._achieve_qlyyd={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_qlyyd==true;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('guanyu')!=-1||
				player.name.indexOf('关羽')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('guanyu')!=-1||
				player.name2.indexOf('关羽')!=-1)))&&
				lib.config.achievement.shu.wushengxianling.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.wushengxianling==undefined) _status.achievement1.wushengxianling=0;
					_status.achievement1.wushengxianling++;
				};
			},
		 };
		 lib.skill._achieve_qlyyd1={
			trigger:{
				player:"shaAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_qlyyd==true;
			},
			content:function (){
				delete player.storage.achieve_qlyyd;
			},
		 };
			lib.skill.qinglong_skill={
				trigger:{player:'shaMiss'},
				direct:true,
				filter:function(event,player){
					if(get.mode()=='guozhan') return false;
					return player.canUse('sha',event.target)&&player.hasSha();
				},
				content:function(){
					"step 0"
					if(player.hasSkill('jiu')){
						game.broadcastAll(function(player){
							player.removeSkill('jiu');
						},player);
						event.jiu=true;
					}
					player.chooseToUse(get.prompt('qinglong'),{name:'sha'},trigger.target,-1).set('addCount',false).logSkill='qinglong_skill';
					player.storage.achieve_qlyyd=true;
					"step 1"
					if(result.bool);
					else if(event.jiu){
						player.addSkill('jiu');
					}
				}
			};
		lib.skill._achieve_qjj1={
			trigger:{
				player:"useCardBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return event.card!=undefined&&event.card.name=='sha'&&player.hasSkill('qinggang_skill');
			},
			content:function (){
				player.storage.achieve_qjj=true;
			},
		 };
		lib.skill._achieve_qjj2={
			trigger:{
				player:"useCardAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_qjj==true;
			},
			content:function (){
				delete player.storage.achieve_qjj;
			},
		 };
		lib.skill._achieve_qjj={
			trigger:{
				player:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				if(event.source==undefined) return false;
				var bool=false;
				var pl=event.source;
				if(pl==game.me&&((pl.name.indexOf('zhaoyun')!=-1||
				pl.name.indexOf('赵云')!=-1)||
				(pl.name2!=undefined&&(pl.name2.indexOf('zhaoyun')!=-1||
				pl.name2.indexOf('赵云')!=-1)))&&
				lib.config.achievement.shu.hunshenshidan.finished!=true&&
				pl.hasSkill('qinggang_skill')&&
				player.get('e','2')!=undefined&&
				pl.storage.achieve_qjj==true) bool=true;
				return bool;
			},
			content:function (){
				if(_status.achievement1==undefined) _status.achievement1={};
				if(_status.achievement1.hunshenshidan==undefined) _status.achievement1.hunshenshidan=0;
				_status.achievement1.hunshenshidan++;
			},
		 };
			lib.skill._achieve_jj={
				trigger:{
					player:'phaseAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					return player.storage.ext_jinnangdai!=undefined;
				},
				content:function(){
					delete player.storage.ext_jinnangdai;
				}
			};
			lib.skill.jizhi={
				audio:2,
				audioname:['jianyong'],
				trigger:{player:'useCard'},
				frequent:true,
				filter:function(event){
					return (get.type(event.card)=='trick'&&(!event.cards.length||event.cards[0]&&event.cards[0]==event.card));
				},
				content:function(){
					if(player==game.me&&((player.name.indexOf('huangyueying')!=-1||
					player.name.indexOf('黄月英')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huangyueying')!=-1||
					player.name2.indexOf('黄月英')!=-1)))&&
					lib.config.achievement.shu.jinnangdai.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.jinnangdai==undefined) _status.achievement1.jinnangdai=0;
						if(player.storage.ext_jinnangdai==undefined) player.storage.ext_jinnangdai=0;
						player.storage.ext_jinnangdai++;
						if(_status.achievement1.jinnangdai<player.storage.ext_jinnangdai) _status.achievement1.jinnangdai=player.storage.ext_jinnangdai;
					};
					player.draw();
				},
				ai:{
					threaten:1.4,
					noautowuxie:true,
				}
			};
			lib.skill.rejizhi={
				audio:'jizhi',
				trigger:{player:'useCard'},
				frequent:true,
				filter:function(event){
					return (get.type(event.card)=='trick');
				},
				init:function(player){
					player.storage.rejizhi=0;
				},
				content:function(){
					'step 0'
					if(player==game.me&&((player.name.indexOf('huangyueying')!=-1||
					player.name.indexOf('黄月英')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huangyueying')!=-1||
					player.name2.indexOf('黄月英')!=-1)))&&
					lib.config.achievement.shu.jinnangdai.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.jinnangdai==undefined) _status.achievement1.jinnangdai=0;
						if(player.storage.ext_jinnangdai==undefined) player.storage.ext_jinnangdai=0;
						player.storage.ext_jinnangdai++;
						if(_status.achievement1.jinnangdai<player.storage.ext_jinnangdai) _status.achievement1.jinnangdai=player.storage.ext_jinnangdai;
					};
					player.draw();
					'step 1'
					event.card=result[0];
					if(get.type(event.card)=='basic'){
						player.chooseBool('是否弃置'+get.translation(event.card)+'并令本回合手牌上限+1？').set('ai',function(evt,player){
							return _status.currentPhase==player&&player.needsToDiscard(-3)&&_status.event.value<6;
						}).set('value',get.value(event.card,player));
					}
					'step 2'
					if(result.bool){
						player.discard(event.card);
						player.storage.rejizhi++;
						if(_status.currentPhase==player){
							player.markSkill('rejizhi');
						}
					}
				},
				ai:{
					threaten:1.4,
					noautowuxie:true,
				},
				mod:{
					maxHandcard:function(player,num){
						return num+player.storage.rejizhi;
					}
				},
				intro:{
					content:'本回合手牌上限+#'
				},
				group:'rejizhi_clear',
				subSkill:{
					clear:{
						trigger:{global:'phaseAfter'},
						silent:true,
						content:function(){
							player.storage.rejizhi=0;
							player.unmarkSkill('rejizhi');
						}
					}
				}
			};
			lib.skill._achieve_kc={
				trigger:{
					player:'phaseEnd'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					var bool=false;
					if(player==game.me&&((player.name.indexOf('zhugeliang')!=-1||
					player.name.indexOf('诸葛亮')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('zhugeliang')!=-1||
					player.name2.indexOf('诸葛亮')!=-1)))&&
					lib.config.achievement.shu.kongchengjuechang.finished!=true&&
					player.hasSkill('kongcheng')) bool=true;
					return bool;
				},
				content:function(){
					if(player.countCards('h')>0){
						player.storage.ext_kongchengjuechang=0;
					}else{
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.kongchengjuechang==undefined) _status.achievement1.kongchengjuechang=0;
						if(player.storage.ext_kongchengjuechang==undefined) player.storage.ext_kongchengjuechang=0;
						player.storage.ext_kongchengjuechang++;
						if(_status.achievement1.kongchengjuechang<player.storage.ext_kongchengjuechang) _status.achievement1.kongchengjuechang=player.storage.ext_kongchengjuechang;
					};
				}
			};
		lib.skill._achieve_fthj={
			trigger:{
				global:"dieBefore",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_fthj!=undefined;;
			},
			content:function (){
				if(player==game.me&&((player.name.indexOf('lvbu')!=-1||
				player.name.indexOf('吕布')!=-1)||
				(player.name2!=undefined&&(player.name2.indexOf('lvbu')!=-1||
				player.name2.indexOf('吕布')!=-1)))&&
				lib.config.achievement.qun.feijiang.finished!=true){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.feijiang==undefined) _status.achievement1.feijiang=0;
					player.storage.achieve_fthj++;
					if(_status.achievement1.feijiang<player.storage.achieve_fthj) _status.achievement1.feijiang=player.storage.achieve_fthj;
				};
			},
		 };
		lib.skill._achieve_fthj1={
			trigger:{
				player:"useCardAfter",
			},
			forced:true,
			popup:false,
			filter:function(event,player){
				return player.storage.achieve_fthj!=undefined;
			},
			content:function (){
				delete player.storage.achieve_fthj;
			},
		 };
			lib.skill._achieve_fthj2={
				trigger:{
					player:'useCardBefore'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					var bool=false;
					if(player==game.me&&((player.name.indexOf('lvbu')!=-1||
					player.name.indexOf('吕布')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('lvbu')!=-1||
					player.name2.indexOf('吕布')!=-1)))&&
					lib.config.achievement.qun.feijiang.finished!=true&&
					(player.hasSkill('fangtian_skill')||player.hasSkill('fangtian_guozhan'))&&
					player.countCards('h')==1&&
					player.get('h')[0].name=='sha') bool=true;
					return bool;
				},
				content:function(){
					player.storage.achieve_fthj=0;
				}
			};
			lib.skill.lijian={
				audio:2,
				enable:'phaseUse',
				usable:1,
				filter:function(event,player){
					return game.countPlayer(function(current){
						return current!=player&&current.sex=='male';
					})>1;
				},
				check:function(card){return 10-get.value(card)},
				filterCard:true,
				position:'he',
				filterTarget:function(card,player,target){
					if(player==target) return false;
					if(target.sex!='male') return false;
					if(ui.selected.targets.length==1){
						return target.canUse({name:'juedou'},ui.selected.targets[0]);
					}
					return true;
				},
				targetprompt:['先出杀','后出杀'],
				selectTarget:2,
				multitarget:true,
				content:function(){
					'step 0'
					targets[1].useCard({name:'juedou'},targets[0],'noai').animate=false;
					game.delay(0.5);
					'step 1'
					if(player==game.me&&((player.name.indexOf('diaochan')!=-1||
					player.name.indexOf('貂蝉')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('diaochan')!=-1||
					player.name2.indexOf('貂蝉')!=-1)))&&
					lib.config.achievement.qun.qingguoqingcheng.finished!=true){
						if(_status.achievement1==undefined) _status.achievement1={};
						if(_status.achievement1.qingguoqingcheng==undefined) _status.achievement1.qingguoqingcheng=0;
						if(!targets[0].isAlive()) _status.achievement1.qingguoqingcheng++;
						if(!targets[1].isAlive()) _status.achievement1.qingguoqingcheng++;
					};
				},
				ai:{
					order:8,
					result:{
						target:function(player,target){
							if(ui.selected.targets.length==0){
								return -3;
							}
							else{
								return get.effect(target,{name:'juedou'},ui.selected.targets[0],target);
							}
						}
					},
					expose:0.4,
					threaten:3,
				}
			};
			lib.skill.jijiu={
				audio:2,
				audioname:['re_huatuo'],
				enable:'chooseToUse',
				filter:function(event,player){
					return _status.currentPhase!=player;
				},
				filterCard:function(card){
					return get.color(card)=='red';
				},
				position:'he',
				viewAs:{name:'tao'},
				prompt:'将一张红色牌当桃使用',
				check:function(card){return 15-get.value(card)},
				onuse:function(result,player){
					if(player==game.me&&((player.name.indexOf('huatuo')!=-1||
					player.name.indexOf('华佗')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huatuo')!=-1||
					player.name2.indexOf('华佗')!=-1)))&&
					lib.config.achievement.qun.luanshimingyi.finished!=true){
						if(player.storage.ext_luanshimingyi==undefined) player.storage.ext_luanshimingyi=[];
					};
				},
				ai:{
					skillTagFilter:function(player){
						return player.countCards('he',{color:'red'})>0&&_status.currentPhase!=player;
					},
					threaten:1.5,
					save:true,
					respondTao:true,
				}
			},
			lib.skill._achieve_jijiu={
				trigger:{
					target:'taoAfter'
				},
				forced:true,
				popup:false,
				filter:function(event,player){
					return event.player!=undefined&&event.player.storage.ext_luanshimingyi!=undefined&&player.hp>0;
				},
				content:function(){
					if(_status.achievement1==undefined) _status.achievement1={};
					if(_status.achievement1.luanshimingyi==undefined) _status.achievement1.luanshimingyi=0;
					if(!trigger.player.storage.ext_luanshimingyi.contains(player)){
						trigger.player.storage.ext_luanshimingyi.push(player);
						_status.achievement1.luanshimingyi++;
					};
				}
			};
			lib.skill.yaowu={
				trigger:{player:'damageEnd'},
				priority:1,
				audio:2,
				filter:function(event){
					if(event.card&&(event.card.name=='sha')){
						if(get.color(event.card)=='red') return true;
					}
					return false;
				},
				forced:true,
				check:function(){
					return false;
				},
				content:function(){
					if(player==game.me&&((player.name.indexOf('huaxiong')!=-1||
					player.name.indexOf('华雄')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huaxiong')!=-1||
					player.name2.indexOf('华雄')!=-1)))&&
					lib.config.achievement.qun.yaowuyangwei.finished!=true){
						if(_status.achievement2==undefined) _status.achievement2={};
						if(_status.achievement2.yaowuyangwei==undefined) _status.achievement2.yaowuyangwei=0;
						_status.achievement2.yaowuyangwei++;
					};
					trigger.source.chooseDrawRecover(true);
				},
				ai:{
					effect:{
						target:function(card,player,target,current){
							if(card.name=='sha'&&(get.color(card)=='red')){
								return [1,-2];
							}
						}
					}
				}
			};
            lib.skill.new_reyaowu={
                trigger:{
                    player:"damageEnd",
                },
                priority:1,
                audio:"yaowu",
                filter:function (event){
					if(event.card&&(event.card.name=='sha')){
						if(['red','black'].contains(get.color(event.card))) return true;
					}
					return false;
				},
                forced:true,
                check:function (event){
					if(event.card&&(event.card.name=='sha')){
						return get.color(event.card)=='black';
					}
				},
                content:function (){
					if(player==game.me&&((player.name.indexOf('huaxiong')!=-1||
					player.name.indexOf('华雄')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('huaxiong')!=-1||
					player.name2.indexOf('华雄')!=-1)))&&
					lib.config.achievement.qun.yaowuyangwei.finished!=true){
						if(_status.achievement2==undefined) _status.achievement2={};
						if(_status.achievement2.yaowuyangwei==undefined) _status.achievement2.yaowuyangwei=0;
						_status.achievement2.yaowuyangwei++;
					};
					if(get.color(trigger.cards)=='black') player.draw();
					else trigger.source.chooseDrawRecover(true);
				},
                ai:{
                    effect:{
						target:function (card,player,target,current){
							if(card.name=='sha'&&(get.color(card)=='red')){
								return [1,-2];
							}
							if(card.name=='sha'&&(get.color(card)=='black')){
								return [0,-0.6];
							}
						},
                    },
                },
            };
			lib.skill.wangzun={
				audio:2,
				trigger:{global:'phaseBegin'},
				check:function(event,player){
					var att=get.attitude(player,event.player);
					return !game.hasPlayer(function(current){
						return get.attitude(player,current)<att;
					});
				},
				filter:function(event,player){
					return event.player!=player&&!player.storage.wangzun;
				},
				logTarget:'player',
				content:function(){
					if(player==game.me&&((player.name.indexOf('yuanshu')!=-1||
					player.name.indexOf('袁术')!=-1)||
					(player.name2!=undefined&&(player.name2.indexOf('yuanshu')!=-1||
					player.name2.indexOf('袁术')!=-1)))&&
					lib.config.achievement.qun.dengjizhizun.finished!=true&&
					(player.identity=='fan'||player.identity=='nei')&&
					trigger.player.identity=='zhu'){
						if(_status.achievement2==undefined) _status.achievement2={};
						if(_status.achievement2.dengjizhizun==undefined) _status.achievement2.dengjizhizun=0;
						_status.achievement2.dengjizhizun++;
					};
					player.draw();
					player.markSkill('wangzun');
					player.storage.wangzun=trigger.player;
					trigger.player.addTempSkill('wangzun3');
				},
				ai:{
					expose:0.2
				},
				intro:{
					content:'player'
				},
				group:'wangzun2'
			};
		 
		 
		 
		 
		 
		 
		
		
		
		
		
		
		
		
		
	lib.kzol_nodeintro['zgcj']=function(uiintro,character,skills){
		var ext_div=ui.create.div('.text');
		ext_div.innerHTML='';
		var ext_num=0;
		for(var i in achievement){
			for(var j in achievement[i]){
				var achievement2=achievement[i][j];
				var condition1=achievement2.condition[1];
				if(condition1.owner!=undefined){
					if(character!=undefined&&character.indexOf(condition1.owner)!=-1){
						if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
						ext_div.innerHTML+='可用来完成【'+achievement2.name+'】';
						ext_num++;
					};
				};
			};
		};
		if(character!=undefined&&(character.indexOf('caocao')!=-1||character.indexOf('曹操')!=-1)&&(skills.contains('jianxiong')||skills.contains('xinjianxiong')||skills.contains('new_rejianxiong'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【乱世的奸雄】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhangliao')!=-1||character.indexOf('张辽')!=-1)&&(skills.contains('new_retuxi')||skills.contains('tuxi'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【神其无备】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('xiahoudun')!=-1||character.indexOf('夏侯惇')!=-1)&&(skills.contains('ganglie')||skills.contains('reganglie'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【两败俱伤】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('xuzhu')!=-1||character.indexOf('许褚')!=-1)&&(skills.contains('luoyi')||skills.contains('new_reluoyi'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【妈，我冷】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('guojia')!=-1||character.indexOf('郭嘉')!=-1)&&(skills.contains('yiji')||skills.contains('new_reyiji'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【不遗余力】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('simayi')!=-1||character.indexOf('司马懿')!=-1)&&(skills.contains('fankui')||skills.contains('refankui'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【手眼通天】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhenji')!=-1||character.indexOf('甄姬')!=-1)&&(skills.contains('luoshen')||skills.contains('reluoshen'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【洛神赋】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('sunquan')!=-1||character.indexOf('孙权')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【年轻有为】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('ganning')!=-1||character.indexOf('甘宁')!=-1)&&skills.contains('qixi')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【神出鬼没】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('huanggai')!=-1||character.indexOf('黄盖')!=-1)&&(skills.contains('kurou')||skills.contains('rekurou'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【无尽的鞭挞】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('lvmeng')!=-1||character.indexOf('吕蒙')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【伺机待发】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('daqiao')!=-1||character.indexOf('大乔')!=-1)&&skills.contains('liuli')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【移花接木】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('sunshangxiang')!=-1||character.indexOf('孙尚香')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【因祸得福】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhouyu')!=-1||character.indexOf('周瑜')!=-1)&&skills.contains('fanjian')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【无尽的挣扎】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('luxun')!=-1||character.indexOf('陆逊')!=-1)&&(skills.contains('lianying')||skills.contains('relianying'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【连绵不绝】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('liubei')!=-1||character.indexOf('刘备')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【纠结之心】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhangfei')!=-1||character.indexOf('张飞')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【燕人的咆哮】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('machao')!=-1||character.indexOf('马超')!=-1)&&(skills.contains('tieji')||skills.contains('retieji'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【全军突击】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('guanyu')!=-1||character.indexOf('关羽')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【武圣显灵】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhaoyun')!=-1||character.indexOf('赵云')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【浑身是胆】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('huangyueying')!=-1||character.indexOf('黄月英')!=-1)&&(skills.contains('jizhi')||skills.contains('rejizhi'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【锦囊袋】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('zhugeliang')!=-1||character.indexOf('诸葛亮')!=-1)&&skills.contains('kongcheng')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【空城绝唱】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('lvbu')!=-1||character.indexOf('吕布')!=-1)){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【飞将】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('diaochan')!=-1||character.indexOf('貂蝉')!=-1)&&skills.contains('lijian')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【倾国倾城】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('huatuo')!=-1||character.indexOf('华佗')!=-1)&&skills.contains('jijiu')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【乱世名医】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('huaxiong')!=-1||character.indexOf('华雄')!=-1)&&(skills.contains('yaowu')||skills.contains('new_reyaowu'))){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【耀武扬威】';
			ext_num++;
		};
		if(character!=undefined&&(character.indexOf('yuanshu')!=-1||character.indexOf('袁术')!=-1)&&skills.contains('wangzun')){
			if(ext_div.innerHTML!='') ext_div.innerHTML+='<br>';
			ext_div.innerHTML+='可用来完成【登极至尊】';
			ext_num++;
		};
		if(ext_num>0&&lib.config['extension_扩展ol_zgcj_show']==true) uiintro.add(ext_div);
	};
	if(lib.config.aurora_mysql_user!=undefined){
		lib.translate.course='游戏历程';
		lib.extensionMenu.extension_扩展ol.lwgn_put={
			'name':'上传数据',
			"clear":true,
			onclick:function(){
				if(lib.aurora_mysql_connection==false){
					game.say1('数据库连接中...');
					return ;
				};
				if(confirm('是否上传数据？')){
					var ljgn_achievement={};
					for(var i in achievement){
						var a=achievement[i];
						ljgn_achievement[i]='';
						for(var j in a){
							if(lib.config.achievement[i][j].finished==true){
								ljgn_achievement[i]+='1';
							}else{
								ljgn_achievement[i]+='2';
							};
						};
					};
					for(var i in ljgn_achievement){
						lib.aurora_mysql.query('UPDATE 数据 SET '+i+'='+ljgn_achievement[i]+' WHERE user="'+lib.config.aurora_mysql_user+'"',function(err, result){
							game.say1(get.translation(this.link)+'部分上传完成');
						}).link=i;
					};
				};
			},
		};
		lib.extensionMenu.extension_扩展ol.lwgn_fetch={
			'name':'读取数据',
			"clear":true,
			onclick:function(){
				if(lib.aurora_mysql_connection==false){
					game.say1('数据库连接中...');
					return ;
				};
				if(confirm('是否读取数据？（刚上传完的数据须刷新游戏后才能读取）')){
					var str='';
					for(var i in achievement){
						if(i!='course') str+=',';
						str+=i;
					};
					lib.aurora_mysql.query('SELECT '+str+' FROM 数据 WHERE user="'+lib.config.aurora_mysql_user+'"',function(err, result){
						if(err){
							throw err;
						}else{
							for(var i in result[0]){
								var ljgn_achievement=result[0][i];
								var list=[];
								for(var k in achievement[i]){
									list.push(k);
								};
								if(ljgn_achievement.length<list.length){
									for(var l=0;l<(list.length-ljgn_achievement.length);l++){
										ljgn_achievement+='2';
									};
								};
								for(var j=0;j<ljgn_achievement.length;j++){
									if(ljgn_achievement[j]=='1'){
										lib.config.achievement[i][list[j]].finished=true;
										lib.config.achievement[i][list[j]].finished_data=date.getFullYear()+'年'+(date.getMonth()+1)+'月'+date.getDate()+'日  '+date.getHours()+'时'+date.getMinutes()+'分'+date.getSeconds()+'秒';
									}else{
										delete lib.config.achievement[i][list[j]];
									};
								};
							};
							game.saveConfig('achievement',lib.config.achievement);
							alert('读取成功，点击确认刷新游戏');
							game.reload();
							console.log(result);
						};
					});
				};
			},
		};
	};
}