window.func=function(lib,game,ui,get,ai,_status){
	if(lib.brawl) {
		lib.brawl.qxhz={
			name:'群雄混战',
			mode:'guozhan',
			intro:[
				'游戏开始时，所有势力不是吴、蜀、魏、晋的角色变为野心家',
			],
			init:function(){
				lib.skill._kzol_qxhz={
					trigger:{
						global:"gameStart",
					},
					forced:true,
					popup:false,
					filter:function(event,player){
						return _status.kzol_qxhz!=true;
					},
					content:function (){
						_status.kzol_qxhz=true;
						lib.element.content.showCharacter=function(){
							if(player.identity=='ye') player.setIdentity();
							lib.element.player.$showCharacter.apply(player,event._args);
						};
						game.showIdentity=function(started){
							if(game.phaseNumber==0&&!started) return;
							for(var i=0;i<game.players.length;i++){
								var pl=game.players[i];
								if(pl.identity=='ye') pl.setIdentity();
								pl.showCharacter(2,false);
							}
						};
						for(var i=0;i<game.players.length;i++){
							var pl=game.players[i];
							var group=lib.character[pl.name1][1];
							var group1=lib.translate[group];
							if(group1!='吴'&&group1!='蜀'&&group1!='魏'&&group1.indexOf('晋')==-1){
								pl.identity='ye';
								//pl.setIdentity();
							};
						};
					},
				};
			},
		};
	};
}