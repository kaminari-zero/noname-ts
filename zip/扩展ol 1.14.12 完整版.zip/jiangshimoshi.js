window.func = function (lib, game, ui, get, ai, _status) {
	if (lib.brawl) {
		lib.brawl.jiangshimoshi = {
			name: '僵尸模式',
			mode: 'identity',
			intro: [
				'移植神杀的僵尸模式，规则有改动。<br><span style=\"color:#EE7621;font-size:18px\"><p align="center">规则介绍</p></span>',
				'1.在此模式中主公为领导者，忠臣为人类，反贼、内奸为僵尸。',
				'2.游戏开始时，所有非领导者角色的身份变为人类，领导者变化退治印记（退治印记为轮次数-退治印记的传承数）。',
				'3.若领导者死亡，则下一名人类玩家成为领导者，生命与上限+1，并被传承退治印记。',
				'4.第二轮的首个开始时，夜幕降临，此轮中会有X个人类变为反贼僵尸（X为存活人数/6（向上整取））。以此法变为反贼僵尸时，体力上限为5。',
				'5.人类死亡时会被病毒侵染，变为内奸僵尸。',
				'6.内奸僵尸杀死领导者、人类、内奸僵尸后变为反贼僵尸。',
				'7.当场上没有僵尸时，不会有角色死亡。',
				'8.领导者和人类获得技能【互助】<br><span style=\"color:#EE7621;font-size:18px\"><p align="center">游戏结束条件</p></span>',
				'1.退治成功，领导者和人类胜利，僵尸失败：<br>任何玩家回合开始时，主公退治印记到达X（X为游戏人数且至少为8）。<br>击杀所有僵尸。',
				'2.退治失败，反贼僵尸胜利，其余玩家失败：<br>领导者阵亡并且场上没有可以代替领导者的人类。'],
			content: {
				gameStart: function () {
					var players = [];
					for (var i = 0; i < game.players.length; i++) {
						if (game.players[i] != game.zhu) {
							players.push(game.players[i]);
							game.players[i].identity = 'zhong';
						};
					};
					game.showIdentity();
					for (var i = 0; i < game.players.length; i++) {
						var pl = game.players[i];
						if (pl.identity == 'zhong') {
							pl.node.identity.firstChild.innerHTML = '人类';
						}
						else {
							pl.node.identity.firstChild.innerHTML = '僵尸';
						};
						if (pl == game.zhu) pl.node.identity.firstChild.innerHTML = '领导者';
						pl.node.identity.dataset.color = pl.identity;
					};
					game.zhu.storage.tuizhi = 0;
					var num = 1;
					if (game.players.length > 6 && game.players.length <= 12) num = 2;
					if (game.players.length > 12 && game.players.length <= 18) num = 3;
					game.first_js = players.randomGets(num);
				},
			},
			init: function () {
				lib.config.mode_config.identity.identity_mode='normal';
				lib.skill._jiangshiTx = {
					skillAnimation: 'epic',
					animationStr: '灵魂献祭',
					forced: true,
					trigger: {
						player: 'dieBefore'
					},
					filter: function (event, player) {
						return player.identity == 'zhong' && game.roundNumber >= 2;
					},
					content: function () {
						game.log('灵魂献祭');
					}
				};
				lib.skill._jiangshiTx2 = {
					skillAnimation: 'epic',
					animationStr: '僵尸灭亡',
					animationColor: 'thunder',
					forced: true,
					trigger: {
						player: 'dieBefore'
					},
					filter: function (event, player) {
						return player.identity == 'fan' || (player.identity == 'nei'&&event.bianjs!='fan');
					},
					content: function () {
						game.log('僵尸灭亡');
					}
				};
				lib.skill._jiangshiTx4 = {
					skillAnimation: 'epic',
					animationStr: '僵尸进化',
					animationColor: 'thunder',
					forced: true,
					trigger: {
						player: 'dieBefore'
					},
					filter: function (event, player) {
						return player.identity == 'nei'&&event.bianjs=='fan';
					},
					content: function () {
						game.log('僵尸进化');
					}
				};
				lib.skill._jiangshiTx3 = {
					skillAnimation: 'epic',
					animationStr: '暗夜降临',
					animationColor: 'thunder',
					trigger: {
						player: 'phaseBegin'
					},
					forced: true,
					filter: function (event, player) {
						return game.roundNumber == 2 && game.ayjl != true;
					},
					content: function () {
						game.ayjl = true;
						game.log('暗夜降临');
					}
				}
				lib.skill._tuizhi = {
					trigger: {
						player: 'phaseBegin'
					},
					forced: true,
					popup: false,
					priority: 2,
					content: function () {
						var num = game.roundNumber;
						if (game.zhu.storage.tuizhi != undefined) num -= game.zhu.storage.tuizhi;
						game.zhu.storage.tuizhi1 = num;
						game.zhu.markSkill('tuizhi1');
						game.zhu.syncStorage('tuizhi1');
					},
				};
				lib.skill.tuizhi1 = {
					intro: {
						content: function (storage, player, skill) {
							return '当前有' + (game.roundNumber - player.storage.tuizhi) + '个‘退治’标记';
						},
					},
					marktext: '退',
				};
				lib.skill._tuizhi2 = {
					skillAnimation: 'epic',
					animationStr: '退治成功',
					animationColor: 'metal',
					trigger: {
						player: 'phaseBegin'
					},
					forced: true,
					priority: 1,
					filter: function (event, player) {
						var num = 8;
						if (game.players.length + game.dead.length > 8) num = game.players.length + game.dead.length;
						var num1 = game.roundNumber;
						if (game.zhu.storage.tuizhi != undefined) num1 -= game.zhu.storage.tuizhi;
						return num1 >= num;
					},
					content: function () {
						if (game.me.identity == 'zhu' || game.me.identity == 'zhong') {
							game.over(true);
						}
						else {
							game.over(false);
						};
					}
				};
				lib.skill._jiangshi = {
					trigger: {
						player: 'dieBegin'
					},
					forced: true,
					popup: false,
					filter: function (event, player) {
						return (player.identity == 'zhong'||(player.identity == 'nei'&&event.bianjs=='fan'))&& game.roundNumber >= 2;
					},
					content: function () {
						if (trigger.bianjs == "fan") {
							player.draw(4);
							player.discard(player.get("hej"));
							player.revive();
							player.uninit;
							player.init(player.name, 'jiangshifz');
							player.maxHp = 5;
							player.hp = player.maxHp;
							player.identity = 'fan';
						}
						else {
							player.draw(4);
							player.discard(player.get("hej"));
							player.revive();
							player.uninit;
							player.init(player.name, 'jiangshinj');
							player.hp = player.maxHp;
							player.identity = 'nei';
						};
						game.showIdentity();
						for (var i = 0; i < game.players.length; i++) {
							var pl = game.players[i];
							if (pl.identity == 'zhong') {
								pl.node.identity.firstChild.innerHTML = '人类';
							}
							else {
								pl.node.identity.firstChild.innerHTML = '僵尸';
							};
							if (pl == game.zhu) pl.node.identity.firstChild.innerHTML = '领导者';
							pl.node.identity.dataset.color = pl.identity;
						};
						trigger.untrigger();
						trigger.finish();
					}
				};
				lib.skill._jiangshi1 = {
					trigger: {
						player: 'dieBefore'
					},
					forced: true,
					popup: false,
					priority: Infinity,
					filter: function (event, player) {
						return game.countPlayer(function (current) {
							return current.identity == 'fan' || current.identity == 'nei'
						}) == 0 && event.bianjs == undefined;
					},
					content: function () {
						player.hp = 0;
						trigger.untrigger();
						trigger.finish();
					}
				};
				lib.skill._jiangshi2 = {
					trigger: {
						player: 'phaseBefore'
					},
					forced: true,
					popup: false,
					priority: Infinity,
					filter: function (event, player) {
						return game.first_js.contains(player) && game.roundNumber == 2;
					},
					content: function () {
						player.die().bianjs = "fan";
					}
				}
				lib.skill._jiangshi3 = {
					skillAnimation: 'epic',
					animationStr: '僵尸进化',
					animationColor: 'thunder',
					trigger: {
						source: 'dieBefore'
					},
					forced: true,
					popup: false,
					filter: function (event, player) {
						return (event.player.identity == 'zhong' || event.player.identity == 'nei'|| event.player.identity == 'zhu') && player.identity == 'nei';
					},
					content: function () {
						player.identity = 'fan';
						player.init(player.name, 'jiangshifz');
						game.showIdentity();
						for (var i = 0; i < game.players.length; i++) {
							var pl = game.players[i];
							if (pl.identity == 'zhong') {
								pl.node.identity.firstChild.innerHTML = '人类';
							}
							else {
								pl.node.identity.firstChild.innerHTML = '僵尸';
							};
							if (pl == game.zhu) pl.node.identity.firstChild.innerHTML = '领导者';
							pl.node.identity.dataset.color = pl.identity;
						};
					},
				};
				lib.skill._jiangshi4 = {
					skillAnimation: 'epic',
					animationStr: '主公阵亡',
					animationColor: 'metal',
					trigger: {
						player: 'dieBegin'
					},
					forced: true,
					popup: false,
					filter: function (event, player) {
						return player == game.zhu;
					},
					content: function () {
						for (var i = 0; i < game.players.length; i++) {
							if (game.players[i].identity == 'zhong') {
								event.target = game.players[i];
								break;
							}
						}
						if (event.target) {
							game.zhu.line(event.target, 'thunder');
							game.log(game.zhu, '死亡<br>', event.target, '成为了新的主公！');
							game.zhu = event.target;
							event.target.identity = 'zhu';
							event.target.gainMaxHp();
							event.target.recover();
							event.target.storage.tuizhi = player.storage.tuizhi + 1;
							event.target.markSkill('_tuizhi');
							event.target.syncStorage('_tuizhi');
							game.showIdentity();
							for (var i = 0; i < game.players.length; i++) {
								var pl = game.players[i];
								if (pl.identity == 'zhong') {
									pl.node.identity.firstChild.innerHTML = '人类';
								}
								else {
									pl.node.identity.firstChild.innerHTML = '僵尸';
								};
								if (pl == game.zhu) pl.node.identity.firstChild.innerHTML = '领导者';
								pl.node.identity.dataset.color = pl.identity;
							};
						}
					}
				}
				lib.skill._huzhu = {
					enable: 'phaseUse',
					usable: 1,
					filterCard: function (card, player) {
						return card.name == 'tao';
					},
					filter: function (event, player) {
						return player.identity == 'zhong' || player.identity == 'zhu';
					},
					filterTarget: function (card, player, target) {
						if (player == target) return false;
						return get.distance(player, target) <= 1 && target.isDamaged() && (target.identity == 'zhong' || target.identity == 'zhu');
					},
					content: function () {
						player.useCard({
							name: 'tao'
						}, target)
					}
				}
				/*lib.translate._tuizhi='退治'
				lib.translate._jiangshi='僵尸'
				lib.translate._jiangshi1='僵尸'
				lib.translate._jiangshi2='僵尸'
				lib.translate._jiangshi4='僵尸'*/
				lib.translate._tuizhi2 = '退治成功'
				lib.translate._jiangshi3='僵尸进化'
				lib.translate._jiangshiTx = '灵魂献祭'
				lib.translate._jiangshiTx2 = '僵尸灭亡'
				lib.translate._jiangshiTx3 = '暗夜降临'
				lib.translate._jiangshiTx4 = '僵尸进化'
				lib.translate.tuizhi1 = '退治'
				lib.translate._huzhu = '互助'
				lib.translate._huzhu_info = '出牌阶段限一次，人类玩家可以弃置一张【桃】令距离一的人类玩家恢复一点体力'
			},
		};
	};
}