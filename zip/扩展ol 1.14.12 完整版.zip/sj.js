window.func = function (lib, game, ui, get, ai, _status) {
	if(lib.config.kzol_bag_num==undefined) game.saveConfig('kzol_bag_num',0);
	if(lib.kzol_bag==undefined) lib.kzol_bag={};
	if(lib.config.kzol_bag==undefined) lib.config.kzol_bag={};
	game.saveConfig('kzol_bag',lib.config.kzol_bag);
	var bag={
		'shuijing':{
			name:'shuijing',
			info:'扩展ol代币',
			type:'material',
			canLay:true,
			noBorder:true,
		},
	};
	for(var i in bag){
		var item=bag[i];
		lib.kzol_bag[i]=item;
	};
	lib.translate.shuijing='水晶';
}