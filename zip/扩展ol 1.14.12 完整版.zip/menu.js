window.func=function(lib,game,ui,get,ai,_status){
	lib.arenaReady.push(function(){
		ui.扩展ol_menu=ui.create.system('扩展ol菜单',null,true);
		lib.setPopped(ui.扩展ol_menu,function(){
			var uiintro=ui.create.dialog('hidden');
			uiintro.listen(function(e){
				e.stopPropagation();
			});
			var bag=ui.create.div('.menubutton.large','<span style="cursor:pointer;">背包</span>',function(){
				game.openBag();
				uiintro.hide();
			});
			bag.style.height='30px';
			bag.style.width='175px';
			bag.style.borderRadius='8px';
			bag.style.backgroundColor="#E00000";
			uiintro.add(bag);
			var task=ui.create.div('.menubutton.large','<span style="cursor:pointer;">任务</span>',function(){
				game.openTask();
				uiintro.hide();
			});
			task.style.height='30px';
			task.style.width='175px';
			task.style.borderRadius='8px';
			task.style.backgroundColor="#E00000";
			uiintro.add(task);
			var achievement=ui.create.div('.menubutton.large','<span style="cursor:pointer;">战功</span>',function(){
				game.扩展ol_menu_config=true;
				lib.extensionMenu.extension_扩展ol['zgcj_check'].onclick();
				uiintro.hide();
			});
			achievement.style.height='30px';
			achievement.style.width='175px';
			achievement.style.borderRadius='8px';
			achievement.style.backgroundColor="#E00000";
			uiintro.add(achievement);
			var user=ui.create.div('.menubutton.large','<span style="cursor:pointer;">帐号</span>',function(){
				if(lib.config.extension_扩展ol_lwgn_forbidden==true){
					game.say1('请先关闭禁止连接mySQL数据库选项');
					return ;
				};
				if(!lib.device){
					var dialog=ui.create.dialog('hidden');
					dialog.style.height='280px';
					dialog.style.width='350px';
					//dialog.style.top=event.clientY+document.body.scrollTop+'px';
					//dialog.style.left=event.clientX+document.body.scrollLeft+'px';
					dialog.style.top='calc(50% - 200px)';
					dialog.style.left='calc(50% - 175px)';
					dialog.setBackgroundImage('extension/扩展ol/Background3.jpg');
					dialog.style.backgroundSize="cover";
					dialog.classList.add('popped');
					dialog.classList.add('static');
					var str='<span style="cursor:pointer;">登录</span>';
					if(lib.config.aurora_mysql_user!=undefined) str=get.translation(lib.config.aurora_mysql_user);
					var div1=ui.create.div('.menubutton.large',str,function(){
						if(lib.config.aurora_mysql_user==undefined){
							game.扩展ol_menu_config=true;
							lib.extensionMenu.extension_扩展ol.lwgn_signIn.onclick();
						}else{
							game.say1('欢迎你，'+get.translation(lib.config.aurora_mysql_user));
						};
					});
					div1.style.height='30px';
					div1.style.width='300px';
					dialog.add(div1);
					var div2=ui.create.div('.menubutton.large','<span style="cursor:pointer;">注册</span>',function(){
						game.扩展ol_menu_config=true;
						lib.extensionMenu.extension_扩展ol.lwgn_signUp.onclick();
					});
					div2.style.height='30px';
					div2.style.width='300px';
					dialog.add(div2);
					var div3=ui.create.div('.menubutton.large','<span style="cursor:pointer;">上传</span>',function(){
						if(lib.config.aurora_mysql_user==undefined){
							game.say1('请先登录');
						}else{
							lib.extensionMenu.extension_扩展ol.lwgn_put.onclick();
						};
					});
					div3.style.height='30px';
					div3.style.width='300px';
					dialog.add(div3);
					var div4=ui.create.div('.menubutton.large','<span style="cursor:pointer;">读取</span>',function(){
						if(lib.config.aurora_mysql_user==undefined){
							game.say1('请先登录');
						}else{
							lib.extensionMenu.extension_扩展ol.lwgn_fetch.onclick();
						};
					});
					div4.style.height='30px';
					div4.style.width='300px';
					dialog.add(div4);
					var div5=ui.create.div('.menubutton.large','<span style="cursor:pointer;">退出登录</span>',function(){
						if(lib.config.aurora_mysql_user==undefined){
							game.say1('请先登录');
						}else{
							lib.extensionMenu.extension_扩展ol.lwgn_exit.onclick();
						};
					});
					div5.style.height='30px';
					div5.style.width='300px';
					dialog.add(div5);
					ui.window.appendChild(dialog);
					var close=ui.create.control('关闭',function(){
						dialog.close();
						close.close();
					});
					uiintro.hide();
				}else{
					game.say1('手机暂时无法使用');
				};
			});
			user.style.height='30px';
			user.style.width='175px';
			user.style.borderRadius='8px';
			user.style.backgroundColor="#E00000";
			uiintro.add(user);
			var more=ui.create.div('.menubutton.large','<span style="cursor:pointer;">更多</span>',function(){
				ui.click.configMenu();
				ui.click.menuTab('扩展');
				game.say1('点击扩展ol以查看更多选项');
				uiintro.hide();
			});
			more.style.height='30px';
			more.style.width='175px';
			more.style.borderRadius='8px';
			more.style.backgroundColor="#E00000";
			uiintro.add(more);
			return uiintro;
		},220);
	});
}