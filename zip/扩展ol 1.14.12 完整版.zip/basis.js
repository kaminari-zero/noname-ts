window.func=function(lib,game,ui,get,ai,_status){
	/*lib.init.css(lib.assetURL+'extension/扩展ol','style');
	document.body.classList.add('hide-system-cursor');
	var div1 = document.createElement("div"); 
	div1.classList.add('cursor');
	div1.style['pointer-events']='none';
	document.body.appendChild(div1);
	var div = document.createElement("div"); 
	div.id="horiz";
	div.classList.add('horizontal');
	div.style['pointer-events']='none';
	div1.appendChild(div);
	var div = document.createElement("div"); 
	div.id="vertical";
	div.classList.add('vertical');
	div.style['pointer-events']='none';
	div1.appendChild(div);
	var div = document.createElement("div"); 
	div.id="middle";
	div.classList.add('middle');
	div.style['pointer-events']='none';
	div1.appendChild(div);
	var horiz = document.getElementById('horiz'),
		vertical = document.getElementById('vertical'),
		middle = document.getElementById('middle'),
		moving = false;
	document.onmousemove = function (e) {
		var x = e.pageX,
			y = e.pageY;
		if (!moving) {
			horiz.classList.add('moving');
			vertical.classList.add('moving');
			middle.classList.add('moving');
			moving = true;
		}
		horiz.style.top = y - 1 + 'px';
		vertical.style.left = x - 1 + 'px';
		middle.style.left = x - 6 + 'px';
		middle.style.top = y - 6 + 'px';
	};*/
	lib.config.mode_config.guozhan.choice_num=12;
	lib.kzol_charactercard_func={};
	var kzol_charactercard=ui.click.charactercard;
	ui.click.charactercard=function(name,sourcenode,noedit,resume,avatar){
		kzol_charactercard(name,sourcenode,noedit,resume,avatar);
		for(var i in lib.kzol_charactercard_func){
			lib.kzol_charactercard_func[i](name,sourcenode,noedit,resume,avatar);
		};
	};
	var kzol_createButton=ui.create.button;
	ui.create.button=function(item,type,position,noclick,node){
		if(lib.character[item]!=undefined&&lib.character[item][2]=='未解锁'){
			noclick=true;
		};
		if(typeof item=='string'&&item.indexOf('kzsg_')!=-1){
			noclick=true;
		};
		var node=kzol_createButton(item,type,position,noclick,node);
		if(typeof item=='string'&&item.indexOf('kzsg_')!=-1){
			node.setBackgroundImage('extension/扩展ol/'+lib.kzol_kzsg_card[item].name+'.jpg','character');
			node.style.backgroundSize="cover";
		};
		if(typeof item=='string'&&item.indexOf('kzsg_')!=-1){
			
			node.node.hp.hide();
			
			node.style.width='90px';
			node.style.height='120px';
			
			node.node.group.style.left='5px';
			node.node.group.style['text-align']='left';
			node.node.name.style.top='25px';
			
			node.node.type=ui.create.div('',node);
			node.node.type.style.height='20px';
			node.node.type.style.width='40px';
			node.node.type.style.top='2px';
			if(lib.kzol_kzsg_card[item].type=='武将'){
				node.node.type.style.left='22.5px';
			}else{
				node.node.type.style.left='25px';
			};
			node.node.type.style['font-size']='16px';
			node.node.type.style['text-align']='center';
			node.node.type.style['font-family']="'STXinwei','xinwei'";
			node.node.type.style['line-height']='20px';
			node.node.type.innerHTML=lib.kzol_kzsg_card[item].type;
			
			node.node.prepareRound=ui.create.div('',node);
			node.node.prepareRound.style.height='30px';
			node.node.prepareRound.style.width='30px';
			node.node.prepareRound.style.top='90px';
			node.node.prepareRound.style.left='0px';
			node.node.prepareRound.style['font-size']='10px';
			node.node.prepareRound.style['text-align']='center';
			node.node.prepareRound.style['font-family']="'STXinwei','xinwei'";
			node.node.prepareRound.style['line-height']='30px';
			node.node.prepareRound.setBackgroundImage('extension/扩展ol/框.png');
			node.node.prepareRound.style.backgroundSize="100% 100%";
			node.node.prepareRound.innerHTML=lib.kzol_kzsg_card[item].prepareRound;
			
			node.node.prepareRound_str=ui.create.div('',node);
			node.node.prepareRound_str.style.height='10px';
			node.node.prepareRound_str.style.width='10px';
			node.node.prepareRound_str.style.top='105px';
			node.node.prepareRound_str.style.left='15px';
			node.node.prepareRound_str.style['font-family']="'STXinwei','xinwei'";
			node.node.prepareRound_str.innerHTML='轮';
			
			node.node.attack=ui.create.div('',node);
			node.node.attack.style.height='30px';
			node.node.attack.style.width='30px';
			node.node.attack.style.top='90px';
			node.node.attack.style.left='30px';
			node.node.attack.style['font-size']='10px';
			node.node.attack.style['text-align']='center';
			node.node.attack.style['font-family']="'STXinwei','xinwei'";
			node.node.attack.style['line-height']='30px';
			node.node.attack.setBackgroundImage('extension/扩展ol/框.png');
			node.node.attack.style.backgroundSize="100% 100%";
			node.node.attack.innerHTML=lib.kzol_kzsg_card[item].attack;
			
			node.node.attack_str=ui.create.div('',node);
			node.node.attack_str.style.height='10px';
			node.node.attack_str.style.width='10px';
			node.node.attack_str.style.top='105px';
			node.node.attack_str.style.left='45px';
			node.node.attack_str.style['font-family']="'STXinwei','xinwei'";
			node.node.attack_str.innerHTML='攻';
			
			if(lib.kzol_kzsg_card[item].type=='武将'){
				node.node.bing=ui.create.div('',node);
				node.node.bing.style.height='30px';
				node.node.bing.style.width='30px';
				node.node.bing.style.top='0px';
				node.node.bing.style.right='0px';
				node.node.bing.style['font-size']='10px';
				node.node.bing.style['text-align']='center';
				node.node.bing.style['font-family']="'STXinwei','xinwei'";
				node.node.bing.style['line-height']='30px';
				node.node.bing.setBackgroundImage('extension/扩展ol/框.png');
				node.node.bing.style.backgroundSize="100% 100%";
				node.node.bing.innerHTML=lib.kzol_kzsg_card[item].bing;
				
				node.node.bing_str=ui.create.div('',node);
				node.node.bing_str.style.height='10px';
				node.node.bing_str.style.width='10px';
				node.node.bing_str.style.top='15px';
				node.node.bing_str.style.right='5px';
				node.node.bing_str.style['font-family']="'STXinwei','xinwei'";
				node.node.bing_str.innerHTML='兵';
				
				node.node.bao=ui.create.div('',node);
				node.node.bao.style.height='30px';
				node.node.bao.style.width='30px';
				node.node.bao.style.top='30px';
				node.node.bao.style.right='0px';
				node.node.bao.style['font-size']='10px';
				node.node.bao.style['text-align']='center';
				node.node.bao.style['font-family']="'STXinwei','xinwei'";
				node.node.bao.style['line-height']='30px';
				node.node.bao.setBackgroundImage('extension/扩展ol/框.png');
				node.node.bao.style.backgroundSize="100% 100%";
				node.node.bao.innerHTML=lib.kzol_kzsg_card[item].bao;
				
				node.node.bao_str=ui.create.div('',node);
				node.node.bao_str.style.height='10px';
				node.node.bao_str.style.width='10px';
				node.node.bao_str.style.top='45px';
				node.node.bao_str.style.right='5px';
				node.node.bao_str.style['font-family']="'STXinwei','xinwei'";
				node.node.bao_str.innerHTML='宝';
				
				node.node.shu=ui.create.div('',node);
				node.node.shu.style.height='30px';
				node.node.shu.style.width='30px';
				node.node.shu.style.top='60px';
				node.node.shu.style.right='0px';
				node.node.shu.style['font-size']='10px';
				node.node.shu.style['text-align']='center';
				node.node.shu.style['font-family']="'STXinwei','xinwei'";
				node.node.shu.style['line-height']='30px';
				node.node.shu.setBackgroundImage('extension/扩展ol/框.png');
				node.node.shu.style.backgroundSize="100% 100%";
				node.node.shu.innerHTML=lib.kzol_kzsg_card[item].shu;
				
				node.node.shu_str=ui.create.div('',node);
				node.node.shu_str.style.height='10px';
				node.node.shu_str.style.width='10px';
				node.node.shu_str.style.top='75px';
				node.node.shu_str.style.right='5px';
				node.node.shu_str.style['font-family']="'STXinwei','xinwei'";
				node.node.shu_str.innerHTML='术';
			};
			
			node.node.hp=ui.create.div('',node);
			node.node.hp.style.height='30px';
			node.node.hp.style.width='30px';
			node.node.hp.style.top='90px';
			node.node.hp.style.right='0px';
			node.node.hp.style['font-size']='10px';
			node.node.hp.style['text-align']='center';
			node.node.hp.style['font-family']="'STXinwei','xinwei'";
			node.node.hp.style['line-height']='30px';
			node.node.hp.setBackgroundImage('extension/扩展ol/框.png');
			node.node.hp.style.backgroundSize="100% 100%";
			node.node.hp.innerHTML=lib.kzol_kzsg_card[item].hp;
			
			node.node.hp_str=ui.create.div('',node);
			node.node.hp_str.style.height='10px';
			node.node.hp_str.style.width='10px';
			node.node.hp_str.style.top='105px';
			node.node.hp_str.style.right='5px';
			node.node.hp_str.style['font-family']="'STXinwei','xinwei'";
			node.node.hp_str.innerHTML='体';
			if(lib.kzol_kzsg_card[item].type=='术'||lib.kzol_kzsg_card[item].type=='宝物'){
				node.node.attack.hide();
				node.node.attack_str.hide();
				node.node.hp.hide();
				node.node.hp_str.hide();
			};
		};
		if(lib.character[item]!=undefined&&lib.character[item][4]!=undefined){
			for(var i=0;i<lib.character[item][4].length;i++){
				if(lib.character[item][4][i].indexOf('职业:')!=-1){
					var occupation=lib.character[item][4][i].slice(3,lib.character[item][4][i].length);
					node.node.occupation=ui.create.div(node);
					node.node.occupation.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+occupation+'.jpg")';
					node.node.occupation.style.height='20px';
					node.node.occupation.style.width='20px';
					node.node.occupation.style.bottom='0px';
					node.node.occupation.style.left='0px';
					node.node.occupation.style.borderRadius='5px';
				};
			};
		};
		var infoitem=lib.character[item];
		if(lib.config.buttoncharacter_style=='default'||lib.config.buttoncharacter_style=='simple'){
			if(typeof item=='string'&&item.indexOf('kzsg_')!=-1){
				if(lib.kzol_kzsg_card!=undefined&&lib.kzol_kzsg_card[item]!=undefined){
					var quailty=lib.kzol_kzsg_card[item].quailty;
					node.node.name.dataset.nature='kzsg'+quailty;
				};
			};
		};
		if(infoitem!=undefined&&infoitem[2]=='未解锁') node.node.hp.innerHTML='<span style="color:red;font-size:18px;font-weight:600;font-family:xinwei">未解锁</span>';
		if(lib.character[item]!=undefined&&lib.character[item][2]=='未解锁'){
			lib.setIntro(node);
			node.addEventListener(lib.config.touchscreen?'touchend':'click',function(){
				game.say1('你未解锁该武将')
			});
		};
		if(typeof item=='string'&&item.indexOf('kzsg_')!=-1){
			lib.setIntro(node);
		};
		return node;
	};
	lib.kzol_nodeintro={};
	var kzol_getNodeIntro=get.nodeintro;
	get.nodeintro=function(node,simple,evt){
		var uiintro=kzol_getNodeIntro(node,simple,evt);
		if(node.classList.contains('character')){
			var character=node.link;
			var infoitem=lib.character[character];
			if(infoitem==undefined){
				for(var j in lib.characterPack){
					for(var i in lib.characterPack[j]){
						if(i==character) infoitem=lib.characterPack[j][i];
					};
				};
			};
			if(infoitem!=undefined){
				var skills=infoitem[3];
				for(var i in lib.kzol_nodeintro){
					lib.kzol_nodeintro[i](uiintro,character,skills);
				};
			};
		};
		return uiintro;
	};
	var kzol_getGroupnature=get.groupnature;
	get.groupnature=function(group,method){
		var nature=kzol_getGroupnature(group,method);
		if(method!='raw') nature=nature.slice(0,nature.length-2);
		if(group=='min') nature='min';
		if(group=='zhi') nature='zhi';
		if(group=='li') nature='li';
		if(group=='shenghen') nature='metal';
		if(group=='nyhzrlong') nature='nyhzrlong';
		if(group=='WSS_jin') nature='WSS_jin';
		if(group=='TLP') nature='TLP';
		if(group=='gu') nature='gu';
		if(group=='r') nature='r';
		if(group=='sr') nature='sr';
		if(group=='ssr') nature='ssr';
		if(group=='meng') nature='meng';
		if(method=='raw') return nature;
		return nature+'mm';
	};
	var swapPlayer=game.swapPlayer;
	game.swapPlayer=function(player,hs){
		if(game.countPlayer(function(current){return current.扩展ol_type=='fellow'})==0){
			swapPlayer(player,hs);
		}else{
			game.log('士兵在场时无法换人');
		};
	};
	game.removePlayer1=function(player){
		if(_status.roundStart==player) _status.roundStart=player.next||player.getNext()||game.players[0];
		player.style.top=player.offsetTop+'px';
		player.style.left=player.offsetLeft+'px';
		if(player==undefined) player=game.dead[0]||game.me.next;
		if(player.isAlive()){
			player.next.previous=player.previous;
			player.previous.next=player.next;
		};
		player.nextSeat.previousSeat=player.previousSeat;
		player.previousSeat.nextSeat=player.nextSeat;
		player.delete();
		game.players.remove(player);
		game.dead.remove(player);
		player.removed=true;
		if(player==game.me){
			ui.me.hide();
			ui.auto.hide();
			ui.wuxie.hide();
		};
		setTimeout(function(){
			player.removeAttribute('style');
		},500);
		game.log(player,'退场了');
		if(game.countPlayer(function(current){return current.扩展ol_type=='fellow'})==0){
			clearInterval(game.shibing_move_interval);
			delete game.shibing_move_interval;
		};
		return player;
	};
	game.reSetSeat=function(){
		var owners=[];
		var fellows=[];
		for(var i=0;i<game.players.length;i++){
			if(game.players[i].扩展ol_owner==undefined){
				owners.push(game.players[i]);
			}else{
				fellows.push(game.players[i]);
			};
		};
		game.players=[];
		for(var i=0;i<owners.length;i++){
			game.players.push(owners[i]);
			for(var j=0;j<fellows.length;j++){
				if(fellows[j].扩展ol_owner==owners[i]) game.players.push(fellows[j]);
			};
		};
		var players=game.players.concat(game.dead);
		for(var i=0;i<players.length;i++){
			if(i==0){
				players[i].previousSeat=players[players.length-1];
			}else{
				players[i].previousSeat=players[i-1];
			};
			if(i==players.length-1){
				players[i].nextSeat=players[0];
			}else{
				players[i].nextSeat=players[i+1];
			};
		};
		for(var i=0;i<game.players.length;i++){
			if(i==0){
				game.players[i].previous=game.players[game.players.length-1];
			}else{
				game.players[i].previous=game.players[i-1];
			}
			if(i==game.players.length-1){
				game.players[i].next=game.players[0];
			}else{
				game.players[i].next=game.players[i+1];
			}
		};
	};
	game.addShibing=function(name,player){
		_status.addingShibing=true;
		var fellow=game.addFellow(1,name);
		delete _status.addingShibing;
		fellow.hide();
		fellow.扩展ol_type='fellow';
		fellow.扩展ol_owner=player;
		fellow.classList.add('minskin');
		fellow.style.width='65px';
		fellow.style.height='65px';
		fellow.node.avatar.style.width='55px';
		fellow.node.avatar.style.height='55px';
		fellow.node.avatar.style.left='5px';
		fellow.node.avatar.style.top='5px';
		fellow.node.identity.style.left='50px';
		fellow.node.name.innerHTML='<span style="font-size:12px;">'+fellow.node.name.innerHTML+'</span>'
		fellow.node.name.style.left='7.5px';
		fellow.node.name.style.top='5px';
		fellow.node.hp.style.width='20px';
		fellow.node.hp.style.left='37.5px';
		fellow.node.hp.style.bottom='5px';
		fellow.node.marks.style.top='30px';
		fellow.node.equips.style.top='60px';
		fellow.node.equips.style.left='0px';
		if(player.side!=undefined) fellow.side=player.side;
		fellow.identity=player.identity;
		if(fellow.identity=='zhu') fellow.identity='zhong';
		fellow.setIdentity('兵');
		fellow.node.identity.dataset.color='cai';
		if(fellow.扩展ol_owner.identity=='zhu'){
			fellow.node.identity.classList.remove('guessing');
			fellow.identityShown=true;
			fellow.node.identity.dataset.color=fellow.identity;
		};
		fellow.ai.shown=1;
		fellow.addSkill('undist');
		game.reSetSeat();
		if(game.shibing_move_interval==undefined){
			game.shibing_move_interval=setInterval(function(){
				for(var i=0;i<game.players.length;i++){
					var pl=game.players[i];
					if(pl.扩展ol_owner!=undefined){
						var owner=pl.扩展ol_owner;
						var left=owner.offsetLeft;
						var top=owner.offsetTop;
						var width=owner.offsetWidth;
						var height=owner.offsetHeight;
						var left1=pl.offsetLeft;
						var top1=pl.offsetTop;
						var pos='middle';
						if(pl.扩展ol_owner==game.me){
							left+=75;
							top-=67.5;
						}else if(left<ui.window.offsetWidth/2&&top>30){
							left+=width;
							pos='left';
						}else if(left>ui.window.offsetWidth/2&top>30){
							left-=67.5;
							pos='right';
						}else{
							top+=height;
						};
						var inc=function(){
							for(var k=0;k<10;k++){
								for(var j=0;j<game.players.length;j++){
									var pl1=game.players[j];
									if(pos=='left'||pos=='right'){
										if(pl1.style.top==top+'px'&&pl1.style.left==left+'px'&&pl1!=pl){
											top+=70;
										};
									}else{
										if(pl1.style.left==left+'px'&&pl1.style.top==top+'px'&&pl1!=pl){
											left+=70;
										};
									};
								};
							};
							sort();
						};
						var sort=function(){
							if(pos=='left'||pos=='right'){
								if(top>owner.offsetTop+owner.offsetHeight){
									top=owner.offsetTop;
									if(owner.offsetLeft<game.players[Math.floor(game.players.length/2)].offsetLeft&&owner.offsetTop>30){
										left+=70;
									}else{
										left-=70;
									};
									inc();
								};
							}else{
								if(pl.扩展ol_owner!=game.me){
									if(left>owner.offsetLeft+owner.offsetWidth){
										left=owner.offsetLeft;
										top+=70;
										inc();
									};
								};
							};
						};
						inc();
						if(pl.style.left!=left+'px') pl.style.left=left+'px';
						if(pl.style.top!=top+'px') pl.style.top=top+'px';
					};
				};
			},500);
		};
		setTimeout(function(){
			fellow.show();
		},750);
		return fellow;
	};
	var style2=document.createElement('style');
	style2.innerHTML="div[data-nature='min'],";
	style2.innerHTML+="span[data-nature='min'] {text-shadow: black 0 0 1px,rgba(50, 240, 0,1) 0 0 2px,rgba(50, 240, 0,1) 0 0 5px,rgba(50, 240, 0,1) 0 0 10px,rgba(50, 240, 0,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='minm'],";
	style2.innerHTML+="span[data-nature='minm'] {text-shadow: black 0 0 1px,rgba(50, 240, 0,1) 0 0 2px,rgba(50, 240, 0,1) 0 0 5px,rgba(50, 240, 0,1) 0 0 5px,rgba(50, 240, 0,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='minmm'],";
	style2.innerHTML+="span[data-nature='minmm'] {text-shadow: black 0 0 1px,rgba(50, 240, 0,1) 0 0 2px,rgba(50, 240, 0,1) 0 0 2px,rgba(50, 240, 0,1) 0 0 2px,rgba(50, 240, 0,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='zhi'],";
	style2.innerHTML+="span[data-nature='zhi'] {text-shadow: black 0 0 1px,rgba(78, 117, 180,1) 0 0 2px,rgba(78, 117, 180,1) 0 0 5px,rgba(78, 117, 180,1) 0 0 10px,rgba(78, 117, 180,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='zhim'],";
	style2.innerHTML+="span[data-nature='zhim'] {text-shadow: black 0 0 1px,rgba(78, 117, 180,1) 0 0 2px,rgba(78, 117, 180,1) 0 0 5px,rgba(78, 117, 180,1) 0 0 5px,rgba(78, 117, 180,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='zhimm'],";
	style2.innerHTML+="span[data-nature='zhimm'] {text-shadow: black 0 0 1px,rgba(78, 117, 180,1) 0 0 2px,rgba(78, 117, 180,1) 0 0 2px,rgba(78, 117, 180,1) 0 0 2px,rgba(78, 117, 180,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='li'],";
	style2.innerHTML+="span[data-nature='li'] {text-shadow: black 0 0 1px,rgba(240, 50, 0,1) 0 0 2px,rgba(240, 50, 0,1) 0 0 5px,rgba(240, 50, 0,1) 0 0 10px,rgba(240, 50, 0,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='lim'],";
	style2.innerHTML+="span[data-nature='lim'] {text-shadow: black 0 0 1px,rgba(240, 50, 0,1) 0 0 2px,rgba(240, 50, 0,1) 0 0 5px,rgba(240, 50, 0,1) 0 0 5px,rgba(240, 50, 0,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='limm'],";
	style2.innerHTML+="span[data-nature='limm'] {text-shadow: black 0 0 1px,rgba(240, 50, 0,1) 0 0 2px,rgba(240, 50, 0,1) 0 0 2px,rgba(240, 50, 0,1) 0 0 2px,rgba(240, 50, 0,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='TLP'],";
	style2.innerHTML+="span[data-nature='TLP'] {text-shadow: black 0 0 1px,rgba(255, 200, 255,1) 0 0 2px,rgba(255, 200, 255,1) 0 0 5px,rgba(255, 200, 255,1) 0 0 10px,rgba(255, 200, 255,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='TLPm'],";
	style2.innerHTML+="span[data-nature='TLPm'] {text-shadow: black 0 0 1px,rgba(255, 200, 255,1) 0 0 2px,rgba(255, 200, 255,1) 0 0 5px,rgba(255, 200, 255,1) 0 0 5px,rgba(255, 200, 255,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='TLPmm'],";
	style2.innerHTML+="span[data-nature='TLPmm'] {text-shadow: black 0 0 1px,rgba(255, 200, 255,1) 0 0 2px,rgba(255, 200, 255,1) 0 0 2px,rgba(255, 200, 255,1) 0 0 2px,rgba(255, 200, 255,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='r'],";
	style2.innerHTML+="span[data-nature='r'] {text-shadow: black 0 0 1px,rgba(120, 255, 255,1) 0 0 2px,rgba(120, 255, 255,1) 0 0 5px,rgba(120, 255, 255,1) 0 0 10px,rgba(120, 255, 255,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='rm'],";
	style2.innerHTML+="span[data-nature='rm'] {text-shadow: black 0 0 1px,rgba(120, 255, 255,1) 0 0 2px,rgba(120, 255, 255,1) 0 0 5px,rgba(120, 255, 255,1) 0 0 5px,rgba(120, 255, 255,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='rmm'],";
	style2.innerHTML+="span[data-nature='rmm'] {text-shadow: black 0 0 1px,rgba(120, 255, 255,1) 0 0 2px,rgba(120, 255, 255,1) 0 0 2px,rgba(120, 255, 255,1) 0 0 2px,rgba(120, 255, 255,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='sr'],";
	style2.innerHTML+="span[data-nature='sr'] {text-shadow: black 0 0 1px,rgba(255, 30, 255,1) 0 0 2px,rgba(255, 30, 255,1) 0 0 5px,rgba(255, 30, 255,1) 0 0 10px,rgba(255, 30, 255,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='srm'],";
	style2.innerHTML+="span[data-nature='srm'] {text-shadow: black 0 0 1px,rgba(255, 30, 255,1) 0 0 2px,rgba(255, 30, 255,1) 0 0 5px,rgba(255, 30, 255,1) 0 0 5px,rgba(255, 30, 255,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='srmm'],";
	style2.innerHTML+="span[data-nature='srmm'] {text-shadow: black 0 0 1px,rgba(255, 30, 255,1) 0 0 2px,rgba(255, 30, 255,1) 0 0 2px,rgba(255, 30, 255,1) 0 0 2px,rgba(255, 30, 255,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='ssr'],";
	style2.innerHTML+="span[data-nature='ssr'] {text-shadow: black 0 0 1px,rgba(255, 255, 100,1) 0 0 2px,rgba(255, 255, 100,1) 0 0 5px,rgba(255, 255, 100,1) 0 0 10px,rgba(255, 255, 100,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='ssrm'],";
	style2.innerHTML+="span[data-nature='ssrm'] {text-shadow: black 0 0 1px,rgba(255, 255, 100,1) 0 0 2px,rgba(255, 255, 100,1) 0 0 5px,rgba(255, 255, 100,1) 0 0 5px,rgba(255, 255, 100,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='ssrmm'],";
	style2.innerHTML+="span[data-nature='ssrmm'] {text-shadow: black 0 0 1px,rgba(255, 255, 100,1) 0 0 2px,rgba(255, 255, 100,1) 0 0 2px,rgba(255, 255, 100,1) 0 0 2px,rgba(255, 255, 100,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='meng'],";
	style2.innerHTML+="span[data-nature='meng'] {text-shadow: black 0 0 1px,rgba(255, 75, 255,1) 0 0 2px,rgba(255, 75, 255,1) 0 0 5px,rgba(255, 75, 255,1) 0 0 10px,rgba(255, 75, 255,1) 0 0 10px}";
	style2.innerHTML+="div[data-nature='mengm'],";
	style2.innerHTML+="span[data-nature='mengm'] {text-shadow: black 0 0 1px,rgba(255, 75, 255,1) 0 0 2px,rgba(255, 75, 255,1) 0 0 5px,rgba(255, 75, 255,1) 0 0 5px,rgba(255, 75, 255,1) 0 0 5px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='mengmm'],";
	style2.innerHTML+="span[data-nature='mengmm'] {text-shadow: black 0 0 1px,rgba(255, 75, 255,1) 0 0 2px,rgba(255, 75, 255,1) 0 0 2px,rgba(255, 75, 255,1) 0 0 2px,rgba(255, 75, 255,1) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg1'],";
	style2.innerHTML+="span[data-nature='kzsg1'] {text-shadow: black 0 0 1px,rgba(204, 204, 204,255) 0 0 2px,rgba(204, 204, 204,255) 0 0 2px,rgba(204, 204, 204,255) 0 0 2px,rgba(204, 204, 204,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg2'],";
	style2.innerHTML+="span[data-nature='kzsg2'] {text-shadow: black 0 0 1px,rgba(255,255,255,255) 0 0 2px,rgba(255,255,255,255) 0 0 2px,rgba(255,255,255,255) 0 0 2px,rgba(255,255,255,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg3'],";
	style2.innerHTML+="span[data-nature='kzsg3'] {text-shadow: black 0 0 1px,rgba(51,255,0,255) 0 0 2px,rgba(51,255,0,255) 0 0 2px,rgba(51,255,0,255) 0 0 2px,rgba(51,255,0,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg4'],";
	style2.innerHTML+="span[data-nature='kzsg4'] {text-shadow: black 0 0 1px,rgba(0,0,255,255) 0 0 2px,rgba(0,0,255,255) 0 0 2px,rgba(0,0,255,255) 0 0 2px,rgba(0,0,255,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg5'],";
	style2.innerHTML+="span[data-nature='kzsg5'] {text-shadow: black 0 0 1px,rgba(204,0,255,255) 0 0 2px,rgba(204,0,255,255) 0 0 2px,rgba(204,0,255,255) 0 0 2px,rgba(204,0,255,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg6'],";
	style2.innerHTML+="span[data-nature='kzsg6'] {text-shadow: black 0 0 1px,rgba(238,118,33,255) 0 0 2px,rgba(238,118,33,255) 0 0 2px,rgba(238,118,33,255) 0 0 2px,rgba(238,118,33,255) 0 0 2px,black 0 0 1px;}";
	style2.innerHTML+="div[data-nature='kzsg7'],";
	style2.innerHTML+="span[data-nature='kzsg7'] {text-shadow: black 0 0 1px,rgba(255,0,0,255) 0 0 2px,rgba(255,0,0,255) 0 0 2px,rgba(255,0,0,255) 0 0 2px,rgba(255,0,0,255) 0 0 2px,black 0 0 1px;}";
	document.head.appendChild(style2);
	if(lib.config.layout=='default'||lib.config.layout=='mobile'||lib.config.layout=='long'){
		var style=document.createElement('style');
		style.innerHTML="#arena:not(.chess) .player[data-position='0']>.equips>.equip1{top: 16px;left: 3px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip2{top: 16px;left: 42px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip3{top: 68px;left: 3px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip4{top: 68px;left: 42px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip5{top: 42px;left: 22.5px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip6{top: 3px;left: 81px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip7{top: 42px;left: 81px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>.equip8{top: 81px;left: 81px}";
		style.innerHTML+="#arena:not(.chess) .player[data-position='0']>.equips>div:not(.equip9){width: 36px;height: 36px;margin: 0;border-radius: 4px;position: absolute;}";
		document.head.appendChild(style);
	};
	var style1=document.createElement('style');
	style1.innerHTML="[data-number='9']>.player[data-position='1']{top:calc(200% / 3 - 145px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='2']{top:calc(100% / 3 - 120px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='3']{top:30px;left:calc(80% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='4']{top:5px;left:calc(60% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='5']{top:5px;left:calc(40% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='6']{top:30px;left:calc(20% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='7']{top:calc(100% / 3 - 120px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='9']>.player[data-position='8']{top:calc(200% / 3 - 145px);left:calc(5% - 75px);}";
	
	style1.innerHTML+="[data-number='10']>.player[data-position='1']{top:calc(200% / 3 - 145px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='2']{top:calc(100% / 3 - 120px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='3']{top:30px;left:calc(80% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='4']{top:5px;left:calc(65% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='5']{top:0px;left:calc(50% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='6']{top:5px;left:calc(35% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='7']{top:30px;left:calc(20% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='8']{top:calc(100% / 3 - 120px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='10']>.player[data-position='9']{top:calc(200% / 3 - 145px);left:calc(5% - 75px);}";
	
	style1.innerHTML+="[data-number='11']>.player[data-position='1']{top:calc(200% / 3 - 100px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='2']{top:calc(100% / 3 - 50px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='3']{top:5px;left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='4']{top:0px;left:calc(77% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='5']{top:0px;left:calc(59% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='6']{top:0px;left:calc(41% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='7']{top:0px;left:calc(23% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='8']{top:5px;left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='9']{top:calc(100% / 3 - 50px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='11']>.player[data-position='10']{top:calc(200% / 3 - 100px);left:calc(5% - 75px);}";
	
	style1.innerHTML+="[data-number='12']>.player[data-position='1']{top:calc(200% / 3 - 87.5px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='2']{top:calc(100% / 3 - 25px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='3']{top:37.5px;left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='4']{top:0px;left:calc(80% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='5']{top:0px;left:calc(65% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='6']{top:0px;left:calc(50% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='7']{top:0px;left:calc(35% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='8']{top:0px;left:calc(20% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='9']{top:37.5px;left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='10']{top:calc(100% / 3 - 25px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='12']>.player[data-position='11']{top:calc(200% / 3 - 87.5px);left:calc(5% - 75px);}";
	
	style1.innerHTML+="[data-number='13']>.player[data-position='1']{top:calc(200% / 3 - 87.5px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='2']{top:calc(100% / 3 - 25px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='3']{top:37.5px;left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='4']{top:0px;left:calc(83% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='5']{top:0px;left:calc(69.8% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='6']{top:0px;left:calc(56.6% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='7']{top:0px;left:calc(43.4% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='8']{top:0px;left:calc(30.2% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='9']{top:0px;left:calc(17% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='10']{top:37.5px;left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='11']{top:calc(100% / 3 - 25px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='13']>.player[data-position='12']{top:calc(200% / 3 - 87.5px);left:calc(5% - 75px);}";
	
	if(!lib.device){
		style1.innerHTML+="[data-number='14']>.player[data-position='1']{top:calc(100% / 3 + 190px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='2']{top:calc(100% / 3 + 60px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='3']{top:calc(100% / 3 - 70px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='4']{top:calc(100% / 3 - 200px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='5']{top:30px;left:calc(80% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='6']{top:10px;left:calc(65% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='7']{top:0px;left:calc(50% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='8']{top:10px;left:calc(35% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='9']{top:30px;left:calc(20% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='10']{top:calc(100% / 3 - 200px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='11']{top:calc(100% / 3 - 70px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='12']{top:calc(100% / 3 + 60px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='13']{top:calc(100% / 3 + 190px);left:calc(5% - 75px);}";
	}else{
		style1.innerHTML+="[data-number='14']>.player[data-position='1']{top:calc(100% / 3 + 130px);left:calc(80% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='2']{top:calc(100% / 3 + 110px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='3']{top:calc(100% / 3 - 35px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='4']{top:calc(100% / 3 - 180px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='5']{top:30px;left:calc(80% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='6']{top:10px;left:calc(65% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='7']{top:0px;left:calc(50% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='8']{top:10px;left:calc(35% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='9']{top:30px;left:calc(20% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='10']{top:calc(100% / 3 - 180px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='11']{top:calc(100% / 3 - 35px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='12']{top:calc(100% / 3 + 110px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='14']>.player[data-position='13']{top:calc(100% / 3 + 130px);left:calc(20% - 75px);}";
	};
	
	if(!lib.device){
		style1.innerHTML+="[data-number='15']>.player[data-position='1']{top:calc(100% / 3 + 190px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='2']{top:calc(100% / 3 + 60px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='3']{top:calc(100% / 3 - 70px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='4']{top:calc(100% / 3 - 200px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='5']{top:30px;left:calc(82.1% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='6']{top:10px;left:calc(69.25% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='7']{top:0px;left:calc(56.4% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='8']{top:0px;left:calc(43.55% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='9']{top:10px;left:calc(30.7% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='10']{top:30px;left:calc(17.85% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='11']{top:calc(100% / 3 - 200px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='12']{top:calc(100% / 3 - 70px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='13']{top:calc(100% / 3 + 60px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='14']{top:calc(100% / 3 + 190px);left:calc(5% - 75px);}";
	}else{
		style1.innerHTML+="[data-number='15']>.player[data-position='1']{top:calc(100% / 3 + 130px);left:calc(82.1% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='2']{top:calc(100% / 3 + 110px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='3']{top:calc(100% / 3 - 35px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='4']{top:calc(100% / 3 - 180px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='5']{top:30px;left:calc(82.1% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='6']{top:10px;left:calc(69.25% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='7']{top:0px;left:calc(56.4% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='8']{top:0px;left:calc(43.55% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='9']{top:10px;left:calc(30.7% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='10']{top:30px;left:calc(17.85% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='11']{top:calc(100% / 3 - 180px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='12']{top:calc(100% / 3 - 35px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='13']{top:calc(100% / 3 + 110px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='15']>.player[data-position='14']{top:calc(100% / 3 + 130px);left:calc(17.85% - 75px);}";
	};
	
	if(!lib.device){
		style1.innerHTML+="[data-number='16']>.player[data-position='1']{top:calc(100% / 3 + 190px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='2']{top:calc(100% / 3 + 60px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='3']{top:calc(100% / 3 - 70px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='4']{top:calc(100% / 3 - 200px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='5']{top:30px;left:calc(83.75% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='6']{top:20px;left:calc(72.5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='7']{top:10px;left:calc(61.25% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='8']{top:0px;left:calc(50% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='9']{top:10px;left:calc(38.75% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='10']{top:20px;left:calc(27.5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='11']{top:30px;left:calc(16.25% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='12']{top:calc(100% / 3 - 200px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='13']{top:calc(100% / 3 - 70px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='14']{top:calc(100% / 3 + 60px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='15']{top:calc(100% / 3 + 190px);left:calc(5% - 75px);}";
	}else{
		style1.innerHTML+="[data-number='16']>.player[data-position='1']{top:calc(100% / 3 + 130px);left:calc(83.75% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='2']{top:calc(100% / 3 + 110px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='3']{top:calc(100% / 3 - 35px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='4']{top:calc(100% / 3 - 180px);left:calc(95% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='5']{top:30px;left:calc(83.75% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='6']{top:20px;left:calc(72.5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='7']{top:10px;left:calc(61.25% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='8']{top:0px;left:calc(50% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='9']{top:10px;left:calc(38.75% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='10']{top:20px;left:calc(27.5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='11']{top:30px;left:calc(16.25% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='12']{top:calc(100% / 3 - 180px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='13']{top:calc(100% / 3 - 35px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='14']{top:calc(100% / 3 + 110px);left:calc(5% - 75px);}";
		style1.innerHTML+="[data-number='16']>.player[data-position='15']{top:calc(100% / 3 + 130px);left:calc(16.25% - 75px);}";
	};
	
	style1.innerHTML+="[data-number='17']>.player[data-position='1']{top:calc(100% / 3 + 160px);left:calc(50% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='2']{top:calc(100% / 3 + 160px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='3']{top:calc(100% / 3 + 30px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='4']{top:calc(100% / 3 - 100px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='5']{top:calc(100% / 3 - 230px);left:calc(95% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='6']{top:30px;left:calc(83.75% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='7']{top:20px;left:calc(72.5% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='8']{top:5px;left:calc(61.25% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='9']{top:0;left:calc(50% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='10']{top:5px;left:calc(38.75% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='11']{top:20px;left:calc(27.5% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='12']{top:30px;left:calc(16.25% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='13']{top:calc(100% / 3 - 230px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='14']{top:calc(100% / 3 - 100px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='15']{top:calc(100% / 3 + 30px);left:calc(5% - 75px);}";
	style1.innerHTML+="[data-number='17']>.player[data-position='16']{top:calc(100% / 3 + 160px);left:calc(5% - 75px);}";
	document.head.appendChild(style1);
/*Window.alert = function(){
　　//创建一个大盒子
    var box = document.createElement("div");
　　//创建一个关闭按钮
    var button = document.createElement("button");
　　//定义一个对象保存样式
    var boxName = {
        width:"500px",
        height:"180px",
        backgroundColor:"#f8f8f8",
        border:"1px solid #ccc",
        position:"absolute",
        top:"50%",
        left:"50%",
        margin:"-90px 0 0 -250px",
        zIndex:"999",
        textAlign:"center",
        lineHeight:"180px"
    }
　　//给元素添加元素
    for(var k in boxName){
        box.style[k] = boxName[k];
    }
　　//把创建的元素添加到body中
    document.body.appendChild(box);
　　//把alert传入的内容添加到box中
    if(arguments[0]){
        box.innerHTML = arguments[0];
    }
    button.innerHTML = "关闭";
 　　//定义按钮样式
    var btnName = {
        border:"1px solid #ccc",
        backgroundColor:"#fff",
        width:"70px",
        height:"30px",
        textAlign:"center",
        lineHeight:"30px",
        outline:"none",
        position:"absolute",
        bottom:"10px",
        right:"20px",
    }
    for(var j in btnName){
        button.style[j] = btnName[j];
    }
　　//把按钮添加到box中
    box.appendChild(button);
　　//给按钮添加单击事件
    button.addEventListener("click",function(){
        box.style.display = "none";
    })
}*/
	lib.translate.equip6='圣痕-上';
	lib.translate.equip7='圣痕-中';
	lib.translate.equip8='圣痕-下';
	lib.translate.unknown8='九号位';
	lib.translate.unknown9='十号位';
	lib.translate.unknown10='十一号位';
	lib.translate.unknown11='十二号位';
	lib.translate.unknown12='十三号位';
	lib.translate.unknown13='十四号位';
	lib.translate.unknown14='十五号位';
	lib.translate.unknown15='十六号位';
	lib.mode.identity.config.player_number.item={
		'2':'两人',
		'3':'三人',
		'4':'四人',
		'5':'五人',
		'6':'六人',
		'7':'七人',
		'8':'八人',
		'9':'九人',
		'10':'十人',
		'11':'十一人',
		'12':'十二人',
		'13':'十三人',
		'14':'十四人',
		'15':'十五人',
		'16':'十六人',
	}
	lib.mode.guozhan.config.player_number.item={
		'2':'两人',
		'3':'三人',
		'4':'四人',
		'5':'五人',
		'6':'六人',
		'7':'七人',
		'8':'八人',
		'9':'九人',
		'10':'十人',
		'11':'十一人',
		'12':'十二人',
		'13':'十三人',
		'14':'十四人',
		'15':'十五人',
		'16':'十六人',
	};
	var identity=['zhu','zhong','zhong','zhong','nei','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_9r']=='2') identity=['zhu','zhong','zhong','nei','nei','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_9r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_9r']=='4') identity=['zhu','zhong','zhong','zhong','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[7]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_10r']=='2') identity=['zhu','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_10r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[8]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_11r']=='2') identity=['zhu','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_11r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_11r']=='4') identity=['zhu','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[9]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_12r']=='2') identity=['zhu','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_12r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[10]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_13r']=='2') identity=['zhu','zhong','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_13r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_13r']=='4') identity=['zhu','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[11]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_14r']=='2') identity=['zhu','zhong','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_14r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[12]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_15r']=='2') identity=['zhu','zhong','zhong','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_15r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_15r']=='4') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[13]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','nei','nei','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_16r']=='2') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','nei','fan','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config['extension_扩展ol_16r']=='3') identity=['zhu','zhong','zhong','zhong','zhong','zhong','zhong','zhong','fan','fan','fan','fan','fan','fan','fan','fan'];
	if(lib.config.mode_config.identity.identity[14]==undefined&&get.mode() != 'connect') lib.config.mode_config.identity.identity.push(identity);
	/*lib.skill._shenghen_image={
		trigger:{
			player:'gainBefore'
		},
		filter:function(event,player){
			for(var i=0;i<event.cards.length;i++){
				var card=event.cards[i];
				if(lib.card[card.name].shenghen_Image==true) return true;
			};
			return false;
		},
		forced:true,
		popup:false,
		content:function(){
			for(var i=0;i<trigger.cards.length;i++){
				var card=trigger.cards[i];
				if(lib.card[card.name].shenghen_Image==true){
					card.node.name.innerHTML='<img src="'+lib.assetURL+'extension/扩展ol/'+card.name+'_shenghen_Image.png" width="20" height="20">';
				};
			};
		},
	};*/
	lib.skill["_useCardLimit"]={
		mod:{
			targetEnabled:function(card,player,target){
				if(game.players.length+game.dead.length-game.countPlayer(function(current){return current.扩展ol_type=='fellow'})>10&&get.distance(player,target)>4) return false;
			},
		},
	};
	lib.skill["_minskinSJ"]={
		mode:['identity','guozhan','partner'],
		trigger:{
			global:["gameStart","useCardBefore","phaseBefore","loseEnd","phaseBegin","phaseDradBegin","phaseUseBegin","phaseUseEnd","phaseEnd","phaseDiscardBegin","useSkillBefore","judgeAfter"],
			//player:'dieBefore',
		},
		filter:function (event,player){
			return game.players.length+game.dead.length-game.countPlayer(function(current){return current.扩展ol_type=='fellow'})>=12||player.扩展ol_type=='fellow';
		},
		forced:true,
		popup:false,
		content:function (){
			game.broadcastAll(function(player){
				if(player!=game.me){
					player.classList.add('minskin');
					if(player.name2!=undefined){
						player.node.avatar2.hide();
						if(player.扩展ol_type=='fellow') player.node.name2.hide();
						if(!player.isUnseen(1)&&player.storage.STAVA2!=0){
							player.storage.STAVA2=0;
							player.setNickname=function(){};
							var avatar2=ui.create.div(function(){if(player.name2) ui.click.charactercard(player.name2,'')});
							avatar2.style.borderRadius='40px';
							avatar2.style.boxShadow='rgba(0, 0, 0, 0.2) 0 0 0 1px';
							if(player.扩展ol_type=='fellow'){
								avatar2.style.top='-25px';
								avatar2.style.left='-20px';
								avatar2.style.height='30px';
								avatar2.style.width='30px';
							}else{
								avatar2.style.height='40px';
								avatar2.style.width='40px';
								avatar2.style.top='77px';
								avatar2.style.left='-10px';
							};
							avatar2.setBackground(player.name2,'character');
							player.node.nameol.appendChild(avatar2);
							player.avatar2_name=player.name2;
							setInterval(function(){
								if(player.avatar2_name!=player.name2){
									avatar2.setBackground(player.name2,'character');
									player.avatar2_name=player.name2;
								};
							},1000);
						};
					};
				}else{
					if(player.isMin()) player.classList.remove('minskin');
				};
			},player);
		},
	};
	lib.skill["_ismin"]={};
	lib.skill["_minskinEquip1"]={
		mode:['identity','guozhan','partner'],
		trigger:{
			player:"equipBefore",
		},
		filter:function (event,player){
			return (game.players.length+game.dead.length-game.countPlayer(function(current){return current.扩展ol_type=='fellow'})>=12||player.扩展ol_type=='fellow')&&player!=game.me;
		},
		forced:true,
		popup:false,
		content:function (){
			game.broadcastAll(function(player){
				player.classList.remove('minskin');
			},player);
		},
	};
	lib.skill["_minskinEquip2"]={
		mode:['identity','guozhan','partner'],
		trigger:{
			player:"equipAfter",
		},
		filter:function (event,player){
			return (game.players.length+game.dead.length-game.countPlayer(function(current){return current.扩展ol_type=='fellow'})>=12||player.扩展ol_type=='fellow')&&player!=game.me;
		},
		forced:true,
		popup:false,
		content:function (){
			game.broadcastAll(function(player){
				player.classList.add('minskin');
			},player);
		},
	};
	lib.skill._countHasUsedCard={
		trigger:{
			player:"useCardAfter",
		},
		filter:function (event,player){
			return _status.currentPhase==player&&event.card!=undefined;
		},
		forced:true,
		popup:false,
		content:function (){
			if(player.storage.countHasUsedCard==undefined) player.storage.countHasUsedCard=[];
			player.storage.countHasUsedCard.push(trigger.card);
		},
	};
	lib.skill._countHasUsedCard1={
		trigger:{
			player:"phaseAfter",
		},
		filter:function (event,player){
			return player.storage.countHasUsedCard!=undefined;
		},
		priority:Infinity,
		forced:true,
		popup:false,
		content:function (){
			delete player.storage.countHasUsedCard;
		},
	};
	lib.element.player.$equip=function(card){
		if(this.storage.lose_pos_equip!=undefined&&this.storage.lose_pos_equip.contains(get.subtype(card))){
			this.gain(card,'gain2');
			game.log(this,'装备失败');
		}else{
			game.broadcast(function(player,card){
				player.$equip(card);
			},this,card);
			card.fix();
			card.style.transform='';
			card.classList.remove('drawinghidden');
			delete card._transform;
			var player=this;
			var equipNum=get.equipNum(card);
			var equipped=false;
			for(var i=0;i<player.node.equips.childNodes.length;i++){
				if(get.equipNum(player.node.equips.childNodes[i])>=equipNum){
					player.node.equips.insertBefore(card,player.node.equips.childNodes[i]);
					equipped=true;
					break;
				}
			}
			if(!equipped){
				player.node.equips.appendChild(card);
				if(_status.discarded){
					_status.discarded.remove(card);
				}
			}
			var info=get.info(card);
			if(info.skills){
				for(var i=0;i<info.skills.length;i++){
					player.addSkillTrigger(info.skills[i]);
				}
			}
			return player;
		};
	};
	lib.extensionMenu.extension_扩展ol['16r_title']={
		"name":"<b><p align=center><span style=\"font-size:18px\">-----多人身份-----</span></b>",
		"clear":true,
		"nopointer":true,
	};
	lib.extensionMenu.extension_扩展ol['9r']={"name":'九人场身份',"init":'1',"item":{'1':'三忠四反一内','2':'二忠四反二内','3':'四忠四反零内','4':'三忠五反零内'}};
	lib.extensionMenu.extension_扩展ol['10r']={"name":'十人场身份',"init":'1',"item":{'1':'三忠四反二内','2':'三忠五反一内','3':'四忠五反零内'}};
	lib.extensionMenu.extension_扩展ol['11r']={"name":'十一人场身份',"init":'1',"item":{'1':'四忠五反一内','2':'三忠五反二内','3':'五忠五反零内','4':'四忠六反零内'}};
	lib.extensionMenu.extension_扩展ol['12r']={"name":'十二人场身份',"init":'1',"item":{'1':'四忠五反二内','2':'四忠六反一内','3':'五忠六反零内'}};
	lib.extensionMenu.extension_扩展ol['13r']={"name":'十三人场身份',"init":'1',"item":{'1':'五忠六反一内','2':'四忠六反二内','3':'六忠六反零内','4':'五忠七反零内'}};
	lib.extensionMenu.extension_扩展ol['14r']={"name":'十四人场身份',"init":'1',"item":{'1':'五忠六反二内','2':'五忠七反一内','3':'六忠七反零内'}};
	lib.extensionMenu.extension_扩展ol['15r']={"name":'十五人场身份',"init":'1',"item":{'1':'六忠七反一内','2':'五忠七反二内','3':'七忠七反零内','4':'六忠八反零内'}};
	lib.extensionMenu.extension_扩展ol['16r']={"name":'十六人场身份',"init":'1',"item":{'1':'六忠七反二内','2':'六忠八反一内','3':'七忠八反零内'}};
	lib.skill._shibing_die={
		trigger:{
			player:"dieBefore",
		},
		forced:true,
		popup:false,
		priority:Infinity,
		content:function (){
			if(player.扩展ol_type=='fellow'){
				game.removePlayer1(player);
			}else{
				var list=[];
				for(var i=0;i<game.players.length;i++){
					if(game.players[i].扩展ol_owner==player) list.push(game.players[i]);
				};
				for(var i=0;i<list.length;i++){
					game.removePlayer1(list[i]);
				};
			};
		},
	};
	lib.help['16人模式']="当游戏人数超过10时，使用的牌不能指定距离大于4的角色为目标";
}