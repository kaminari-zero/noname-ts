window.func=function(lib,game,ui,get,ai,_status){
	lib.kzol_bw_skill={};
	if(lib.config.kzol_bag_num==undefined) game.saveConfig('kzol_bag_num',0);
	if(lib.kzol_bag==undefined) lib.kzol_bag={};
	if(lib.config.kzol_bag==undefined) lib.config.kzol_bag={};
	game.saveConfig('kzol_bag',lib.config.kzol_bag);
	var bag={
		'baozhu':{
			name:'baozhu',
			info:'装备后，你的首个回合开始时，随机获得一项增益效果',
			type:'baowu',
			canLay:false,
		},
		'qianmian':{
			name:'qianmian',
			info:'装备后，你可以在合适的时机发动其他角色限制回合内使用次数的技能，每局使用三次后失去身上所有宝物效果',
			type:'baowu',
			canLay:false,
		},
		'xukongdajian':{
			name:'xukongdajian',
			info:'装备后，你造成伤害时不会触发技能',
			type:'baowu',
			canLay:false,
			noBorder:true,
		},
	};
	for(var i in lib.characterPack){
		for(var j in lib.characterPack[i]){
			var character=lib.characterPack[i][j];
			if(character!=undefined){
				var bw_name='kzol_bw_lhs_'+j;
				var info='装备后，游戏开始时，你召唤'+get.translation(j)+'为你作战三个回合';
				bag[bw_name]={
					name:bw_name,
					character:j,
					info:info,
					type:'baowu',
					canLay:false,
				};
				lib.translate[bw_name]='灵魂碎片：'+get.translation(j);
				lib.skill['kzol_bw_'+bw_name]={
					nobracket:true,
					intro:{
						content:info.slice(4,info.length),
					},
					mark:true,
					trigger:{
						global:'gameStart',
					},
					forced:true,
					content:function(){
						if(player==game.me){
							var fellow=game.addShibing(lib.config.kzol_bw[player.name].character,player);
						}else{
							var fellow=game.addShibing(lib.kzol_bag[player.storage.kzol_bw].character,player);
						};
						fellow.setIdentity('灵');
						fellow.node.identity.dataset.color='cai';
						fellow.storage.kzol_lhs=true;
					},
				};
				lib.translate['kzol_bw_'+bw_name]='灵魂碎片：'+get.translation(j);
				lib.translate['kzol_bw_'+bw_name+'_info']=info.slice(4,info.length);
			};
		};
	};
	lib.skill._kzol_bw_die={
		trigger:{
			player:'phaseAfter',
		},
		forced:true,
		popup:false,
		filter:function(event,player){
			return player.storage.kzol_lhs!=undefined;
		},
		content:function(){
			if(player.storage.kzol_lhs1==undefined) player.storage.kzol_lhs1=0;
			player.storage.kzol_lhs1++;
			if(player.storage.kzol_lhs1==3) player.die();
		},
	};
	for(var i in bag){
		var item=bag[i];
		lib.kzol_bag[i]=item;
	};
	lib.kzol_charactercard_func['createBwEquip']=function(name,sourcenode,noedit,resume,avatar){
		var bool=false;
		for(var j in lib.characterPack){
			for(var i in lib.characterPack[j]){
				if(i==name&&(lib.characterPack[j][i][4]==undefined||!lib.characterPack[j][i][4].contains('forbidai'))) bool=true;
			};
		};
		if(bool==false) return ;
		var div1=ui.create.div('.dialog');
		div1.style.height='50px';
		div1.style.width='50px';
		div1.style.left='calc(50% - 115px)';
		div1.style.top='calc(50% + 45px)';
		div1.style['z-index']=99999;
		var item=lib.config.kzol_bw[name];
		if(item!=undefined){
			if(item.noBorder==true){
				div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+item.name+'.png'+'")';
			}else if(item.character){
				div1.setBackground(item.character,'character');
				if(item.noBorder!=true){
					var str=div1.style.backgroundImage;
					str='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+str;
					div1.style.backgroundImage=str;
				};
			}else{
				div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+'url("'+lib.assetURL+'extension/扩展ol/'+item.name+'.png'+'")';
			};
		}else{
			div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png")';
		};
		div1.style.backgroundSize="cover";
		var onOpen=false;
		div1.onclick=function(){
			if(onOpen==false){
				var dialog=ui.create.dialog('hidden');
				dialog.classList.add('popped');
				dialog.classList.add('static');
				dialog.style.height='150px';
				dialog.style.width='300px';
				dialog.style['z-index']=99999;
				dialog.addText('<span style="font-family:xinwei"><span style="font-size:30px;font-weight:600">宝物</span>');
				for(var i in lib.config.kzol_bag){
					var item=lib.config.kzol_bag[i];
					if(item.type=='baowu'){
						var div=ui.create.div('.card.fullskin');
						div.style.height='50px';
						div.style.width='50px';
						div.style.top='-10px';
						div.style.borderRadius='5px';
						if(item.noBorder==true){
							div.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+item.name+'.png'+'")';
						}else if(item.character){
							div.setBackground(item.character,'character');
							if(item.noBorder!=true){
								var str=div.style.backgroundImage;
								str='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+str;
								div.style.backgroundImage=str;
							};
						}else{
							div.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+'url("'+lib.assetURL+'extension/扩展ol/'+item.name+'.png'+'")';
						};
						div.style.backgroundSize="cover";
						div.link=i;
						div.onclick=function(){
							var str1='';
							var item=lib.config.kzol_bag[this.link];
							if(item.ext_info==undefined){
								str1=lib.kzol_bag[item.name].info;
							}else{
								str1=item.ext_info;
							};
							var str='是否让'+get.translation(name)+'装备'+get.translation(item.ext_name)+'？（'+str1+'）';
							if(confirm(str)){
								game.kzol_equipBaowu(this.link,name);
								onOpen.hide();
								onOpen=false;
							};
						};
						dialog.add(div);
					};
				};
				var loadDown=ui.create.div('.menubutton.large','<span style="cursor:pointer;">卸下</span>',function(){
					if(lib.config.kzol_bw[name]==undefined){
						onOpen.hide();
						onOpen=false;
						game.say1('当前没有装备宝物');
						return ;
					};
					lib.config.kzol_bag[lib.config.kzol_bag_num]=lib.config.kzol_bw[name];
					game.saveConfig('kzol_bag_num',lib.config.kzol_bag_num+1);
					game.saveConfig('kzol_bag',lib.config.kzol_bag);
					delete lib.config.kzol_bw[name];
					game.saveConfig('kzol_bw',lib.config.kzol_bw);
					game.say1('成功卸下');
					onOpen.hide();
					onOpen=false;
				});
				loadDown.style.height='30px';
				loadDown.style.width='270px';
				loadDown.style.borderRadius='8px';
				loadDown.style.backgroundColor="#E00000";
				dialog.add(loadDown);
				ui.window.appendChild(dialog);
				dialog.setBackgroundImage('extension/扩展ol/Background3.jpg');
				dialog.style.backgroundSize="cover";
				dialog.hide();
				dialog.style.left=event.clientX+10+document.body.scrollLeft+'px';
				dialog.style.top=event.clientY+document.body.scrollTop+'px';
				dialog.show();
				onOpen=dialog;
			}else{
				onOpen.hide();
				onOpen=false;
			};
		};
		ui.window.appendChild(div1);
		div1.hide();
		setTimeout(function(){
			div1.show();
		},150);
		var interval=setInterval(function(){
			if(lib.config.kzol_bw[name]!=undefined){
				if(lib.config.kzol_bw[name].noBorder==true){
					div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+lib.config.kzol_bw[name].name+'.png'+'")';
				}else if(lib.config.kzol_bw[name].character){
					div1.setBackground(lib.config.kzol_bw[name].character,'character');
					if(lib.config.kzol_bw[name].noBorder!=true){
						var str=div1.style.backgroundImage;
						str='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+str;
						div1.style.backgroundImage=str;
					};
				}else{
					div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+'url("'+lib.assetURL+'extension/扩展ol/'+lib.config.kzol_bw[name].name+'.png'+'")';
				};
			}else{
				//div1.innerHTML='<b><p align=center>+</b>';
				div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png")';
			};
			if(_status.openingSkillSkin==true){
				div1.hide();
			}else{
				div1.show();
			};
			if((lib.config.theme=='simple'&&!ui.window.classList.contains('systempaused'))||(lib.config.theme!='simple'&&!ui.window.classList.contains('shortcutpaused'))){
				if(onOpen!=false) onOpen.delete();
				div1.delete();
				clearInterval(interval);
			};
		},100);
	};
	if(lib.config.kzol_bw==undefined) game.saveConfig('kzol_bw',{});
	lib.extensionMenu.extension_扩展ol['bw']={
		"name":"<b><p align=center><span style=\"font-size:18px\">------宝物------</span></b>",
		"clear":true,
		"nopointer":true,
	};
	lib.extensionMenu.extension_扩展ol['bw_show']={
		"name":"显示装备中的宝物",
		"init":false,
		"intro":"开启后在武将简介页显示该武将装备中的宝物"
    };
	lib.extensionMenu.extension_扩展ol['bw_aiCanUse']={
		"name":"电脑也能使用宝物",
		"init":false,
		"intro":"开启后电脑在开局时随机获得宝物",
    };
	lib.extensionMenu.extension_扩展ol['bw_forbidden']={
		"name":"禁用宝物",
		"init":false,
		"intro":"开启后开局时无法获得宝物技能"
    };
	lib.kzol_nodeintro['bw']=function(uiintro,character,skills){
		var bool=false;
		for(var j in lib.characterPack){
			for(var i in lib.characterPack[j]){
				if(i==character&&(lib.characterPack[j][i][4]==undefined||!lib.characterPack[j][i][4].contains('forbidai'))) bool=true;
			};
		};
		if(bool==false) return ;
		if(lib.config['extension_扩展ol_bw_show']==false) return ;
		uiintro.add('<div><div class="text">当前装备的宝物：</div></div>');
		var div1=ui.create.div('.shadowed.reduce_radius');
		div1.style.height='50px';
		div1.style.width='50px';
		div1.style.top='-15px';
		if(lib.config.kzol_bw[character]!=undefined){
			if(lib.config.kzol_bw[character].noBorder==true){
				div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/'+lib.config.kzol_bw[character].name+'.png'+'")';
			}else if(lib.config.kzol_bw[character].character){
				div1.setBackground(lib.config.kzol_bw[character].character,'character');
				if(lib.config.kzol_bw[character].noBorder!=true){
					var str=div1.style.backgroundImage;
					str='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+str;
					div1.style.backgroundImage=str;
				};
			}else{
				div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png"),'+'url("'+lib.assetURL+'extension/扩展ol/'+lib.config.kzol_bw[character].name+'.png'+'")';
			};
		}else{
			div1.innerHTML='<b><p align=center>无</b>';
			div1.style.backgroundImage='url("'+lib.assetURL+'extension/扩展ol/item.png")';
		};
		div1.style.backgroundSize="cover";
		uiintro.add(div1);
	};
	game.kzol_equipBaowu=function(item_num,character){
		if(lib.config.kzol_bw[character]!=undefined){
			lib.config.kzol_bag[lib.config.kzol_bag_num]=lib.config.kzol_bw[character];
			game.saveConfig('kzol_bag_num',lib.config.kzol_bag_num+1);
		};
		lib.config.kzol_bw[character]=lib.config.kzol_bag[item_num];
		game.say1(get.translation(character)+'装备了'+get.translation(lib.config.kzol_bag[item_num].ext_name));
		var item=lib.config.kzol_bag[item_num];
		game.loseItem2(item_num,1,false);
		lib.config.kzol_bw[character].num=1;
		game.saveConfig('kzol_bw',lib.config.kzol_bw);
	};
	lib.skill._kzol_bw={
		trigger:{
			global:'gameStart',
		},
		forced:true,
		popup:false,
		filter:function (event,player){
			if(lib.config['extension_扩展ol_bw_forbidden']==true) return false;
			if(lib.config['extension_扩展ol_bw_aiCanUse']==true&&lib.config.kzol_bw[player.name]==undefined&&(player.name2==undefined&&lib.config.kzol_bw[player.name2]==undefined)&&player==game.me) return false;
			if(lib.config['extension_扩展ol_bw_aiCanUse']==true) return true;
			return lib.config.kzol_bw[player.name]!=undefined||(player.name2!=undefined&&lib.config.kzol_bw[player.name2]!=undefined)&&player==game.me;
		},
		content:function(){
			if(player!=game.me&&lib.config['extension_扩展ol_bw_aiCanUse']==true){
				var list=[];
				for(var i in lib.kzol_bag){
					if(lib.kzol_bag[i].type=='baowu') list.push(lib.kzol_bag[i].name);
				};
				var name=list.randomGet();
				var skill='kzol_bw_'+name;
				player.addSkill(skill);
				player.storage.kzol_bw=name;
				setTimeout(function(){
					for(var i=0;i<player.node.marks.childNodes.length;i++){
						if(player.node.marks.childNodes[i].name==skill){
							if(lib.kzol_bag[name].character==undefined){
								player.node.marks.childNodes[i].setBackgroundImage('extension/扩展ol/'+name+'.png');
							}else{
								player.node.marks.childNodes[i].setBackground(lib.kzol_bag[name].character,'character');
							};
							player.node.marks.childNodes[i].innerHTML='';
						};
					};
				},200);
			};
			if(lib.config.kzol_bw[player.name]!=undefined&&player==game.me){
				var name=lib.config.kzol_bw[player.name].ext_name;
				var skill='kzol_bw_'+name;
				player.addSkill(skill);
				setTimeout(function(){
					for(var i=0;i<player.node.marks.childNodes.length;i++){
						if(player.node.marks.childNodes[i].name==skill){
							if(lib.config.kzol_bw[player.name].character==undefined){
								player.node.marks.childNodes[i].setBackgroundImage('extension/扩展ol/'+name+'.png');
							}else{
								player.node.marks.childNodes[i].setBackground(lib.config.kzol_bw[player.name].character,'character');
							};
							player.node.marks.childNodes[i].innerHTML='';
						};
					};
				},200);
			};
			if(lib.config.kzol_bw[player.name2]!=undefined){
				var name=lib.config.kzol_bw[player.name2].ext_name;
				var skill='kzol_bw_'+name;
				player.addSkill(skill);
				setTimeout(function(){
					for(var i=0;i<player.node.marks.childNodes.length;i++){
						if(player.node.marks.childNodes[i].name==skill){
							player.node.marks.childNodes[i].setBackgroundImage('extension/扩展ol/'+name+'.png');
							player.node.marks.childNodes[i].innerHTML='';
						};
					};
				},200);
			};
		},
	};
	var bw_name='baozhu';
	lib.skill['kzol_bw_'+bw_name]={
		nobracket:true,
		intro:{
			content:lib.kzol_bag[bw_name].info.slice(4,lib.kzol_bag[bw_name].info.length),
		},
		mark:true,
		trigger:{
			player:'phaseBegin',
		},
		forced:true,
		filter:function (event,player){
			return player.storage.kzol_bw_baozhu==undefined;
		},
		content:function(){
			player.getBuff();
			player.storage.kzol_bw_baozhu=true;
		},
	};
	var bw_name='qianmian';
	lib.skill['kzol_bw_'+bw_name]={
		nobracket:true,
		intro:{
			content:function(storage){
				return lib.kzol_bag[bw_name].info.slice(4,lib.kzol_bag[bw_name].info.length)+'<br>已使用次数：'+storage;
			},
		},
		mark:true,
		init:function(player){
			if(player.storage.kzol_bw_qianmian==undefined) player.storage.kzol_bw_qianmian=0;
			for(var i=0;i<game.players.length;i++){
				var pl=game.players[i];
				if(pl!=player){
					var skills=pl.get('s');
					for(var j=0;j<skills.length;j++){
						if(lib.translate[skills[j]+'_info']!=undefined&&lib.translate[skills[j]+'_info'].indexOf('限')!=-1&&lib.translate[skills[j]+'_info'].indexOf('次')!=-1&&lib.skill[skills[j]].usable!=undefined&&lib.skill[skills[j]].content!=undefined){
							player.addSkill('kzol_bw_'+skills[j]);
						};
					};
				};
			};
		},
	};
	var bw_name='xukongdajian';
	lib.skill['kzol_bw_'+bw_name]={
		nobracket:true,
		intro:{
			content:lib.kzol_bag[bw_name].info.slice(4,lib.kzol_bag[bw_name].info.length),
		},
		mark:true,
		trigger:{
			source:"damageBefore",
		},
		forced:true,
		priority:Infinity,
		content:function (){
			trigger._triggered=null;
		},
	};
	var translation={
		'baozhu':'宝珠',
		'qianmian':'千面',
		'xukongdajian':'虚空·大剑',
	};
	for(var i in translation){
		lib.translate[i]=translation[i];
		lib.translate['kzol_bw_'+i]='宝物：'+translation[i];
		lib.translate['kzol_bw_'+i+'_info']=lib.kzol_bag[i].info.slice(4,lib.kzol_bag[i].info.length);
	};
	lib.translate.baowu='宝物';
	for(var i in lib.skill){
		if(lib.translate[i+'_info']!=undefined&&lib.translate[i+'_info'].indexOf('限')!=-1&&lib.translate[i+'_info'].indexOf('次')!=-1&&lib.skill[i].usable!=undefined&&lib.skill[i].content!=undefined){
			lib.skill['kzol_bw_'+i]=lib.skill[i];
			var func2=lib.skill['kzol_bw_'+i].content;
			var str=func2.toString();
			str=str.slice(0,str.length-1);
			str+=";if(player.storage.kzol_bw_qianmian>=2){var skills=player.get('s');for(var j=0;j<skills.length;j++){if(skills[j].indexOf('kzol_bw_')!=-1) player.removeSkill(skills[j]);};};player.storage.kzol_bw_qianmian++;player.syncStorage('kzol_bw_qianmian');}";
			str='('+str+')';
			lib.skill[i].content=eval(str);
			//console.log(lib.skill[i].content)
			lib.translate['kzol_bw_'+i]=lib.translate[i];
			lib.translate['kzol_bw_'+i+'_info']='<li>千面技能<br>'+lib.translate[i+'_info'];
		};
	};
}